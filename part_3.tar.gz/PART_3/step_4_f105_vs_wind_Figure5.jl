using Glob  # for globbing the file patterns
using CSV   # for reading CSV files
using Plots # for plotting
using Colors # for color normalization
using NCDatasets # for NetCDF
using Dates  # to convert dates in sec
using Statistics # for mean
using Dierckx     # For detrend (spline interpolation)
using Polynomials
using StatsBase 
using DSP  # Import DSP package
using DelimitedFiles
using Measures
using LaTeXStrings



include("../paths_for_all.jl")

function main()
    # PATH_output_png = "/home/ellai/test_arm_data/flux_calc/VER6/output_png/"
    # PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER6/output_txt/"

    w_winter_data = readdlm(PATH_output_txt *"wind_winter.txt")
    w_spring_data = readdlm(PATH_output_txt *"wind_spring.txt")
    w_summer_data = readdlm(PATH_output_txt *"wind_summer.txt")
    w_fall_data   = readdlm(PATH_output_txt *"wind_fall.txt")

    f_winter_data = readdlm(PATH_output_txt * "flux_105_stats_season_1.txt")
    f_spring_data = readdlm(PATH_output_txt * "flux_105_stats_season_2.txt")
    f_summer_data = readdlm(PATH_output_txt * "flux_105_stats_season_3.txt")
    f_fall_data   = readdlm(PATH_output_txt * "flux_105_stats_season_4.txt")

    colors = cgrad([:purple, :green], 4, categorical = true)

    p = plot(layout=(2, 5), size=(1700, 900), bottom_margin=10mm, 
         xguidefont=22 ,yguidefont=22, ytickfont=font(16), xtickfont=font(16), 
         legendfont=font(16), xlim=[-0.2, 24.5], ylim=[0, 7], plot_spacing=(-50mm, 0mm), xticks = [0, 6, 12, 18, 24])
 
    # println( w_winter_data[:, 1])
    # println( w_winter_data[:, 2])   
    # println( w_winter_data[:, 3]) 
    # sleep(100)
    main_max = maximum([maximum(f_winter_data[:, 4]), maximum(f_spring_data[:, 4]),maximum(f_summer_data[:, 4]), maximum(f_fall_data[:, 4]) ]) 
    # println(maximum(f_winter_data[:, 4]))
    # println(maximum(f_spring_data[:, 4]))
    # println(maximum(f_summer_data[:, 4]))
    # println(maximum(f_fall_data[:, 4]))

    f_winter_data = f_winter_data[sortperm(f_winter_data[:, 1]), :]
    f_spring_data = f_spring_data[sortperm(f_spring_data[:, 1]), :]
    f_summer_data = f_summer_data[sortperm(f_summer_data[:, 1]), :]
    f_fall_data = f_fall_data[sortperm(f_fall_data[:, 1]), :]

    # f_alpha_winter = f_winter_data[:, 4] ./ maximum(f_winter_data[:, 4])
    # f_alpha_winter = f_winter_data[:, 4] ./ main_max 
    # plot!(p[1],  f_winter_data[:, 1], f_winter_data[:, 2]; ribbon = f_winter_data[:, 3], color = colors[1] ,  fillalpha = 0.2, linealpha = 0, label = "", ylabel = L"Flux_{105m} \times 10^6 (s^{-1}sr^{-1})", xlabel =L"Time (h)" )
    # scatter!(p[1],  f_winter_data[:, 1], f_winter_data[:, 2]; alpha = f_alpha_winter, color = colors[1] , markersize=5, colorbar = false, label="", ylims = [-0.1, 0.3],  title="winter", titlefont=font(18))
    # hline!(p[1], [0], color=:gray, linestyle=:dash, label = false)
    # annotate!(p[1], (1, 0.35, text("a", :left, 16)))

    # # f_alpha_spring = f_spring_data[:, 4] ./ maximum(f_spring_data[:, 4])
    # f_alpha_spring = f_spring_data[:, 4] ./ main_max
    # plot!(p[2],  f_spring_data[:, 1], f_spring_data[:, 2]; ribbon = f_spring_data[:, 3], color = colors[2] ,  fillalpha = 0.2, linealpha = 0, label = "", xlabel =L"Time (h)" )
    # scatter!(p[2],  f_spring_data[:, 1], f_spring_data[:, 2]; alpha = f_alpha_spring, color = colors[2] , markersize=5, colorbar = false, label="", ylims = [-0.1, 0.3],  title="spring", titlefont=font(18))
    # hline!(p[2], [0], color=:gray, linestyle=:dash, label = false)
    # annotate!(p[2], (1, 0.35, text("b", :left, 16)))

    # f_alpha_summer = f_summer_data[:, 4] ./ maximum(f_summer_data[:, 4])
    # f_alpha_summer = f_summer_data[:, 4] ./ main_max
    # plot!(p[3],  f_summer_data[:, 1], f_summer_data[:, 2]; ribbon = f_summer_data[:, 3], color = colors[3] ,  fillalpha = 0.2, linealpha = 0, label = "", xlabel =L"Time (h)" )
    # scatter!(p[3],  f_summer_data[:, 1], f_summer_data[:, 2]; alpha = f_alpha_summer, color = colors[3] , markersize=5, colorbar = false, label="", ylims = [-0.1, 0.3],  title="summer", titlefont=font(18))
    # hline!(p[3], [0], color=:gray, linestyle=:dash, label = false)
    # annotate!(p[3], (1, 0.35, text("c", :left, 16)))
    plot!(p[1], f_winter_data[:, 1], f_winter_data[:, 2] .+ f_winter_data[:, 3]; fillrange = f_winter_data[:, 2] .- f_winter_data[:, 3], fillalpha = 0.15, linealpha = 0, color =:grey, label = "", ylabel = L"Flux_{105m} \ (cm^{-2}s^{-1})", xlabel =L"Time (h)" , left_margin=9mm )
    f_alpha_winter = f_winter_data[:, 4] ./ main_max
    # scatter!(p[1], f_winter_data[:, 1], f_winter_data[:, 2]; alpha = f_alpha_winter, color =:grey, markersize = 5, colorbar = false, label = "", ylims = [-0.1, 100], title = "winter", titlefont = font(18))
    scatter!(p[1], f_winter_data[:,1], f_winter_data[:,2], zcolor=f_alpha_winter, c=:binary, colorbar=false, markersize=5, markerstrokewidth=0, alpha=0.8, ylims=[-0.1,100], title="winter", titlefont=font(18), label="",   clims=(0, 1))
    hline!(p[1], [0], color = :gray, linestyle = :dash, label = false)
    annotate!(p[1], (1, 90, text("a", :left, 16)))
    vline!(p[1], [7.41], color = :red, linestyle = :dash, label = false)
    vline!(p[1], [17.75], color = :blue, linestyle = :dash, label = false)

    plot!(p[2], f_spring_data[:, 1], f_spring_data[:, 2] .+ f_spring_data[:, 3]; fillrange = f_spring_data[:, 2] .- f_spring_data[:, 3], fillalpha = 0.15, linealpha = 0, color =:grey, label = "")
    f_alpha_spring = f_spring_data[:, 4] ./ main_max
    # scatter!(p[2], f_spring_data[:, 1], f_spring_data[:, 2]; alpha = f_alpha_spring, color =:grey, markersize = 5, colorbar = false, label = "", ylims = [-0.1, 100], title = "spring", titlefont = font(18))
    scatter!(p[2], f_spring_data[:,1], f_spring_data[:,2], zcolor=f_alpha_spring, c=:binary, colorbar=false, markersize=5, markerstrokewidth=0, alpha=0.8, ylims=[-0.1,100], title="spring", titlefont=font(18), label="",   clims=(0, 1))
    hline!(p[2], [0], color = :gray, linestyle = :dash, label = false)
    annotate!(p[2], (1, 90, text("b", :left, 16)))
    vline!(p[2], [6.5], color = :red, linestyle = :dash, label = false)
    vline!(p[2], [20.00], color = :blue, linestyle = :dash, label = false)

    plot!(p[3], f_summer_data[:, 1], f_summer_data[:, 2] .+ f_summer_data[:, 3]; fillrange = f_summer_data[:, 2] .- f_summer_data[:, 3], fillalpha = 0.15, linealpha = 0, color =:grey, label = "")
    f_alpha_summer = f_summer_data[:, 4] ./ main_max
    # scatter!(p[3], f_summer_data[:, 1], f_summer_data[:, 2]; alpha = f_alpha_summer, color =:grey, markersize = 5, colorbar = false, label = "", ylims = [-0.1, 100], title = "summer", titlefont = font(18))
    scatter!(p[3], f_summer_data[:,1], f_summer_data[:,2], zcolor=f_alpha_summer, c=:binary, colorbar=false, markersize=5, markerstrokewidth=0, alpha=0.8, ylims=[-0.1,100], title="summer", titlefont=font(18), label="",   clims=(0, 1))
    hline!(p[3], [0], color = :gray, linestyle = :dash, label = false)
    annotate!(p[3], (1, 90, text("c", :left, 16)))
    vline!(p[3], [6.5], color = :red, linestyle = :dash, label = false)
    vline!(p[3], [20.5], color = :blue, linestyle = :dash, label = false)

    plot!(p[4], f_fall_data[:, 1], f_fall_data[:, 2] .+ f_fall_data[:, 3]; fillrange = f_fall_data[:, 2] .- f_fall_data[:, 3], fillalpha = 0.15, linealpha = 0, color =:grey, label = "")
    f_alpha_fall = f_fall_data[:, 4] ./ main_max
    # scatter!(p[4], f_fall_data[:, 1], f_fall_data[:, 2]; alpha = f_alpha_fall, color =:grey, markersize = 5, colorbar = true, label = "", ylims = [-0.1, 100], title = "fall", titlefont = font(18))
    scatter!(p[4], f_fall_data[:,1], f_fall_data[:,2], zcolor=f_alpha_fall, c=:binary, colorbar=false, markersize=5, markerstrokewidth=0, alpha=0.8, ylims=[-0.1,100], title="fall", titlefont=font(18), label="",   clims=(0, 1))
    hline!(p[4], [0], color = :gray, linestyle = :dash, label = false)
    annotate!(p[4], (1, 90, text("d", :left, 16)))
    vline!(p[4], [7.1], color = :red, linestyle = :dash, label = false)
    vline!(p[4], [18.5], color = :blue, linestyle = :dash, label = false)

    scatter!(p[5], f_fall_data[:,1], f_fall_data[:,2],
    zcolor=f_alpha_fall, c=:binary, colorbar=true, clims=(0,1), markersize=0, label="", framestyle=:none,   colorbar_position = :right)

    # println("fefe")
    # println(f_summer_data[:, 1], " ", f_summer_data[:, 2], " ", f_summer_data[:, 3])

    # f_alpha_fall = f_fall_data[:, 4] ./ maximum(f_fall_data[:, 4])
    # f_alpha_fall = f_fall_data[:, 4] ./ main_max
    # plot!(p[4],  f_fall_data[:, 1], f_fall_data[:, 2]; ribbon = f_fall_data[:, 3], color = colors[4] ,  fillalpha = 0.2, linealpha = 0, label = "", xlabel =L"Time (h)" )
    # scatter!(p[4],  f_fall_data[:, 1], f_fall_data[:, 2]; alpha = f_alpha_fall, color = colors[4] , markersize=5, colorbar = false, label="", ylims = [-0.1, 0.3],  title="fall", titlefont=font(18))
    # hline!(p[4], [0], color=:gray, linestyle=:dash, label = false)
    # annotate!(p[4], (1, 0.35, text("d", :left, 16)))
    
    # println(minimum(f_alpha_winter))
    # println(minimum(f_alpha_spring))
    # println(minimum(f_alpha_fall))
    # println(minimum(f_alpha_summer))

    scatter!(p[6], w_winter_data[:, 1], w_winter_data[:, 2], label=false, xlabel=L"Time\ (h)", ylabel=L"Wind\ (m/s)", lw=2, marker=:circle, color=:grey, legend=:topright, ylim=[0, 7])
    plot!(p[6], w_winter_data[:, 1], w_winter_data[:, 3], fill_between=(w_winter_data[:, 4], w_winter_data[:, 3]), fillalpha=0.15, color=:grey, label=false, lw=0)
    hline!(p[6], [0], color=:black, lw=1, linestyle=:dash, label=false)
    annotate!(p[6], (1, 6.7, text("e", :left, 16)))
    vline!(p[6], [7.41], color = :red, linestyle = :dash, label = false)
    vline!(p[6], [17.75], color = :blue, linestyle = :dash, label = false)

    scatter!(p[7], w_spring_data[:, 1], w_spring_data[:, 2], label=false, xlabel=L"Time\ (h)", lw=2, marker=:circle, color=:grey, legend=:topright,  ylim=[0, 7])
    plot!(p[7], w_spring_data[:, 1], w_spring_data[:, 3], fill_between=(w_spring_data[:, 4], w_spring_data[:, 3]), fillalpha=0.15, color=:grey, label=false, lw=0)
    hline!(p[7], [0], color=:black, lw=1, linestyle=:dash, label=false)
    annotate!(p[7], (1, 6.7, text("f", :left, 16)))
    vline!(p[7], [6.5], color = :red, linestyle = :dash, label = false)
    vline!(p[7], [20.00], color = :blue, linestyle = :dash, label = false)

    scatter!(p[8], w_summer_data[:, 1], w_summer_data[:, 2], label=false,  xlabel=L"Time\ (h)", lw=2, marker=:circle, color=:grey, legend=:topright,  ylim=[0, 7])
    plot!(p[8], w_summer_data[:, 1], w_summer_data[:, 3], fill_between=(w_summer_data[:, 4], w_summer_data[:, 3]), fillalpha=0.15, color=:grey, label=false, lw=0)
    hline!(p[8], [0], color=:black, lw=1, linestyle=:dash, label=false)
    annotate!(p[8], (1, 6.7, text("g", :left, 16)))
    vline!(p[8], [6.5], color = :red, linestyle = :dash, label = false)
    vline!(p[8], [20.5], color = :blue, linestyle = :dash, label = false)

    scatter!(p[9], w_fall_data[:, 1], w_fall_data[:, 2], label=false, xlabel=L"Time\ (h)", lw=2, marker=:circle, color=:grey, legend=:topright,  ylim=[0, 7])
    plot!(p[9], w_fall_data[:, 1], w_fall_data[:, 3], fill_between=(w_fall_data[:, 4], w_fall_data[:, 3]), fillalpha=0.15, color=:grey, label=false, lw=0)
    hline!(p[9], [0], color=:black, lw=1, linestyle=:dash, label=false)
    annotate!(p[9], (1, 6.7, text("h", :left, 16)))
    vline!(p[9], [7.1], color = :red, linestyle = :dash, label = false)
    vline!(p[9], [18.5], color = :blue, linestyle = :dash, label = false)

    plot!(p[10], framestyle=:none, grid=false, legend=false, showaxis=false)

    println("fefefer")
    println(PATH_output_png* "FOR_PAPER_flux105_wind_over_day_for_season.png") 
    savefig(PATH_output_png* "FOR_PAPER_flux105_wind_over_day_for_season.png")
end 



function main_dir()
    # PATH_output_png = "/home/ellai/test_arm_data/flux_calc/VER6/output_png/"
    # PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER6/output_txt/"

    w_winter_data = readdlm(PATH_output_txt *"wind_dir_winter.txt")
    w_spring_data = readdlm(PATH_output_txt *"wind_dir_spring.txt")
    w_summer_data = readdlm(PATH_output_txt *"wind_dir_summer.txt")
    w_fall_data   = readdlm(PATH_output_txt *"wind_dir_fall.txt")

    f_winter_data = readdlm(PATH_output_txt * "flux_105_stats_season_1.txt")
    f_spring_data = readdlm(PATH_output_txt * "flux_105_stats_season_2.txt")
    f_summer_data = readdlm(PATH_output_txt * "flux_105_stats_season_3.txt")
    f_fall_data   = readdlm(PATH_output_txt * "flux_105_stats_season_4.txt")

    colors = cgrad([:purple, :green], 4, categorical = true)

    p = plot(layout=(2, 5), size=(1700, 900), bottom_margin=10mm, 
         xguidefont=22 ,yguidefont=22, ytickfont=font(16), xtickfont=font(16), 
         legendfont=font(16), xlim=[-0.2, 24.5], ylim=[0, 7], plot_spacing=(-50mm, 0mm), xticks = [0, 6, 12, 18, 24])
 
    # println( w_winter_data[:, 1])
    # println( w_winter_data[:, 2])   
    # println( w_winter_data[:, 3]) 
    # sleep(100)
    main_max = maximum([maximum(f_winter_data[:, 4]), maximum(f_spring_data[:, 4]),maximum(f_summer_data[:, 4]), maximum(f_fall_data[:, 4]) ]) 
    # println(maximum(f_winter_data[:, 4]))
    # println(maximum(f_spring_data[:, 4]))
    # println(maximum(f_summer_data[:, 4]))
    # println(maximum(f_fall_data[:, 4]))

    f_winter_data = f_winter_data[sortperm(f_winter_data[:, 1]), :]
    f_spring_data = f_spring_data[sortperm(f_spring_data[:, 1]), :]
    f_summer_data = f_summer_data[sortperm(f_summer_data[:, 1]), :]
    f_fall_data = f_fall_data[sortperm(f_fall_data[:, 1]), :]

    # f_alpha_winter = f_winter_data[:, 4] ./ maximum(f_winter_data[:, 4])
    # f_alpha_winter = f_winter_data[:, 4] ./ main_max 
    # plot!(p[1],  f_winter_data[:, 1], f_winter_data[:, 2]; ribbon = f_winter_data[:, 3], color = colors[1] ,  fillalpha = 0.2, linealpha = 0, label = "", ylabel = L"Flux_{105m} \times 10^6 (s^{-1}sr^{-1})", xlabel =L"Time (h)" )
    # scatter!(p[1],  f_winter_data[:, 1], f_winter_data[:, 2]; alpha = f_alpha_winter, color = colors[1] , markersize=5, colorbar = false, label="", ylims = [-0.1, 0.3],  title="winter", titlefont=font(18))
    # hline!(p[1], [0], color=:gray, linestyle=:dash, label = false)
    # annotate!(p[1], (1, 0.35, text("a", :left, 16)))

    # # f_alpha_spring = f_spring_data[:, 4] ./ maximum(f_spring_data[:, 4])
    # f_alpha_spring = f_spring_data[:, 4] ./ main_max
    # plot!(p[2],  f_spring_data[:, 1], f_spring_data[:, 2]; ribbon = f_spring_data[:, 3], color = colors[2] ,  fillalpha = 0.2, linealpha = 0, label = "", xlabel =L"Time (h)" )
    # scatter!(p[2],  f_spring_data[:, 1], f_spring_data[:, 2]; alpha = f_alpha_spring, color = colors[2] , markersize=5, colorbar = false, label="", ylims = [-0.1, 0.3],  title="spring", titlefont=font(18))
    # hline!(p[2], [0], color=:gray, linestyle=:dash, label = false)
    # annotate!(p[2], (1, 0.35, text("b", :left, 16)))

    # f_alpha_summer = f_summer_data[:, 4] ./ maximum(f_summer_data[:, 4])
    # f_alpha_summer = f_summer_data[:, 4] ./ main_max
    # plot!(p[3],  f_summer_data[:, 1], f_summer_data[:, 2]; ribbon = f_summer_data[:, 3], color = colors[3] ,  fillalpha = 0.2, linealpha = 0, label = "", xlabel =L"Time (h)" )
    # scatter!(p[3],  f_summer_data[:, 1], f_summer_data[:, 2]; alpha = f_alpha_summer, color = colors[3] , markersize=5, colorbar = false, label="", ylims = [-0.1, 0.3],  title="summer", titlefont=font(18))
    # hline!(p[3], [0], color=:gray, linestyle=:dash, label = false)
    # annotate!(p[3], (1, 0.35, text("c", :left, 16)))
    plot!(p[1], f_winter_data[:, 1], f_winter_data[:, 2] .+ f_winter_data[:, 3]; fillrange = f_winter_data[:, 2] .- f_winter_data[:, 3], fillalpha = 0.15, linealpha = 0, color =:grey, label = "", ylabel = L"Flux_{105m} \times 10^6 (s^{-1}sr^{-1})", xlabel =L"Time (h)" , left_margin=9mm )
    f_alpha_winter = f_winter_data[:, 4] ./ main_max
    # scatter!(p[1], f_winter_data[:, 1], f_winter_data[:, 2]; alpha = f_alpha_winter, color =:grey, markersize = 5, colorbar = false, label = "", ylims = [-0.1, 100], title = "winter", titlefont = font(18))
    scatter!(p[1], f_winter_data[:,1], f_winter_data[:,2], zcolor=f_alpha_winter, c=:binary, colorbar=false, markersize=5, markerstrokewidth=0, alpha=0.8, ylims=[-0.1,100], title="winter", titlefont=font(18), label="",   clims=(0, 1))
    hline!(p[1], [0], color = :gray, linestyle = :dash, label = false)
    annotate!(p[1], (1, 90, text("a", :left, 16)))
    vline!(p[1], [7.41], color = :red, linestyle = :dash, label = false)
    vline!(p[1], [17.75], color = :blue, linestyle = :dash, label = false)

    plot!(p[2], f_spring_data[:, 1], f_spring_data[:, 2] .+ f_spring_data[:, 3]; fillrange = f_spring_data[:, 2] .- f_spring_data[:, 3], fillalpha = 0.15, linealpha = 0, color =:grey, label = "")
    f_alpha_spring = f_spring_data[:, 4] ./ main_max
    # scatter!(p[2], f_spring_data[:, 1], f_spring_data[:, 2]; alpha = f_alpha_spring, color =:grey, markersize = 5, colorbar = false, label = "", ylims = [-0.1, 100], title = "spring", titlefont = font(18))
    scatter!(p[2], f_spring_data[:,1], f_spring_data[:,2], zcolor=f_alpha_spring, c=:binary, colorbar=false, markersize=5, markerstrokewidth=0, alpha=0.8, ylims=[-0.1,100], title="spring", titlefont=font(18), label="",   clims=(0, 1))
    hline!(p[2], [0], color = :gray, linestyle = :dash, label = false)
    annotate!(p[2], (1, 90, text("b", :left, 16)))
    vline!(p[2], [6.5], color = :red, linestyle = :dash, label = false)
    vline!(p[2], [20.00], color = :blue, linestyle = :dash, label = false)

    plot!(p[3], f_summer_data[:, 1], f_summer_data[:, 2] .+ f_summer_data[:, 3]; fillrange = f_summer_data[:, 2] .- f_summer_data[:, 3], fillalpha = 0.15, linealpha = 0, color =:grey, label = "")
    f_alpha_summer = f_summer_data[:, 4] ./ main_max
    # scatter!(p[3], f_summer_data[:, 1], f_summer_data[:, 2]; alpha = f_alpha_summer, color =:grey, markersize = 5, colorbar = false, label = "", ylims = [-0.1, 100], title = "summer", titlefont = font(18))
    scatter!(p[3], f_summer_data[:,1], f_summer_data[:,2], zcolor=f_alpha_summer, c=:binary, colorbar=false, markersize=5, markerstrokewidth=0, alpha=0.8, ylims=[-0.1,100], title="summer", titlefont=font(18), label="",   clims=(0, 1))
    hline!(p[3], [0], color = :gray, linestyle = :dash, label = false)
    annotate!(p[3], (1, 90, text("c", :left, 16)))
    vline!(p[3], [6.5], color = :red, linestyle = :dash, label = false)
    vline!(p[3], [20.5], color = :blue, linestyle = :dash, label = false)

    plot!(p[4], f_fall_data[:, 1], f_fall_data[:, 2] .+ f_fall_data[:, 3]; fillrange = f_fall_data[:, 2] .- f_fall_data[:, 3], fillalpha = 0.15, linealpha = 0, color =:grey, label = "")
    f_alpha_fall = f_fall_data[:, 4] ./ main_max
    # scatter!(p[4], f_fall_data[:, 1], f_fall_data[:, 2]; alpha = f_alpha_fall, color =:grey, markersize = 5, colorbar = true, label = "", ylims = [-0.1, 100], title = "fall", titlefont = font(18))
    scatter!(p[4], f_fall_data[:,1], f_fall_data[:,2], zcolor=f_alpha_fall, c=:binary, colorbar=false, markersize=5, markerstrokewidth=0, alpha=0.8, ylims=[-0.1,100], title="fall", titlefont=font(18), label="",   clims=(0, 1))
    hline!(p[4], [0], color = :gray, linestyle = :dash, label = false)
    annotate!(p[4], (1, 90, text("d", :left, 16)))
    vline!(p[4], [7.1], color = :red, linestyle = :dash, label = false)
    vline!(p[4], [18.5], color = :blue, linestyle = :dash, label = false)

    scatter!(p[5], f_fall_data[:,1], f_fall_data[:,2],
    zcolor=f_alpha_fall, c=:binary, colorbar=true, clims=(0,1), markersize=0, label="", framestyle=:none,   colorbar_position = :right)

    # println("fefe")
    # println(f_summer_data[:, 1], " ", f_summer_data[:, 2], " ", f_summer_data[:, 3])

    # f_alpha_fall = f_fall_data[:, 4] ./ maximum(f_fall_data[:, 4])
    # f_alpha_fall = f_fall_data[:, 4] ./ main_max
    # plot!(p[4],  f_fall_data[:, 1], f_fall_data[:, 2]; ribbon = f_fall_data[:, 3], color = colors[4] ,  fillalpha = 0.2, linealpha = 0, label = "", xlabel =L"Time (h)" )
    # scatter!(p[4],  f_fall_data[:, 1], f_fall_data[:, 2]; alpha = f_alpha_fall, color = colors[4] , markersize=5, colorbar = false, label="", ylims = [-0.1, 0.3],  title="fall", titlefont=font(18))
    # hline!(p[4], [0], color=:gray, linestyle=:dash, label = false)
    # annotate!(p[4], (1, 0.35, text("d", :left, 16)))
    
    # println(minimum(f_alpha_winter))
    # println(minimum(f_alpha_spring))
    # println(minimum(f_alpha_fall))
    # println(minimum(f_alpha_summer))

    scatter!(p[6], w_winter_data[:, 1], w_winter_data[:, 2], label=false, xlabel=L"Time\ (h)", ylabel=L"Wind\ (m/s)", lw=2, marker=:circle, color=:grey, legend=:topright, ylim=[100, 250])
    plot!(p[6], w_winter_data[:, 1], w_winter_data[:, 3], fill_between=(w_winter_data[:, 4], w_winter_data[:, 3]), fillalpha=0.15, color=:grey, label=false, lw=0)
    hline!(p[6], [0], color=:black, lw=1, linestyle=:dash, label=false)
    annotate!(p[6], (1, 6.7, text("e", :left, 16)))
    vline!(p[6], [7.41], color = :red, linestyle = :dash, label = false)
    vline!(p[6], [17.75], color = :blue, linestyle = :dash, label = false)

    scatter!(p[7], w_spring_data[:, 1], w_spring_data[:, 2], label=false, xlabel=L"Time\ (h)", lw=2, marker=:circle, color=:grey, legend=:topright,  ylim=[100, 250])
    plot!(p[7], w_spring_data[:, 1], w_spring_data[:, 3], fill_between=(w_spring_data[:, 4], w_spring_data[:, 3]), fillalpha=0.15, color=:grey, label=false, lw=0)
    hline!(p[7], [0], color=:black, lw=1, linestyle=:dash, label=false)
    annotate!(p[7], (1, 6.7, text("f", :left, 16)))
    vline!(p[7], [6.5], color = :red, linestyle = :dash, label = false)
    vline!(p[7], [20.00], color = :blue, linestyle = :dash, label = false)

    scatter!(p[8], w_summer_data[:, 1], w_summer_data[:, 2], label=false,  xlabel=L"Time\ (h)", lw=2, marker=:circle, color=:grey, legend=:topright,  ylim=[100, 250])
    plot!(p[8], w_summer_data[:, 1], w_summer_data[:, 3], fill_between=(w_summer_data[:, 4], w_summer_data[:, 3]), fillalpha=0.15, color=:grey, label=false, lw=0)
    hline!(p[8], [0], color=:black, lw=1, linestyle=:dash, label=false)
    annotate!(p[8], (1, 6.7, text("g", :left, 16)))
    vline!(p[8], [6.5], color = :red, linestyle = :dash, label = false)
    vline!(p[8], [20.5], color = :blue, linestyle = :dash, label = false)

    scatter!(p[9], w_fall_data[:, 1], w_fall_data[:, 2], label=false, xlabel=L"Time\ (h)", lw=2, marker=:circle, color=:grey, legend=:topright,  ylim=[100, 250])
    plot!(p[9], w_fall_data[:, 1], w_fall_data[:, 3], fill_between=(w_fall_data[:, 4], w_fall_data[:, 3]), fillalpha=0.15, color=:grey, label=false, lw=0)
    hline!(p[9], [0], color=:black, lw=1, linestyle=:dash, label=false)
    annotate!(p[9], (1, 6.7, text("h", :left, 16)))
    vline!(p[9], [7.1], color = :red, linestyle = :dash, label = false)
    vline!(p[9], [18.5], color = :blue, linestyle = :dash, label = false)

    plot!(p[10], framestyle=:none, grid=false, legend=false, showaxis=false)

    println("fefefer")
    println(PATH_output_png* "FOR_PAPER_flux105_wind_dir_over_day_for_season.png") 
    savefig(PATH_output_png* "FOR_PAPER_flux105_wind_dir_over_day_for_season.png")
end 

function plot_for_season(num_season)
    # PATH_output_png = "/home/ellai/test_arm_data/flux_calc/VER6/output_png/"
    # PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER6/output_txt/"
    
    file_suffixes = ["fluxH_MOD_unstable_clean.txt", "fluxH_MOD_unstable_nonclean.txt",  "fluxH_MOD_neutral_clean.txt",  "fluxH_MOD_neutral_nonclean.txt"]
    # file_suffixes = ["fluxH_MOD_neutral_nonclean.txt",  "fluxH_MOD_neutral_clean.txt"]

    input_data_list = [readdlm(PATH_output_txt * suffix) for suffix in file_suffixes]
    input_data = vcat(input_data_list...)
    # input_file_name_1 =  PATH_output_txt * "fluxH_MOD_unstable_clean.txt"
    # input_file_name_2 =  PATH_output_txt * "fluxH_MOD_unstable_nonclean.txt"
    # input_file_name_3 =  PATH_output_txt * "fluxH_MOD_neutral_clean.txt"
    # input_file_name_4 =  PATH_output_txt * "fluxH_MOD_neutral_nonclean.txt"

    # #[day, month, year, time_in, diff_t, 105, mean_b, std_b, mean_w, std_w, mean_var_w2, std_var_w2, mean_f, std_f, lod_mean, f_uncert_noise, stab_zl]
    # input_data_1 = readdlm(input_file_name_1)
    # input_data_2 = readdlm(input_file_name_2)
    # input_data_3 = readdlm(input_file_name_3)
    # input_data_4 = readdlm(input_file_name_4)

    # input_data = vcat(input_data_1, input_data_2, input_data_3, input_data_4)


    #day, month, year, time_f, height, w2_mean, backscat_mean, flux_corr, w2_std, backscat_std, flux_std, time_range
    day, month, year = input_data[:, 1], input_data[:, 2], input_data[:, 3]
    time_in, time_range = input_data[:, 4], input_data[:, 12]
    height = input_data[:, 5]
    w2_mean, w2_std = input_data[:, 6], input_data[:, 9]
    backscat_mean, backscat_std = input_data[:, 7], input_data[:, 10]
    flux_mean, flux_std = input_data[:, 8], input_data[:, 11]
   
    # sort 12:00 time     
    mask_1200 = (time_in .>= 0) .& (time_in .<= 24)

    time_in, time_range = time_in[mask_1200], time_range[mask_1200]
    w2_mean, w2_std = w2_mean[mask_1200], w2_std[mask_1200]
    flux_mean, flux_std = flux_mean[mask_1200], flux_std[mask_1200]
    backscat_mean, backscat_std = backscat_mean[mask_1200], backscat_std[mask_1200]
    day, month, year = day[mask_1200], month[mask_1200], year[mask_1200]
    height = height[mask_1200]

    # sort by season 
    if num_season == 1
        mask_ssn = (month .== 1) .| (month .== 2) .| (month .== 12)
    elseif num_season == 2
        mask_ssn = (month .== 3) .| (month .== 4) .| (month .== 5)
    elseif num_season == 3
        mask_ssn = (month .== 6) .| (month .== 7) .| (month .== 8)
    elseif num_season == 4
        mask_ssn = (month .== 9) .| (month .== 10) .| (month .== 11)
    end

    time_in = time_in[mask_ssn] 
    time_range = time_range[mask_ssn]
    w2_mean, w2_std = w2_mean[mask_ssn], w2_std[mask_ssn]
    flux_mean, flux_std = flux_mean[mask_ssn], flux_std[mask_ssn]
    backscat_mean, backscat_std = backscat_mean[mask_ssn], backscat_std[mask_ssn]
    day, month, year  = day[mask_ssn], month[mask_ssn], year[mask_ssn]
    height = height[mask_ssn]
    
    

    mask_105 = findall(x -> x == 105, height)

    time_in = time_in[mask_105] 
    time_range = time_range[mask_105]
    w2_mean, w2_std = w2_mean[mask_105], w2_std[mask_105]
    flux_mean, flux_std = flux_mean[mask_105], flux_std[mask_105]
    backscat_mean, backscat_std = backscat_mean[mask_105], backscat_std[mask_105]
    day, month, year  = day[mask_105], month[mask_105], year[mask_105]
    height = height[mask_105]
    
    
    output_file_raw = PATH_output_txt * "flux_150_for_season_$(num_season)_RAW_DATA.txt"
    writedlm(output_file_raw, hcat(height, flux_mean, backscat_mean, w2_mean, day, month, year, time_in ))
    println(output_file_raw, " ", length(height))


    step = 60 * 60  # 60 min
    time_in_sec = time_in .* 3600
    time_bins = collect(minimum(time_in_sec):step:maximum(time_in_sec))

    time_avg, back_avg, w2_avg, flux_avg = Float64[], Float64[], Float64[], Float64[]
    back_std, w2_std_avg, flux_std_avg = Float64[], Float64[], Float64[]
    
    flux_mean = replace(flux_mean, "missing" => missing)
    flux_std_avg = replace(flux_std_avg, "missing" => missing)

    count_in_bin = []
    for i in 1:length(time_bins)-1
        idx_time = (time_in_sec .>= time_bins[i]) .& (time_in_sec .< time_bins[i+1])        
        if sum(idx_time) > 0
            push!(time_avg, mean(time_in_sec[idx_time]) / 3600)
            push!(back_avg, mean(backscat_mean[idx_time]))
            push!(back_std, std(backscat_mean[idx_time]))
            push!(w2_avg, mean(w2_mean[idx_time]))
            push!(w2_std_avg, std(w2_mean[idx_time]))
            # println(mean(flux_avg), flux_mean[idx_time])
            push!(flux_avg, mean(skipmissing(flux_mean[idx_time])))
            push!(flux_std_avg, std(skipmissing(flux_mean[idx_time])))
            push!(count_in_bin, count(idx_time))
        end
    end
    data_out = hcat(time_avg, flux_avg, flux_std_avg, count_in_bin)
    writedlm(PATH_output_txt * "flux_105_stats_season_$(num_season).txt", data_out)
    println(PATH_output_txt * "flux_105_stats_season_$(num_season).txt")

end




function datetime_from_ymdhour(y, m, d, hour_float)
    h = floor(Int, hour_float)
    mi = round(Int, (hour_float - h) * 60)
    return DateTime(y, m, d, h, mi)
end

function unique_indices(v::AbstractVector)
    # return indices of first occurrence of each unique element in v
    p = sortperm(v)
    keep = trues(length(v))
    for i in 2:length(p)
        if v[p[i]] == v[p[i-1]]
            keep[p[i]] = false
        end
    end
    return findall(keep)
end

function main_in_details()
    # --- flux info ---
    file_name = PATH_output_txt * "fluxH_MOD_norm_RAW_DATA.txt"
    input_data = readdlm(file_name)

    backscat_mean = input_data[:, 3]
    w2_mean       = input_data[:, 4]
    day           = input_data[:, 5]
    month         = input_data[:, 6]
    year          = input_data[:, 7]
    time_in       = input_data[:, 8]   # hours?
    clouds        = input_data[:, 13]
    f105          = input_data[:, 14]

    # replace "missing" string with missing
    f105 = replace(f105, "missing" => missing)

    # --- Select non-cloudy profiles ---
    mask_nc = (clouds .== -1)
    day     = day[mask_nc]
    month   = month[mask_nc]
    year    = year[mask_nc]
    time_in = time_in[mask_nc]
    f105    = f105[mask_nc]

    # drop missing f105 if needed
    mask_f  = .!ismissing.(f105)
    day, month, year, time_in, f105 = day[mask_f], month[mask_f], year[mask_f], time_in[mask_f], f105[mask_f]
    f105 = Float64.(f105)  # make it numeric

    # --- wind info ---
    output_file_name_w = "wind_surface_MET.txt"
    input_file_w = PATH_output_txt * output_file_name_w
    info_w = readdlm(input_file_w)

    day_w   = info_w[:, 1]
    month_w = info_w[:, 2]
    year_w  = info_w[:, 3]
    time_w  = info_w[:, 4] ./ 3600  # convert s to hours

    # likely: col 5 = speed, col 6 = direction; your code overwrote dir_w
    speed_w = info_w[:, 5]
    println(minimum(speed_w))
    println(maximum(speed_w))

    dir_w   = info_w[:, 6]

    # --- build DateTime for lidar and wind ---
    dt_in = datetime_from_ymdhour.(year, month, day, time_in)
    dt_w  = datetime_from_ymdhour.(year_w, month_w, day_w, time_w)

    # --- keep unique (day, month, year, time_in) ---
    idx_unique = unique_indices(dt_in)
    dt_in_u  = dt_in[idx_unique]
    f105_u   = f105[idx_unique]

    # --- align wind direction to lidar times with ±0.5 h ---
    dir_match = Vector{Union{Missing, Float64}}(undef, length(dt_in_u))
    fill!(dir_match, missing)

    for (k, dt) in pairs(dt_in_u)
        # same calendar day
        same_day_mask = Date.(dt_w) .== Date(dt)
        if !any(same_day_mask)
            continue
        end

        dt_w_same = dt_w[same_day_mask]
        diffs = abs.(dt_w_same .- dt)  # Millisecond
        jrel = argmin(diffs)

        if diffs[jrel] <= Minute(30)   # 0.5 h tolerance
            idxs = findall(same_day_mask)
            dir_match[k] = dir_w[idxs[jrel]]
        end
    end

    # remove points with no matched wind direction
    keep = .!ismissing.(dir_match)
    f105_final = f105_u[keep]
    dir_final  = Float64.(dir_match[keep])

    # now you have f105 vs dir_w
    scatter(dir_final, f105_final ;
        ylabel = L"Flux_{105m} \times 10^6 (s^{-1}sr^{-1})",
        xlabel = L"Wind\ Direction\  (degree)",
        markersize = 4, alpha = 0.05,
        legend = false, ylims =[-5, 510]
    )
    vline!([160]) 
    vline!([180]) 

    # --- binning in 10° intervals and computing means ---
    # treat 360° as 0° so it goes into the first bin
    dir_mod = dir_final .% 360

    bin_width   = 10
    bin_centers = 5:bin_width:355               # 5,15,...,355
    bin_means   = similar(collect(bin_centers), Float64)

    for (i, c) in enumerate(bin_centers)
        # bin = [center-5, center+5)
        mask = (dir_mod .>= c - bin_width/2) .& (dir_mod .< c + bin_width/2)
        if any(mask)
            bin_means[i] = mean(f105_final[mask])
        else
            bin_means[i] = NaN   # no data in this bin → will not show in plot
        end
    end

    # overlay binned mean as a line with points
    plot!(bin_centers, bin_means;
        lw = 2,
        marker = :o,
        alpha = 0.9,
        label = nothing,
    )

    # save figure
    savefig(PATH_output_png*"f105_vs_dirw.png")
end

function main_in_details_heatmap()
    # --- flux info ---
    file_name = PATH_output_txt * "fluxH_MOD_norm_RAW_DATA.txt"
    input_data = readdlm(file_name)

    backscat_mean = input_data[:, 3]
    w2_mean       = input_data[:, 4]
    day           = input_data[:, 5]
    month         = input_data[:, 6]
    year          = input_data[:, 7]
    time_in       = input_data[:, 8]   # hours
    clouds        = input_data[:, 13]
    f105          = input_data[:, 14]

    # replace "missing" string with missing
    f105 = replace(f105, "missing" => missing)

    # --- Select non-cloudy profiles ---
    mask_nc = (clouds .== -1)
    day     = day[mask_nc]
    month   = month[mask_nc]
    year    = year[mask_nc]
    time_in = time_in[mask_nc]
    f105    = f105[mask_nc]

    # drop missing f105
    mask_f  = .!ismissing.(f105)
    day, month, year, time_in, f105 = day[mask_f], month[mask_f], year[mask_f], time_in[mask_f], f105[mask_f]
    f105 = Float64.(f105)  # make it numeric

    # --- wind info ---
    output_file_name_w = "wind_surface_MET.txt"
    input_file_w = PATH_output_txt * output_file_name_w
    info_w = readdlm(input_file_w)

    day_w   = info_w[:, 1]
    month_w = info_w[:, 2]
    year_w  = info_w[:, 3]
    time_w  = info_w[:, 4] ./ 3600  # convert s to hours
    speed_w = info_w[:, 5]
    dir_w   = info_w[:, 6]

    # --- build DateTime for lidar and wind ---
    dt_in = datetime_from_ymdhour.(year, month, day, time_in)
    dt_w  = datetime_from_ymdhour.(year_w, month_w, day_w, time_w)

    # --- keep unique (day, month, year, time_in) ---
    idx_unique = unique_indices(dt_in)
    dt_in_u  = dt_in[idx_unique]
    f105_u   = f105[idx_unique]

    # --- align wind direction & speed to lidar times with ±0.5 h ---
    dir_match   = Vector{Union{Missing, Float64}}(undef, length(dt_in_u))
    speed_match = Vector{Union{Missing, Float64}}(undef, length(dt_in_u))
    fill!(dir_match,   missing)
    fill!(speed_match, missing)

    for (k, dt) in pairs(dt_in_u)
        # same calendar day
        same_day_mask = Date.(dt_w) .== Date(dt)
        if !any(same_day_mask)
            continue
        end

        dt_w_same = dt_w[same_day_mask]
        diffs = abs.(dt_w_same .- dt)  # Millisecond
        jrel = argmin(diffs)

        if diffs[jrel] <= Minute(30)   # 0.5 h tolerance
            idxs = findall(same_day_mask)
            idx  = idxs[jrel]
            dir_match[k]   = dir_w[idx]
            speed_match[k] = speed_w[idx]
        end
    end

    # remove points with no matched wind direction/speed
    keep = .!ismissing.(dir_match) .& .!ismissing.(speed_match)
    f105_final  = f105_u[keep]
    dir_final   = Float64.(dir_match[keep])
    speed_final = Float64.(speed_match[keep])

    # ---------------------- 1) Scatter + binned mean ----------------------
    plt1 = scatter(dir_final, f105_final;
        ylabel = L"Flux_{105m} \times 10^6 (s^{-1}sr^{-1})",
        xlabel = L"Wind\ Direction\ (degree)",
        markersize = 4, alpha = 0.05,
        legend = false, ylims = [-5, 510]
    )
    vline!([160])
    vline!([180])

    # --- binning in 10° intervals and computing means ---
    dir_mod = dir_final .% 360
    bin_width   = 10
    bin_centers = 5:bin_width:355               # 5,15,...,355
    bin_means   = similar(collect(bin_centers), Float64)

    for (i, c) in enumerate(bin_centers)
        # bin = [center-5, center+5)
        mask = (dir_mod .>= c - bin_width/2) .& (dir_mod .< c + bin_width/2)
        if any(mask)
            bin_means[i] = mean(f105_final[mask])
        else
            bin_means[i] = NaN   # no data in this bin → will not show in plot
        end
    end

    plot!(bin_centers, bin_means;
        lw = 2,
        marker = :o,
        alpha = 0.9,
        label = nothing,
    )

    savefig(PATH_output_png * "f105_vs_dirw.png")

    # ---------------------- 2) Heatmap (speed × direction) ----------------------
    # Wrap direction to [0, 360)
    dir_mod = dir_final .% 360

    # Direction bins: 0–5, 5–10, ..., 355–360
    dir_step  = 5.0
    dir_edges = 0:dir_step:360
    dir_centers = (dir_edges[1:end-1] .+ dir_edges[2:end]) ./ 2

    # Speed bins: 0.5 m/s
    speed_step = 0.5
    smin = floor(minimum(speed_final) / speed_step) * speed_step
    smax = ceil(maximum(speed_final) / speed_step) * speed_step
    speed_edges = smin:speed_step:smax
    speed_centers = (speed_edges[1:end-1] .+ speed_edges[2:end]) ./ 2

    # Matrix: rows = direction bins (y), cols = speed bins (x)
    Z = fill(NaN, length(dir_centers), length(speed_centers))

    for (j, _) in enumerate(dir_centers)      # direction bins
        dmask = (dir_mod .>= dir_edges[j]) .& (dir_mod .< dir_edges[j+1])
        for (i, _) in enumerate(speed_centers)  # speed bins
            smask = (speed_final .>= speed_edges[i]) .& (speed_final .< speed_edges[i+1])
            mask = dmask .& smask
            if any(mask)
                Z[j, i] = mean(f105_final[mask])
            end
        end
    end

    plt2 = heatmap(speed_centers, dir_centers, Z;
        xlabel = L"Wind\ speed\ (m\,s^{-1})",
        ylabel = L"Wind\ direction\ (degree)",
        colorbar_title = L"\overline{Flux_{105m}} \times 10^6\ (s^{-1}sr^{-1})",
        ylims = (0, 360), xlims = (0, 18),
        framestyle = :box,
    )

    savefig(PATH_output_png * "f105_dir_speed_heatmap.png")

end


# plot_for_season(1)
# plot_for_season(2)
# plot_for_season(3)
# plot_for_season(4)


# flag_condition = "nonclean"
# flag_stability = "neutral"
main()      #speed  
# main_dir()  #direction 



# main_in_details()

# main_in_details_heatmap()
