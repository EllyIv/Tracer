using Glob  # for globbing the file patterns
using CSV   # for reading CSV files
using Plots # for plotting
using Colors # for color normalization
using NCDatasets # for NetCDF
using Dates  # to convert dates in sec
using Statistics # for mean
using Dierckx     # For detrend (spline interpolation)
using Polynomials
using StatsBase 
using DSP  
using DelimitedFiles
using Measures
using LaTeXStrings
using Interpolations
using LsqFit #for curve fitting 
using LaTeXStrings
using GLM
using DataFrames
using StatsModels
using ColorSchemes
include("../paths_for_all.jl")

# const PATH_output_png = "/home/ellai/test_arm_data/flux_calc/VER6/output_png/"
# const PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER6/output_txt/"


function define_belly(set_f, set_h)
    set_f = replace(set_f, "missing" => missing)

    mask_h = findall(h->h<0.7, set_h)
    set_f = set_f[mask_h]
    set_h = set_h[mask_h]

    # println(set_f) 
    # println(size(set_h) )
    # Step 2: Find the best 4-element subset with the maximum sum
    max_sum = -Inf
    best_index = -1
    for i in 1:(length(set_f) - 3)  # Ensure at least 4 elements exist
        current_sum = sum(set_f[i:i+3])
        if  !ismissing(current_sum)
            if current_sum > max_sum 
                max_sum = current_sum
                best_index = i  # Store the starting index of the best group
            end
        end
    end    

    # Extract the best 4-element set
    # println(best_index, " ", size(set_f))
    if best_index != -1 
        best_set_f = set_f[best_index:best_index+3]
        best_set_h = set_h[best_index:best_index+3]

        # Step 3: Create overlapping pairs
        pairs = [(best_set_f[i], best_set_f[i+1]) for i in 1:3]  # (1,2), (2,3), (3,4)

        # Step 4: Compute means and errors
        min_error = Inf
        best_pair = nothing
        best_mean = nothing

        for p in pairs
            mean_val = mean(p)  # Mean of the pair
            error = abs(p[1] - p[2])  # Error as absolute difference
            
            if error < min_error
                min_error = error
                best_pair = p
                best_mean = mean_val
            end
        end

        # Step 5: Find corresponding h value using the closest f in best_set_f
        closest_index = argmin(abs.(best_set_f .- best_mean))  # Find index of closest value
        best_h = best_set_h[closest_index]  # Corresponding h value
        return best_mean, best_h
    else 
        return missing, missing 
    end 
end


function find_ave_and_max(flux, height)
    ave_f_data = []
    nbins = 100
    h_edges = range(0, 2; length=nbins+1)
    h_centers = (h_edges[1:end-1] .+ h_edges[2:end]) ./ 2

    for i in 1:nbins
        inds = findall(h -> h_edges[i] ≤ h < h_edges[i+1], skipmissing(height))
        if !isempty(inds)
            flux_vals = flux[inds]
            valid_flux = collect(skipmissing(flux_vals))
            if !isempty(valid_flux)
                push!(ave_f_data, mean(valid_flux))
            else
                push!(ave_f_data, missing)
            end
        else
            push!(ave_f_data, missing)
        end
    end

    return define_belly(ave_f_data, h_centers)
end

function main()

    # --- Define season colors from Viridis
    SEASON_COLORS = Dict(
        "winter" => get(ColorSchemes.viridis, 0.1),
        "spring" => get(ColorSchemes.viridis, 0.4),
        "summer" => get(ColorSchemes.viridis, 0.7),
        "fall"   => get(ColorSchemes.viridis, 0.9)
    )

    # --- Read data
    file_name = PATH_output_txt * "fluxH_MOD_norm_RAW_DATA.txt"
    input_data = readdlm(file_name)

    height = input_data[:, 1]
    flux_mean = input_data[:, 2]
    backscat_mean = input_data[:, 3]
    w2_mean = input_data[:, 4]
    day, month, year = input_data[:, 5], input_data[:, 6], input_data[:, 7]
    time_in = input_data[:, 8]
    number_of_the_profile = input_data[:, 9]
    clouds = input_data[:, 13]
    f105 = input_data[:, 14]

    flux_mean = replace(flux_mean, "missing" => missing)
    height = replace(height, "missing" => missing)
    f105 = replace(f105, "missing" => missing)

    # --- Select non-cloudy profiles
    mask_nc = (clouds .== -1)
    month = month[mask_nc]
    flux_mean = flux_mean[mask_nc]
    height = height[mask_nc]
    number_of_the_profile = number_of_the_profile[mask_nc]
    f105 = f105[mask_nc]

    # --- Define seasons
    SEASONS = [
        ("winter", [12, 1, 2]),
        ("spring", [3, 4, 5]),
        ("summer", [6, 7, 8]),
        ("fall",   [9, 10, 11])
    ]

    # --- Create 4-panel figure
    p = plot(
        layout=(1, 4), size=(1600, 400),
        left_margin=10mm, right_margin=5mm, bottom_margin=13mm, top_margin=5mm,
        xguidefont=18, yguidefont=18, xtickfont=font(12), ytickfont=font(12),
        legend=false
    )

    println("\nSlope and R² per season (linear fit):")

    for (idx, (season, months_s)) in enumerate(SEASONS)
        # Filter season data
        mask_s = in.(month, Ref(months_s))
        flux_s = flux_mean[mask_s]
        height_s = height[mask_s]
        prof_s = number_of_the_profile[mask_s]
        f105_s = f105[mask_s]

        unique_profiles = unique(prof_s)
        fmax_list, f105_list = Float64[], Float64[]

        # --- For each profile in the season
        for prof in unique_profiles
            mask_p = (prof_s .== prof)
            flux_p = flux_s[mask_p]
            height_p = height_s[mask_p]
            f105_p = f105_s[mask_p]

            f_max, h_max = find_ave_and_max(flux_p, height_p)
            valid_f105 = collect(skipmissing(f105_p))

            if !ismissing(f_max) && !isempty(valid_f105)
                push!(fmax_list, f_max)
                push!(f105_list, mean(valid_f105))
            end
        end

        if length(fmax_list) ≤ 2
            println("  $season → insufficient data")
            continue
        end

        color = SEASON_COLORS[season]

        # --- Linear regression (y = a*x + b)
        X = hcat(ones(length(fmax_list)), fmax_list)
        coeffs = X \ f105_list
        b, a = coeffs[1], coeffs[2]
        fit_line(x) = a * x + b

        # --- Compute R²
        y_pred = fit_line.(fmax_list)
        ss_res = sum((f105_list .- y_pred).^2)
        ss_tot = sum((f105_list .- mean(f105_list)).^2)
        r2_lin = 1 - ss_res / ss_tot
        n_s = length(fmax_list)

        println("  $season → slope = $(round(a, digits=3)), R² = $(round(r2_lin, digits=3)), n = $n_s")

        # --- Plot points and trend
        scatter!(p[idx], fmax_list, f105_list,
                 color=:gray, alpha=0.5, markersize=4, markerstrokewidth=0, label="")

        x_fit = range(0, stop=500, length=100)
        plot!(p[idx], x_fit, fit_line.(x_fit),
              color=color, linewidth=2, label="")

        # --- Axes and titles
        title!(p[idx], season, fontsize=16)
        xlabel!(p[idx], L"F_{max} \ (cm^{-2}\ s^{-1})")
        ylabel!(p[idx], idx == 1 ? L"F_{105}  \ (cm^{-2}\ s^{-1})" : "")
        xlims!(p[idx], (0, 500))
        ylims!(p[idx], (0, 300))
    end

    savefig(PATH_output_png * "fmax_vs_f105_seasons.png")
    println("\nSaved: ", PATH_output_png * "fmax_vs_f105_seasons.png")
end

function main_entire_campaign()
    # --- Read data ---
    file_name = PATH_output_txt * "fluxH_MOD_norm_RAW_DATA.txt"
    input_data = readdlm(file_name)

    height = input_data[:, 1]
    flux_mean = input_data[:, 2]
    backscat_mean = input_data[:, 3]
    w2_mean = input_data[:, 4]
    day, month, year = input_data[:, 5], input_data[:, 6], input_data[:, 7]
    time_in = input_data[:, 8]
    number_of_the_profile = input_data[:, 9]
    clouds = input_data[:, 13]
    f105 = input_data[:, 14]

    flux_mean = replace(flux_mean, "missing" => missing)
    height = replace(height, "missing" => missing)
    f105 = replace(f105, "missing" => missing)

    # --- Select non-cloudy profiles ---
    mask_nc = (clouds .== -1)
    flux_mean = flux_mean[mask_nc]
    height = height[mask_nc]
    number_of_the_profile = number_of_the_profile[mask_nc]
    f105 = f105[mask_nc]

    # --- Prepare data containers ---
    unique_profiles = unique(number_of_the_profile)
    fmax_list, f105_list = Float64[], Float64[]

    # --- Loop over all profiles ---
    for prof in unique_profiles
        mask_p = (number_of_the_profile .== prof)
        flux_p = flux_mean[mask_p]
        height_p = height[mask_p]
        f105_p = f105[mask_p]

        f_max, h_max = find_ave_and_max(flux_p, height_p)
        valid_f105 = collect(skipmissing(f105_p))

        if !ismissing(f_max) && !isempty(valid_f105)
            push!(fmax_list, f_max)
            push!(f105_list, mean(valid_f105))
        end
    end

    # --- Skip if not enough data ---
    if length(fmax_list) ≤ 2
        println("⚠️ Not enough data for regression")
        return
    end

    # --- Linear regression (y = a*x + b) ---
    X = hcat(ones(length(fmax_list)), fmax_list)
    coeffs = X \ f105_list
    b, a = coeffs[1], coeffs[2]
    fit_line(x) = a * x + b

    # --- Compute R² ---
    y_pred = fit_line.(fmax_list)
    ss_res = sum((f105_list .- y_pred).^2)
    ss_tot = sum((f105_list .- mean(f105_list)).^2)
    r2_lin = 1 - ss_res / ss_tot
    n_total = length(fmax_list)

    println("Entire campaign → slope = $(round(a, digits=3)), R² = $(round(r2_lin, digits=3)), n = $n_total")

    # --- Plot all points and fit ---
    p = scatter(fmax_list, f105_list,
                color=:gray, alpha=0.5, markersize=4,
                xlabel=L"F_{max} \times 10^6 (s^{-1}\ sr^{-1})", ylabel=L"F_{105} \times 10^6 (s^{-1}\ sr^{-1})",
                label="",
                xlims=(0, 500), ylims=(0, 300))

    x_fit = range(0, stop=500, length=100)
    plot!(p, x_fit, fit_line.(x_fit),
          color=:blue, linewidth=2, label="")

    # --- Save ---
    savefig(PATH_output_png * "fmax_vs_f105_campaign.png")
    println(PATH_output_png * "fmax_vs_f105_campaign.png")
end


function main_month()

    # --- Define colors from Viridis for 12 months
    MONTH_COLORS = Dict(
        1  => get(ColorSchemes.viridis, 0.05),
        2  => get(ColorSchemes.viridis, 0.12),
        3  => get(ColorSchemes.viridis, 0.20),
        4  => get(ColorSchemes.viridis, 0.30),
        5  => get(ColorSchemes.viridis, 0.40),
        6  => get(ColorSchemes.viridis, 0.50),
        7  => get(ColorSchemes.viridis, 0.60),
        8  => get(ColorSchemes.viridis, 0.70),
        9  => get(ColorSchemes.viridis, 0.78),
        10 => get(ColorSchemes.viridis, 0.85),
        11 => get(ColorSchemes.viridis, 0.92),
        12 => get(ColorSchemes.viridis, 0.98)
    )

    # --- Read data
    file_name = PATH_output_txt * "fluxH_MOD_norm_RAW_DATA.txt"
    input_data = readdlm(file_name)

    height = input_data[:, 1]
    flux_mean = input_data[:, 2]
    backscat_mean = input_data[:, 3]
    w2_mean = input_data[:, 4]
    day, month, year = input_data[:, 5], input_data[:, 6], input_data[:, 7]
    time_in = input_data[:, 8]
    number_of_the_profile = input_data[:, 9]
    clouds = input_data[:, 13]
    f105 = input_data[:, 14]

    flux_mean = replace(flux_mean, "missing" => missing)
    height = replace(height, "missing" => missing)
    f105 = replace(f105, "missing" => missing)

    # --- Select non-cloudy profiles
    mask_nc = (clouds .== -1)
    month = month[mask_nc]
    flux_mean = flux_mean[mask_nc]
    height = height[mask_nc]
    number_of_the_profile = number_of_the_profile[mask_nc]
    f105 = f105[mask_nc]

    # --- Create 3x4 figure layout
    p = plot(
        layout=(4, 3), size=(1200, 1600),
        left_margin=10mm, right_margin=5mm, bottom_margin=10mm, top_margin=5mm,
        xguidefont=16, yguidefont=16, xtickfont=font(10), ytickfont=font(10),
        legend=false
    )

    println("\nSlope and R² per month (linear fit, F105 ~ Fmax):")

    # --- Loop through all 12 months
    for m in 1:12
        mask_m = (month .== m)
        flux_m = flux_mean[mask_m]
        height_m = height[mask_m]
        prof_m = number_of_the_profile[mask_m]
        f105_m = f105[mask_m]

        unique_profiles = unique(prof_m)
        fmax_list, f105_list = Float64[], Float64[]

        # --- For each profile in the month
        for prof in unique_profiles
            mask_p = (prof_m .== prof)
            flux_p = flux_m[mask_p]
            height_p = height_m[mask_p]
            f105_p = f105_m[mask_p]

            f_max, h_max = find_ave_and_max(flux_p, height_p)
            valid_f105 = collect(skipmissing(f105_p))

            if !ismissing(f_max) && !isempty(valid_f105)
                push!(fmax_list, f_max)
                push!(f105_list, mean(valid_f105))
            end
        end

        if length(fmax_list) ≤ 2
            println("  Month $m → insufficient data")
            continue
        end

        color = MONTH_COLORS[m]

        # --- Linear regression (y = a*x + b)
        X = hcat(ones(length(fmax_list)), fmax_list)
        coeffs = X \ f105_list
        b, a = coeffs[1], coeffs[2]
        fit_line(x) = a * x + b

        # --- Compute R²
        y_pred = fit_line.(fmax_list)
        ss_res = sum((f105_list .- y_pred).^2)
        ss_tot = sum((f105_list .- mean(f105_list)).^2)
        r2_lin = 1 - ss_res / ss_tot
        n_m = length(fmax_list)

        println("  Month $m → slope = $(round(a, digits=3)), R² = $(round(r2_lin, digits=3)), n = $n_m")

        # --- Plot
        scatter!(p[m], fmax_list, f105_list,
                 color=:gray, alpha=0.5, markersize=4, markerstrokewidth=0, label="")
        x_fit = range(0, stop=500, length=100)
        plot!(p[m], x_fit, fit_line.(x_fit), color=color, linewidth=2, label="")

        title!(p[m], "Month $m", fontsize=12)
        xlabel!(p[m], L"F_{max}")
        ylabel!(p[m], L"F_{105}")
        xlims!(p[m], (0, 500))
        ylims!(p[m], (0, 300))
    end

    savefig(PATH_output_png * "fmax_vs_f105_months.png")
    println(PATH_output_png * "fmax_vs_f105_months.png")
end


function main_entire_campaign_hmax_vs_pbl()

    # --- Read flux data ---
    file_flux = PATH_output_txt * "fluxH_MOD_norm_RAW_DATA.txt"
    data = readdlm(file_flux)

    height  = replace(data[:, 1], "missing" => missing)
    flux    = replace(data[:, 2], "missing" => missing)
    day     = data[:, 5]
    month   = data[:, 6]
    year    = data[:, 7]
    time    = data[:, 8] .* 3600        # seconds
    prof_id = data[:, 9]
    clouds  = data[:, 13]

    # --- Only non-cloudy profiles ---
    mask_nc = (clouds .== -1)
    height  = height[mask_nc]
    flux    = flux[mask_nc]
    day     = day[mask_nc]
    month   = month[mask_nc]
    year    = year[mask_nc]
    time    = time[mask_nc]
    prof_id = prof_id[mask_nc]

    # --- Load PBL file ---
    file_pbl = PATH_output_txt * "pbl_aligned_with_lidar_filtered.txt"
    pbl_data = readdlm(file_pbl)

    pbl_day   = pbl_data[:,1]
    pbl_month = pbl_data[:,2]
    pbl_year  = pbl_data[:,3]
    pbl_time  = pbl_data[:,4]           # already in seconds
    pbl_val   = pbl_data[:,5] |> x -> replace(x, "missing" => missing)

    # --- Prepare arrays ---
    hmax_list = Float64[]
    ratio_list = Float64[]

    # Unique flux profiles
    profiles = unique(prof_id)

    for pid in profiles

        mask = (prof_id .== pid)
        flux_p  = flux[mask]
        height_p = height[mask]

        d = day[mask][1]
        m = month[mask][1]
        y = year[mask][1]
        t = time[mask][1]

        # 1) Find flux belly
        fmax, hmax = find_ave_and_max(flux_p, height_p)
        if ismissing(fmax)
            continue
        end

        # 2) Find matching PBL (same day, ±100 s)
        mask_pbl = (pbl_day .== d) .& (pbl_month .== m) .&
                   (pbl_year .== y) .& (abs.(pbl_time .- t) .<= 100)

        if !any(mask_pbl)
            continue
        end

        pbl_vals = collect(skipmissing(pbl_val[mask_pbl]))
        if isempty(pbl_vals)
            continue
        end

        pbl_mean = mean(pbl_vals)
        ratio = 105 / pbl_mean

        push!(hmax_list, hmax)
        push!(ratio_list, ratio)
    end

    # --- Regression ---
    X = hcat(ones(length(hmax_list)), hmax_list)
    coeffs = X \ ratio_list
    b, a = coeffs[1], coeffs[2]
    fit(x) = a*x + b

    # --- R² ---
    y_pred = fit.(hmax_list)
    ss_res = sum((ratio_list .- y_pred).^2)
    ss_tot = sum((ratio_list .- mean(ratio_list)).^2)
    r2 = 1 - ss_res/ss_tot

    println("slope = $(round(a,digits=3)), R² = $(round(r2,digits=3)), n=$(length(hmax_list))")

    # --- Plot ---
    p = scatter(hmax_list, ratio_list,
                color=:gray, alpha=0.5, ms=4,
                xlabel=L"h_{\max}", ylabel=L"105/PBL",
                label="")

    xfit = range(minimum(hmax_list), stop=maximum(hmax_list), length=100)
    plot!(p, xfit, fit.(xfit), color=:blue, lw=2, label="")

    savefig(PATH_output_png * "hmax_vs_pbl_ratio.png")
    println(PATH_output_png * "hmax_vs_pbl_ratio.png")
end

function main_entire_campaign_hmax_vs_pbl_ave_over_season()

    # --- Read flux data ---
    file_flux = PATH_output_txt * "fluxH_MOD_norm_RAW_DATA.txt"
    data = readdlm(file_flux)

    height  = replace(data[:, 1], "missing" => missing)
    flux    = replace(data[:, 2], "missing" => missing)
    day     = data[:, 5]
    month   = data[:, 6]
    year    = data[:, 7]
    time    = data[:, 8] .* 3600
    prof_id = data[:, 9]
    clouds  = data[:, 13]

    # --- Only non-cloudy profiles ---
    mask_nc = (clouds .== -1)
    height  = height[mask_nc]
    flux    = flux[mask_nc]
    day     = day[mask_nc]
    month   = month[mask_nc]
    year    = year[mask_nc]
    time    = time[mask_nc]
    prof_id = prof_id[mask_nc]

    # --- Load PBL file ---
    file_pbl = PATH_output_txt * "pbl_aligned_with_lidar_filtered.txt"
    pbl_data = readdlm(file_pbl)

    pbl_day   = pbl_data[:,1]
    pbl_month = pbl_data[:,2]
    pbl_year  = pbl_data[:,3]
    pbl_time  = pbl_data[:,4]
    pbl_val   = replace(pbl_data[:,5], "missing" => missing)

    # --- Prepare arrays ---
    hmax_list  = Float64[]
    ratio_list = Float64[]
    month_full = Int[]

    profiles = unique(prof_id)

    for pid in profiles
        mask = (prof_id .== pid)
        flux_p  = flux[mask]
        height_p = height[mask]

        d = day[mask][1]
        m = month[mask][1]
        y = year[mask][1]
        t = time[mask][1]

        # --- Find flux belly ---
        fmax, hmax = find_ave_and_max(flux_p, height_p)
        if ismissing(fmax)
            continue
        end

        # --- Match PBL ---
        mask_pbl = (pbl_day .== d) .& (pbl_month .== m) .&
                   (pbl_year .== y) .& (abs.(pbl_time .- t) .<= 100)

        if !any(mask_pbl)
            continue
        end

        vals = collect(skipmissing(pbl_val[mask_pbl]))
        if isempty(vals)
            continue
        end

        pbl_m = mean(vals)
        ratio = 105 / pbl_m

        push!(hmax_list, hmax)
        push!(ratio_list, ratio)
        push!(month_full, m)
    end

    # --- Linear regression ---
    X = hcat(ones(length(hmax_list)), hmax_list)
    coeffs = X \ ratio_list
    b, a = coeffs[1], coeffs[2]
    fit(x) = a*x + b

    y_pred = fit.(hmax_list)
    ss_res = sum((ratio_list .- y_pred).^2)
    ss_tot = sum((ratio_list .- mean(ratio_list)).^2)
    r2 = 1 - ss_res/ss_tot

    # println("slope = $(round(a,3)), R² = $(round(r2,3)), n=$(length(hmax_list)))")

    # ---------------------------
    # Seasonal means
    # ---------------------------
    season = [(m in (12,1,2)) ? :winter :
              (m in (3,4,5)) ? :spring :
              (m in (6,7,8)) ? :summer : :fall  for m in month_full]

    season_groups = Dict(
        :winter => (Float64[], Float64[]),
        :spring => (Float64[], Float64[]),
        :summer => (Float64[], Float64[]),
        :fall   => (Float64[], Float64[])
    )

    for i in eachindex(hmax_list)
        push!(season_groups[season[i]][1], hmax_list[i])
        push!(season_groups[season[i]][2], ratio_list[i])
    end

    season_means = Dict()
    for (s,(x,y)) in season_groups
        if !isempty(x)
            season_means[s] = (mean(x), mean(y))
        end
    end

    # --- Plot ---
    p = scatter(hmax_list, ratio_list,
                color=:gray, alpha=0.4, ms=4,
                xlabel=L"H_{\max}/H_{PBL} ", ylabel=L"105/H_{PBL}",
                label="", xlims =[ 0,1], ylims = [0, 0.1])

    # Regression line
    xfit = range(minimum(hmax_list), stop=maximum(hmax_list), length=100)
    # plot!(p, xfit, fit.(xfit), color=:blue, lw=2, label="")

    # --- Seasonal average dots ---
    # colors = Dict(:winter=>:blue, :spring=>:green, :summer=>:orange, :fall=>:red)
    cmap = cgrad(:viridis)
    colors = Dict(
    :winter => cmap[0.1],
    :spring => cmap[0.35],
    :summer => cmap[0.6],
    :fall   => cmap[0.85])
    # colors = Dict(:winter=>:blue, :spring=>:green, :summer=>:orange, :fall=>:red)
    println(mean([4.487, 3.282, 4.965, 3.968]))
    for s in keys(season_means)
        xm, ym = season_means[s]
        scatter!(p, [xm], [ym], color=colors[s], markersize=10,
                 markerstrokecolor=:black, label=string(s))
        println([xm], " ", [ym], " ", xm/ym)
    end

    savefig(PATH_output_png * "hmax_vs_pbl_ratio_season.png")
    println(PATH_output_png * "hmax_vs_pbl_ratio_season.png")

end

using ColorSchemes

function main_entire_campaign_ave_over_season()

    # --- Read data ---
    file_name = PATH_output_txt * "fluxH_MOD_norm_RAW_DATA.txt"
    input_data = readdlm(file_name)

    height = input_data[:, 1]
    flux_mean = input_data[:, 2]
    backscat_mean = input_data[:, 3]
    w2_mean = input_data[:, 4]
    day, month, year = input_data[:, 5], input_data[:, 6], input_data[:, 7]
    time_in = input_data[:, 8]
    number_of_the_profile = input_data[:, 9]
    clouds = input_data[:, 13]
    f105 = input_data[:, 14]

    flux_mean = replace(flux_mean, "missing" => missing)
    height = replace(height, "missing" => missing)
    f105 = replace(f105, "missing" => missing)

    # --- Select non-cloudy profiles ---
    mask_nc = (clouds .== -1)
    flux_mean = flux_mean[mask_nc]
    height = height[mask_nc]
    number_of_the_profile = number_of_the_profile[mask_nc]
    f105 = f105[mask_nc]
    day = day[mask_nc]
    month = month[mask_nc]

    # --- Prepare containers ---
    unique_profiles = unique(number_of_the_profile)
    fmax_list, f105_list = Float64[], Float64[]
    season_list = Symbol[]

    # --- Helper for seasons ---
    season(m) = m in (12,1,2)  ? :winter :
                m in 3:5      ? :spring :
                m in 6:8      ? :summer : :fall

    # --- Loop over all profiles ---
    for prof in unique_profiles
        mask_p = (number_of_the_profile .== prof)
        flux_p = flux_mean[mask_p]
        height_p = height[mask_p]
        f105_p = f105[mask_p]
        month_p = month[mask_p][1]

        f_max, h_max = find_ave_and_max(flux_p, height_p)
        valid_f105 = collect(skipmissing(f105_p))

        if !ismissing(f_max) && !isempty(valid_f105)
            push!(fmax_list, f_max)
            push!(f105_list, mean(valid_f105))
            push!(season_list, season(month_p))
        end
    end

    # --- Not enough data? ---
    if length(fmax_list) ≤ 2
        println("⚠️ Not enough data for regression")
        return
    end

    # --- Linear regression ---
    X = hcat(ones(length(fmax_list)), fmax_list)
    coeffs = X \ f105_list
    b, a = coeffs[1], coeffs[2]
    fit_line(x) = a * x + b

    # --- R² ---
    y_pred = fit_line.(fmax_list)
    ss_res = sum((f105_list .- y_pred).^2)
    ss_tot = sum((f105_list .- mean(f105_list)).^2)
    r2_lin = 1 - ss_res / ss_tot
    n_total = length(fmax_list)

    println("Entire campaign → slope = $(round(a, digits=3)), R² = $(round(r2_lin, digits=3)), n = $n_total")

    # --- Viridis colors for seasons ---
    vir = ColorSchemes.viridis
    season_colors = Dict(
        :winter => vir[0.10],
        :spring => vir[0.35],
        :summer => vir[0.60],
        :fall   => vir[0.85]
    )

    # --- Plot all points colored by season ---
    p = scatter(fmax_list, f105_list,
                group=season_list,
                color=:grey,
                alpha=0.2, markersize=4,
                xlabel=L"F_{max} \times 10^6 (s^{-1}\ sr^{-1})",
                ylabel=L"F_{105} \times 10^6 (s^{-1}\ sr^{-1})",
                label="",
                xlims=(0, 500), ylims=(0, 300))

    # --- Regression line ---
    x_fit = range(0, stop=500, length=100)
    # plot!(p, x_fit, fit_line.(x_fit),
    #       color=:black, linewidth=2, label="")

    # --- Seasonal averages plotted as big dots ---
    for s in [:winter, :spring, :summer, :fall]
        mask_s = (season_list .== s)
        if any(mask_s)
            xm = mean(fmax_list[mask_s])
            ym = mean(f105_list[mask_s])
            scatter!(p, [xm], [ym], 
                     markersize=10, 
                     color=season_colors[s], 
                     markerstrokecolor=:black,
                     label=string(s))
            println([xm], " ", [ym], " ", xm/ym)
            
        end
    end
    println(mean([4.9, 2.3,4.2, 4.4]))

    # --- Save ---
    savefig(PATH_output_png * "fmax_vs_f105_campaign_season.png")
    println(PATH_output_png * "fmax_vs_f105_campaign_season.png")
end




main()
# main_month()
# main_entire_campaign()
# main_entire_campaign_hmax_vs_pbl()
# main_entire_campaign_hmax_vs_pbl_ave_over_season()
# main_entire_campaign_ave_over_season()
