
using Glob  # for globbing the file patterns
using CSV   # for reading CSV files
using Plots # for plotting
using Colors # for color normalization
using NCDatasets # for NetCDF
using Dates  # to convert dates in sec
using Statistics # for mean
using Dierckx     # For detrend (spline interpolation)
using Polynomials
using StatsBase 
using DSP  
using DelimitedFiles
using Measures
using LaTeXStrings
using Interpolations
using LsqFit #for curve fitting 
using LaTeXStrings

include("../paths_for_all.jl")


function calc_flux_corr(corr_factor, flux_mean)
    # println(corr_factor)
    corr_factor = [x == "missing" ? missing : x for x in corr_factor]
    # flux_mean = [x == "missing" ? missing : x for x in flux_mean]

   
    flux_corr = Vector{Union{Missing, Float64}}(undef, length(flux_mean))
    for i in eachindex(flux_mean)
        if flux_mean[i] === missing || corr_factor[i] === missing 
            flux_corr[i] = missing
        else
            flux_corr[i] = flux_mean[i] * corr_factor[i]
        end
    end
    # println(flux_corr)
    # sleep(100)
    return  flux_corr
end 


function  corrected_flux(time_l, day_l, month_l, year_l, flux_l, flux_std, w2_l, w2_std, beta_l, backscat_std, h_l, calib_info, time_range)
    day_c, month_c, year_c, time_c, h_c, rh_c, int_vals_c, slp_vals_c = calib_info[:,1], calib_info[:,2], calib_info[:,3], calib_info[:,4], calib_info[:,5], calib_info[:,6], calib_info[:,7], calib_info[:,8]
    day_new, month_new, year_new, time_new, height_new, flux_new, beta_new, w2_new = [], [], [], [] , [], [], [] , []
    flux_std_new, beta_std_new, w2_std_new = [], [], []
    time_range_new = []

    rh_new = []
    # println(flux_l[1:10])
    # println(time_c[1:10])
    # println(int_vals_c[1:10])

    time_l = time_l ./ 3600
    # println(time_c[1:5]," ",  time_l[1:5])
    # sleep(100)
    for i in 1:length(time_l)
        d, m, y, t, h = day_l[i], month_l[i], year_l[i], time_l[i], h_l[i]

        # filter calibration data for the same datetime

        mask = (day_c .== d) .& (month_c .== m) .& (year_c .== y) .& (time_c .== t)
        h_c_sub = h_c[mask]
        int_sub = slp_vals_c[mask]
        rh_c_sub = rh_c[mask]
        if !isempty(h_c_sub) 
            diffs = abs.(h_c_sub .- h)

            idx1 = argmin(diffs)
            diffs[idx1] = Inf
            idx2 = argmin(diffs)

            h1, h2 = h_c_sub[idx1], h_c_sub[idx2]
            v1, v2 = int_sub[idx1], int_sub[idx2]
            rh1, rh2 = rh_c_sub[idx1], rh_c_sub[idx2]
            # println(h1,h2 )
            # sleep(100)
            # Linear interpolation
            if h1 == h2
                int_val = v1
                int_rh = rh1
            else
                int_val = v1 + (v2 - v1) * (h - h1) / (h2 - h1)
                int_rh = rh1 + (rh2 - rh1) * (h - h1) / (h2 - h1)
            end
             
            
            push!(day_new, day_l[i])
            push!(month_new, month_l[i])
            push!(year_new, year_l[i])

            push!(time_new, time_l[i])
            push!(height_new, h_l[i])

            push!(time_range_new, time_range[i])

            # f_filter_lod / db_dn_slo_h * 100
            push!(flux_new, flux_l[i]/int_val*100)
            push!(beta_new, beta_l[i])
            push!(w2_new, w2_l[i])

            #std
            push!(flux_std_new, flux_std[i]/int_val*100)
            push!(beta_std_new, backscat_std[i])
            push!(w2_std_new, w2_std[i])

            push!(rh_new, int_rh)
                        
        end
    end
    flux_new = replace(flux_new, NaN => missing)
    return day_new, month_new ,year_new , time_new, height_new, w2_new, beta_new, flux_new,  w2_std_new, beta_std_new, flux_std_new, time_range_new, rh_new
end

function  fluxH_with_modifications(flag_stability, flag_condition)
    # PATH_output_png = "/home/ellai/test_arm_data/flux_calc/VER6/output_png/"
    # PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER6/output_txt/"

    # input_file_name_2021 = "fluxH_2021_"*flag_stability*"_"*flag_condition*".txt"
    input_file_name = "fluxH_"*flag_stability*"_"*flag_condition*".txt"

    # input_file_path_2021 = PATH_output_txt * input_file_name_2021
    input_file_path = PATH_output_txt * input_file_name

    #[day, month, year, time_in, diff_t, 105, mean_b, std_b, mean_w, std_w, mean_var_w2, std_var_w2, mean_f, std_f, lod_mean, f_uncert_noise, stab_zl]
    # input_data_2021 = readdlm(input_file_path_2021)
    input_data = readdlm(input_file_path)

    # input_data = vcat(input_data_2021, input_data_2022)


    # println(size(input_data))
    time_in, time_range = input_data[:,4], input_data[:,5] # sec
    w2_mean, w2_std = input_data[:,11], input_data[:,12]
    flux_mean, flux_std = input_data[:,13], input_data[:,14]
    backscat_mean, backscat_std = input_data[:,7], input_data[:,8]
    day, month, year = input_data[:,1], input_data[:,2], input_data[:,3]
    stab_zl = input_data[:, 17]
    corr_factor = input_data[:, 18]
    height = input_data[:, 6]

    sorted_idx = sortperm(time_in)
    time_in = time_in[sorted_idx]
    time_range = time_range[sorted_idx]
    w2_mean = w2_mean[sorted_idx]
    w2_std = w2_std[sorted_idx]
    flux_mean = flux_mean[sorted_idx]
    flux_std = flux_std[sorted_idx]
    backscat_mean = backscat_mean[sorted_idx]
    backscat_std = backscat_std[sorted_idx]
    day = day[sorted_idx]
    month = month[sorted_idx]
    year = year[sorted_idx]
    stab_zl = stab_zl[sorted_idx]
    corr_factor = corr_factor[sorted_idx]
    height = height[sorted_idx]


    
    if flag_stability == "unstable"
        stab_const = -1
    elseif flag_stability == "neutral"
        stab_const = 0 
    elseif flag_stability == "stable"
        stab_const = 1  
    end 
    stability = fill(stab_const, length(height))
    
    if flag_condition == "clean"
        clean_const = 1
    elseif flag_condition == "nonclean"
        clean_const = -1
    end 
    cleanliness = fill(clean_const, length(height))
    
    # println("initial ", mean(flux_mean))

    # calibration
    input_file_calibration = PATH_output_txt *  "calibration_slope_intercept_$(flag_stability)_$(flag_condition).txt"
    calib_info = readdlm(input_file_calibration)
    #day, month, year, time, h, rh, int_vals = calib_info[:, 1], calib_info[:,2 ], calib_info[:, 3], calib_info[:]
    println("before calibration ", mean(skipmissing(flux_mean)))
    day, month, year, time_f, height, w2_mean, backscat_mean, flux_mean, w2_std, backscat_std, flux_std, time_range, rh = corrected_flux(time_in, day, month, year, flux_mean, flux_std, w2_mean, w2_std, backscat_mean, backscat_std,  height, calib_info, time_range)

    # filter_rh()
    println("after calibration ", mean(skipmissing(flux_mean)))
    
    flux_corr  = calc_flux_corr(corr_factor, flux_mean)
    println("after correction ", mean(skipmissing(flux_corr)))
    
    info_matrix = hcat(day, month, year, time_f, height, w2_mean, backscat_mean, flux_corr, w2_std, backscat_std, flux_std, time_range, stability, cleanliness)

    output_file_name = "fluxH_MOD_" * flag_stability *"_"*flag_condition* ".txt"
    output_file = PATH_output_txt * output_file_name
    println(output_file)
    writedlm(output_file, info_matrix)

end

# condition_options = ["clean"]
# stability_options = ["stable"]
condition_options = ["clean", "nonclean"]
stability_options = ["stable", "unstable", "neutral"]

for flag_condition in condition_options
    for flag_stability in stability_options
        fluxH_with_modifications(flag_stability, flag_condition)
    end
end