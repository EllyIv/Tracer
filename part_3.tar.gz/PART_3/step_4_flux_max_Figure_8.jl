using Glob  # for globbing the file patterns
using CSV   # for reading CSV files
using Plots # for plotting
using Colors # for color normalization
using NCDatasets # for NetCDF
using Dates  # to convert dates in sec
using Statistics # for mean
using Dierckx     # For detrend (spline interpolation)
using Polynomials
using StatsBase 
using DSP  
using DelimitedFiles
using Measures
using LaTeXStrings
using Interpolations
using LsqFit #for curve fitting 
using LaTeXStrings
using GLM
using DataFrames
using StatsModels
using Logging
disable_logging(Logging.Warn)
include("../paths_for_all.jl")

function find_number_of_the_profile(day, month, year, time_in)
    number_set = zeros(Int, length(time_in))
    unique_comb = unique(zip(time_in, day, month, year))

    for (k, (ti, d, m, y)) in enumerate(unique_comb)
        inds = findall(i -> time_in[i] == ti && day[i] == d && month[i] == m && year[i] == y, eachindex(time_in))
        number_set[inds] .= k
    end   
    return number_set

end 

function normalize_height(fix_t, day, month, year, input_data_pbl1)
    #[pbl1[1], pbl2[1], day[1], hours, month[1], year[1]]
    # day_lidar, m_lidar, y_lidar, t_lidar, pbl_set1
    day_pbl, month_pbl, year_pbl = input_data_pbl1[:, 1], input_data_pbl1[:, 2], input_data_pbl1[:, 3]
    time_pbl, pbl_h = input_data_pbl1[:, 4], input_data_pbl1[:, 5]
    
    fix_t = floor(Float64, fix_t)
    # println(fix_t)
    # println(time_pbl[1:10])
    # sleep(100)
    mask = (time_pbl .== fix_t) .&(day_pbl .== day) .& (month_pbl .== month) .& (year_pbl .== year)
    # println("clouds ", cld_h[mask])

    if !isempty(pbl_h[mask])
        return pbl_h[mask][1]
    else 
        return missing
    end
end  

function define_belly(set_f, set_h)
    set_f = replace(set_f, "missing" => missing)

    mask_h = findall(h->h<0.7, set_h)
    set_f = set_f[mask_h]
    set_h = set_h[mask_h]

    # println(set_f) 
    # println(size(set_h) )
    # Step 2: Find the best 4-element subset with the maximum sum
    max_sum = -Inf
    best_index = -1
    for i in 1:(length(set_f) - 3)  # Ensure at least 4 elements exist
        current_sum = sum(set_f[i:i+3])
        if  !ismissing(current_sum)
            if current_sum > max_sum 
                max_sum = current_sum
                best_index = i  # Store the starting index of the best group
            end
        end
    end    

    # Extract the best 4-element set
    # println(best_index, " ", size(set_f))
    if best_index != -1 
        best_set_f = set_f[best_index:best_index+3]
        best_set_h = set_h[best_index:best_index+3]

        # Step 3: Create overlapping pairs
        pairs = [(best_set_f[i], best_set_f[i+1]) for i in 1:3]  # (1,2), (2,3), (3,4)

        # Step 4: Compute means and errors
        min_error = Inf
        best_pair = nothing
        best_mean = nothing

        for p in pairs
            mean_val = mean(p)  # Mean of the pair
            error = abs(p[1] - p[2])  # Error as absolute difference
            
            if error < min_error
                min_error = error
                best_pair = p
                best_mean = mean_val
            end
        end

        # Step 5: Find corresponding h value using the closest f in best_set_f
        closest_index = argmin(abs.(best_set_f .- best_mean))  # Find index of closest value
        best_h = best_set_h[closest_index]  # Corresponding h value
        return best_mean, best_h
    else 
        return missing, missing 
    end 
end

function get_non_missing_data(raw_input_data)
    h0_1, f0_1, b0_1, w0_1, n0_1 = raw_input_data[:, 1], raw_input_data[:, 2], raw_input_data[:, 3], raw_input_data[:, 4], raw_input_data[:, 9]
    h0_1 = replace(h0_1, "missing" => missing)
    f0_1 = replace(f0_1, "missing" => missing)
    b0_1 = replace(b0_1, "missing" => missing)
    w0_1 = replace(w0_1, "missing" => missing)
    
    inds_missing = findall(i -> ismissing(h0_1[i]) || ismissing(f0_1[i]) || ismissing(b0_1[i]) || ismissing(w0_1[i]), eachindex(h0_1))

    keep_inds = setdiff(1:length(h0_1), inds_missing)

    h0_1 = h0_1[keep_inds]
    f0_1 = f0_1[keep_inds]
    b0_1 = b0_1[keep_inds]
    w0_1 = w0_1[keep_inds]
    n0_1 = n0_1[keep_inds]

    return h0_1, f0_1, b0_1, w0_1, n0_1 
end 

function get_non_missing_data(h0_1, f0_1, w0_1, b0_1, n0_1)
    h0_1 = replace(h0_1, "missing" => missing)
    f0_1 = replace(f0_1, "missing" => missing)
    b0_1 = replace(b0_1, "missing" => missing)
    w0_1 = replace(w0_1, "missing" => missing)
    
    inds_missing = findall(i -> ismissing(h0_1[i]) || ismissing(f0_1[i]) || ismissing(b0_1[i]) || ismissing(w0_1[i]), eachindex(h0_1))

    keep_inds = setdiff(1:length(h0_1), inds_missing)

    h0_1 = h0_1[keep_inds]
    f0_1 = f0_1[keep_inds]
    b0_1 = b0_1[keep_inds]
    w0_1 = w0_1[keep_inds]
    n0_1 = n0_1[keep_inds]

    return h0_1, f0_1, w0_1, b0_1, n0_1
end 

function new_filter_max_flux()  
    # PATH_folder_lidar = "/home/ellai/data/tracer/houdlfptM1/"
    # PATH_output_png = "/home/ellai/test_arm_data/flux_calc/VER6/output_png/"
    # PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER6/output_txt/"

    # combine info for 2021 and 2022
    file_name =PATH_output_txt * "fluxH_MOD_norm_RAW_DATA.txt"
    input_data = readdlm(file_name)
    # writedlm(output_file_raw, hcat(h_data, flux_mean, backscat_mean, w2_mean, day, month, year, time_in, number_of_the_profile, info_rgm_u, info_rgm_h, stability, cleanliness))


    #day, month, year, time_f, height, w2_mean, backscat_mean, flux_corr, w2_std, backscat_std, flux_std, time_range
    day, month, year = input_data[:, 5], input_data[:, 6], input_data[:, 7]
    time_in = input_data[:, 8]
    height = input_data[:, 1]
    flux_mean =input_data[:, 2]
    w2_mean = input_data[:, 4]
    backscat_mean = input_data[:, 3]
    number_of_the_profile = input_data[:, 9]

    flux_mean = replace(flux_mean, "missing" => missing)

    println("maximum flux ", maximum(skipmissing(flux_mean)))
    height = replace(height, "missing" => missing)
    height, flux_mean, w2_mean, backscat_mean, number_of_the_profile = get_non_missing_data(height, flux_mean, w2_mean, backscat_mean, number_of_the_profile) 
    h_data = height
    
    mask_025  = (flux_mean .>= 200)
    mask_025 = replace(mask_025, missing => false)
    number_of_the_profile_2 = number_of_the_profile[mask_025]
    chosen_profile = unique(number_of_the_profile_2)
    
    mask_chosen = in.(number_of_the_profile, Ref(chosen_profile))
    mask_non_chosen = .!mask_chosen
    

    flux_mean_c  = flux_mean[mask_chosen]
    backscat_mean_c = backscat_mean[mask_chosen]
    w2_mean_c = w2_mean[mask_chosen]
    number_of_the_profile_c = number_of_the_profile[mask_chosen]
    h_data_c = h_data[mask_chosen]

    flux_mean_nc  = flux_mean[mask_non_chosen]
    backscat_mean_nc = backscat_mean[mask_non_chosen]
    w2_mean_nc = w2_mean[mask_non_chosen]
    number_of_the_profile_nc = number_of_the_profile[mask_non_chosen]
    h_data_nc = h_data[mask_non_chosen]
    
    ave_f_data_c, std_f_data_c, ave_b_data_c, ave_w2_data_c, ave_h_data_c = [], [], [], [], []
    nbins = 50
    h_edges = range(0, 2; length=nbins+1)
    h_centers = (h_edges[1:end-1] .+ h_edges[2:end]) ./ 2
    for i in 1:nbins
        inds = findall(h -> h_edges[i] ≤ h < h_edges[i+1], skipmissing(h_data_c))
        if !isempty(inds) && length(collect(skipmissing(flux_mean_c[inds]))) != 0
            push!(ave_f_data_c, mean(skipmissing(flux_mean_c[inds])))
            push!(std_f_data_c, std(skipmissing(flux_mean_c[inds])))
            push!(ave_b_data_c, mean(skipmissing(backscat_mean_c[inds])))
            push!(ave_w2_data_c, mean(skipmissing(w2_mean_c[inds])))
            push!(ave_h_data_c, h_centers[i])
        end
    end

    ave_f_data_nc, std_f_data_nc, ave_b_data_nc, ave_w2_data_nc, ave_h_data_nc = [], [], [], [], []
    for i in 1:nbins
        inds = findall(h -> h_edges[i] ≤ h < h_edges[i+1], skipmissing(h_data_nc))
        if !isempty(inds) && length(collect(skipmissing(flux_mean_nc[inds]))) != 0
            push!(ave_f_data_nc, mean(skipmissing(flux_mean_nc[inds])))
            push!(std_f_data_nc, std(skipmissing(flux_mean_nc[inds])))
            push!(ave_b_data_nc, mean(skipmissing(backscat_mean_nc[inds])))
            push!(ave_w2_data_nc, mean(skipmissing(w2_mean_nc[inds])))
            push!(ave_h_data_nc, h_centers[i])
        end
    end

    unique_n01 = unique(number_of_the_profile_c)
    unique_n02 = unique(number_of_the_profile_nc)

    colors = cgrad([:purple, :green], 4, categorical = true)
    # p = plot(layout=(2, 3), size=(1500, 1000), left_margin = 15mm, bottom_margin = 15mm,  top_margin = 10mm,  xguidefont = 20, yguidefont = 20, ytickfont = font(18), xtickfont = font(18), legendfont = font(18))#, xlim = [-100, 500], xticks = ([0, 200, 400], ["0", "200", "400"]))
    p = plot(layout=(2, 3), size=(2500/5*3, 450*2), left_margin = 15mm, right_margin = 5mm, bottom_margin = 15mm,  top_margin = 5mm,  xguidefont = 20, yguidefont = 20, ytickfont = font(14), xtickfont = font(14), legendfont = font(18))#, xlim = [-100, 500], xticks = ([0, 200, 400], ["0", "200", "400"]))


    # println(length(unique_n01))
    for j in 1:length(unique_n01)
        inds = findall(i -> unique_n01[j] == number_of_the_profile_c[i], eachindex(number_of_the_profile_c))
        one_h01 = h_data_c[inds]
        one_b01 = backscat_mean_c[inds]
        one_w01 = w2_mean_c[inds]
        one_f01 = flux_mean_c[inds]
        mask_one = sortperm(one_h01)
        # println(sum(mask_one))
        one_h01 = one_h01[mask_one]
        one_b01 = one_b01[mask_one]
        one_w01 = one_w01[mask_one]
        one_f01 = one_f01[mask_one]
        # println(one_h01)
        # plot!(p[1], one_b01, one_h01, color =:black, alpha = 0.2, label = false) 
        plot!(p[1], one_b01, one_h01, color =:black, alpha = 0.015, xscale = :log10, label = false) 
        plot!(p[2], one_w01, one_h01, color =:black, alpha = 0.015, label = false) 
        plot!(p[3], one_f01, one_h01, color =:black, alpha = 0.015,  xscale = :log10, label = false) 
    end  

    # scatter!(p[3], b0_1, h0_1, markerstrokecolor=:black, alpha=0.1, lw=2, marker=:circle, color=:black, ylim=[0, 1.2])
    hspan!(p[1], [1, 2], color = :lightgray, alpha = 0.5, label = false)
    scatter!(p[1], ave_b_data_c, ave_h_data_c, marker=:circle, markerstrokecolor=colors[1], legend=false, ylabel=L"H/H_{PBL} (-)",  xlabel=L"\beta\ (Mm^{-1}\ sr^{-1})",  lw=2,  color=colors[1], ylim=[0, 1.2], xlim=[1, 100])
    annotate!(p[1], (1.5, 1.1, text("a1", :left, 18)))
    vline!(p[1], [0], linestyle=:dot, color=:black, label=false)
    hline!(p[1], [1],  linestyle=:dot, color=:black, label=false)
    println("max beta for high flux :", maximum(ave_b_data_c))
    belly1 = define_belly(ave_b_data_c, ave_h_data_c)
    println(belly1)

    # scatter!(p[4], w0_1, h0_1, markerstrokecolor=:black, alpha=0.1, lw=2, marker=:circle, color=:black, ylim=[0, 1.2])
    hspan!(p[2], [1, 2], color = :lightgray, alpha = 0.5, label = false)
    scatter!(p[2], ave_w2_data_c, ave_h_data_c, legend=false, xlabel=L"<w'w'> (m^2\ s^{-2})",  lw=2,markerstrokecolor=colors[1],  marker=:circle, color=colors[1], ylim=[0, 1.2], xlim=[-0.0, 2.0])
    annotate!(p[2], (0.2, 1.1, text("b1", :left, 18)))
    # vline!(p[2], [0], linestyle=:dot, color=:black, label=false)
    hline!(p[2], [1],  linestyle=:dot, color=:black, label=false)
    println("max w'w' for high flux :", maximum(ave_w2_data_c))
    belly2 = define_belly(ave_w2_data_c[10:end], ave_h_data_c[10:end])
    println(belly2)

    # scatter!(p[5], f0_1, h0_1, markerstrokecolor=:black, alpha=0.1, lw=2, marker=:circle, color=:black, ylim=[0, 1.2])
    hspan!(p[3], [1, 2], color = :lightgray, alpha = 0.5, label = false)
    # scatter!(p[3], f_1, h_1;  xerror=df_1, markerstrokecolor=colors[1], alpha=0.3,  label=false, xlabel=L"Flux \times 10^6 (s^{-1}sr^{-1})", lw=2, marker=:circle, color=colors[1], ylim=[0, 1.2], xlim=[-20, 230], legend=:right, title="winter", titlefont=font(18))
    scatter!(p[3], ave_f_data_c, ave_h_data_c, marker=:circle, markerstrokecolor=colors[1], color=colors[1], legend=false, xlabel=L"Flux \ (cm^{-2}\ s^{-1})", ylim=[0, 1.2], xlim=[1, 700],  title="High Flux", titlefont=font(18))
    annotate!(p[3], (1.5, 1.1, text("c1", :left, 18)))
    vline!(p[3], [0], linestyle=:dot, color=:black, label=false)
    hline!(p[3], [1],  linestyle=:dot, color=:black, label=false)


    for j in 1:length(unique_n02)
        inds = findall(i -> unique_n02[j] == number_of_the_profile_nc[i], eachindex(number_of_the_profile_nc))
        one_h01 = h_data_nc[inds]
        one_b01 = backscat_mean_nc[inds]
        one_w01 = w2_mean_nc[inds]
        one_f01 = flux_mean_nc[inds]
        mask_one = sortperm(one_h01)
        one_h01 = one_h01[mask_one]
        one_b01 = one_b01[mask_one]
        one_w01 = one_w01[mask_one]
        one_f01 = one_f01[mask_one]
        # plot!(p[4], one_b01, one_h01, color =:black, alpha = 0.2, label = false) 
        plot!(p[4], one_b01, one_h01, color =:black, alpha = 0.015 ,  xscale = :log10,  label = false) 
        plot!(p[5], one_w01, one_h01, color =:black, alpha = 0.015, label = false) 
        plot!(p[6], one_f01, one_h01, color =:black, alpha = 0.015,  xscale = :log10, label = false) 
    end  
    # scatter!(p[3], b0_1, h0_1, markerstrokecolor=:black, alpha=0.1, lw=2, marker=:circle, color=:black, ylim=[0, 1.2])
    hspan!(p[4], [1, 2], color = :lightgray, alpha = 0.5, label = false)
    scatter!(p[4], ave_b_data_nc, ave_h_data_nc, marker=:circle, markerstrokecolor=colors[2], legend=false, ylabel=L"H/H_{PBL} (-)",  xlabel=L"\beta\ (Mm^{-1}\ sr^{-1})",  lw=2,  color=colors[2], ylim=[0, 1.2], xlim=[1, 100])
    annotate!(p[4], (1.5, 1.1, text("a2", :left, 18)))
    vline!(p[4], [0], linestyle=:dot, color=:black, label=false)
    hline!(p[4], [1],  linestyle=:dot, color=:black, label=false)
    println("max beta for low flux :", maximum(ave_b_data_nc))
    belly3 = define_belly(ave_b_data_nc, ave_h_data_nc)
    println(belly3)

    # scatter!(p[4], w0_1, h0_1, markerstrokecolor=:black, alpha=0.1, lw=2, marker=:circle, color=:black, ylim=[0, 1.2])
    hspan!(p[5], [1, 2], color = :lightgray, alpha = 0.5, label = false)
    scatter!(p[5], ave_w2_data_nc, ave_h_data_nc, legend=false, xlabel=L"<w'w'> (m^2\ s^{-2})",  lw=2,markerstrokecolor=colors[2],  marker=:circle, color=colors[2], ylim=[0, 1.2], xlim=[-0.0, 2.0])
    annotate!(p[5], (0.2, 1.1, text("b2", :left, 18)))
    # vline!(p[5], [0], linestyle=:dot, color=:black, label=false)
    hline!(p[5], [1],  linestyle=:dot, color=:black, label=false)
    println("max w'w' for low flux :", maximum(ave_w2_data_nc))
    belly4 = define_belly(ave_w2_data_nc, ave_h_data_nc)
    println(belly4)

    # scatter!(p[5], f0_1, h0_1, markerstrokecolor=:black, alpha=0.1, lw=2, marker=:circle, color=:black, ylim=[0, 1.2])
    hspan!(p[6], [1, 2], color = :lightgray, alpha = 0.5, label = false)
    # scatter!(p[3], f_1, h_1;  xerror=df_1, markerstrokecolor=colors[1], alpha=0.3,  label=false, xlabel=L"Flux \times 10^6 (s^{-1}sr^{-1})", lw=2, marker=:circle, color=colors[1], ylim=[0, 1.2], xlim=[-20, 230], legend=:right, title="winter", titlefont=font(18))
    scatter!(p[6], ave_f_data_nc, ave_h_data_nc, marker=:circle, markerstrokecolor=colors[2], color=colors[2], legend=false, xlabel=L"Flux \  (cm^{-2}\ s^{-1})", ylim=[0, 1.2], xlim=[1, 700],  title="Low Flux", titlefont=font(18))
    annotate!(p[6], (1.5, 1.1, text("c2", :left, 18)))
    vline!(p[6], [0], linestyle=:dot, color=:black, label=false)
    hline!(p[6], [1],  linestyle=:dot, color=:black, label=false)

    savefig(PATH_output_png* "flux_H_1200_new_filter_max_flux.png")
    println(PATH_output_png* "flux_H_1200_new_filter_max_flux.png")

end 

new_filter_max_flux()  


  