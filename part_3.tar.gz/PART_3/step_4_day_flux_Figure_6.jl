using Glob  # for globbing the file patterns
using CSV   # for reading CSV files
using Plots # for plotting
using Colors # for color normalization
using NCDatasets # for NetCDF
using Dates  # to convert dates in sec
using Statistics # for mean
using Dierckx     # For detrend (spline interpolation)
using Polynomials
using StatsBase 
using DSP  # Import DSP package
using DelimitedFiles
using Measures
using LaTeXStrings

include("../paths_for_all.jl")

function normalize_height(fix_t, day, month, year, input_data_pbl1)
    #[pbl1[1], pbl2[1], day[1], hours, month[1], year[1]]
    # day_lidar, m_lidar, y_lidar, t_lidar, pbl_set1
    day_pbl, month_pbl, year_pbl = input_data_pbl1[:, 1], input_data_pbl1[:, 2], input_data_pbl1[:, 3]
    time_pbl, pbl_h = input_data_pbl1[:, 4], input_data_pbl1[:, 5]
    
    fix_t = floor(Float64, fix_t)
    # println(fix_t)
    # println(time_pbl[1:10])
    # sleep(100)
    mask = (time_pbl .== fix_t) .&(day_pbl .== day) .& (month_pbl .== month) .& (year_pbl .== year)
    # println("clouds ", cld_h[mask])

    if !isempty(pbl_h[mask])
        return pbl_h[mask][1]
    else 
        return missing
    end
end  

function find_a_day()
    # PATH_output_png = "/home/ellai/test_arm_data/flux_calc/VER6/output_png/"
    # PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER6/output_txt/"


    file_suffixes = ["fluxH_MOD_unstable_clean.txt", "fluxH_MOD_unstable_nonclean.txt",  "fluxH_MOD_neutral_clean.txt",  "fluxH_MOD_neutral_nonclean.txt"]
    input_data_list = [readdlm(PATH_output_txt * suffix) for suffix in file_suffixes]
    input_data = vcat(input_data_list...)

    #day, month, year, time_f, height, w2_mean, backscat_mean, flux_corr, w2_std, backscat_std, flux_std, time_range
    day, month, year = input_data[:, 1], input_data[:, 2], input_data[:, 3]
    time_f, time_range = input_data[:, 4], input_data[:, 12]
    height = input_data[:, 5]
    w2_mean, w2_std = input_data[:, 6], input_data[:, 9]
    backscat_mean, backscat_std = input_data[:, 7], input_data[:, 10]
    flux_mean, flux_std = input_data[:, 8], input_data[:, 11]
    
    date_time = [string(d, "-", m, "-", y, " ", t) for (d, m, y, t) in zip(day, month, year, time_f)]
    u_dates = unique(date_time)
    counts = [sum(date_time .== ud) for ud in u_dates]
    sorted_idx = sortperm(counts, rev=true)
    # for i in sorted_idx[1:10]
    #     println(u_dates[i], " => ", counts[i])
    # end
    top_keys = u_dates[sorted_idx[1:min(20, end)]]
    
    set_flux, set_back, set_w2, set_h_for_flux  = [], [], [], []
    for key in top_keys
        sel = (date_time .== key)    
        f  = flux_mean[sel]
        b  = backscat_mean[sel]
        h  = height[sel]
        w2 = w2_mean[sel]
    
        push!(set_flux, f)
        push!(set_back, b)
        push!(set_w2, w2)
        push!(set_h_for_flux, h)

    end


    info_pbl_height = [] 
    input_file_pbl = PATH_output_txt * "pbl_aligned_with_lidar.txt"
    input_data_pbl1 = readdlm(input_file_pbl)
    day_pbl, month_pbl, year_pbl = input_data_pbl1[:, 1], input_data_pbl1[:, 2], input_data_pbl1[:, 3]
    time_pbl, pbl_h = input_data_pbl1[:, 4], input_data_pbl1[:, 5]
    time_pbl = time_pbl ./3600
    for key in top_keys
        parts = split(key, ' ')
        dmy = split(parts[1], '-')
        d = Int(parse(Float64, dmy[1]))
        m = Int(parse(Float64, dmy[2]))
        y = Int(parse(Float64, dmy[3]))
        t0 = parse(Float64, parts[2])
    
        sel = (day_pbl .== d) .& (month_pbl .== m) .& (year_pbl .== y) .& (time_pbl .== t0)# (abs.(time_sonde .- t0) .<= 1)
    
        println("== ", key, " ==")
        println("matches: ", sum(sel))
        push!(info_pbl_height, pbl_h[sel][1])
    end
    println("PBLH ", info_pbl_height)

    # # println(size(pbl_info))
    # # println(pbl_info[1, :])
    # for t_ind in 1:length(time_in)
    #     t = time_in[t_ind]
    #     # println(pbl_info[1])
    #     # sleep(1000)
    #     norm_height = normalize_height(t, day[t_ind], month[t_ind], year[t_ind], pbl_info) #true , false 
    #     push!(info_pbl_height, norm_height)
    # end 

    # flux_corr = calc_flux_corr(corr_factor, flux_mean)
    # file_suffixes_rh = ["sonde_interpolated_rh_unstable_clean.txt", "sonde_interpolated_rh_unstable_nonclean.txt",  "sonde_interpolated_rh_neutral_clean.txt",  "sonde_interpolated_rh__neutral_nonclean.txt"]
    # input_data_list_rh = [readdlm(PATH_output_txt * suffix) for suffix in file_suffixes_rh]
    # info_sonde = vcat(input_data_list_rh...)

    file_sonde = "rh_aligned_with_lidar.txt"
    input_file_sonde =  PATH_output_txt * file_sonde 
    info_sonde = readdlm(input_file_sonde)
    day_sonde, month_sonde, year_sonde, time_sonde =  info_sonde[:, 1], info_sonde[:, 2], info_sonde[:, 3], info_sonde[:, 4]
    h_sonde = info_sonde[:, 5] #./ mean(info_pbl_height)
    rh = info_sonde[:, 6]
    temp = info_sonde[:, 7]
    
    p1 = plot()
    p2 = plot()
    count = 1
    set_rh = []
    set_temp = []
    set_h_for_rh = []
    for key in top_keys
        parts = split(key, ' ')
        dmy = split(parts[1], '-')
        d = Int(parse(Float64, dmy[1]))
        m = Int(parse(Float64, dmy[2]))
        y = Int(parse(Float64, dmy[3]))
        t0 = parse(Float64, parts[2])
    
        sel = (day_sonde .== d) .& (month_sonde .== m) .& (year_sonde .== y) .& (time_sonde .== t0)# (abs.(time_sonde .- t0) .<= 1)
    
        println("== ", key, " ==")
        println("matches: ", sum(sel))
        # Example: access subsets if needed
        rh_sel   = rh[sel]
        temp_sel = temp[sel]
        h_sel    = h_sonde[sel]
        println(maximum(h_sel), " ", minimum(h_sel))
        if !isempty(rh_sel)
            # sort by height so lines look tidy
            ord = sortperm(h_sel)
            plot!(p1, rh_sel[ord], h_sel[ord]./info_pbl_height[1], marker=:circle,  label = count)
            plot!(p2, temp_sel[ord], h_sel[ord]./info_pbl_height[1], marker=:circle,  label = count)   
            push!(set_rh, rh_sel[ord])
            push!(set_temp, temp_sel[ord])
            push!(set_h_for_rh, h_sel[ord])    
        else 
            push!(set_rh, [])
            push!(set_temp, [])
            push!(set_h_for_rh,[])    
        end
        count += 1
        
    end
    p = plot(p1, p2, layout=(1, 2))

    println(PATH_output_png * "rh_10_days.png") 
    savefig(p, PATH_output_png * "rh_10_days.png")

    
    # Choise one option 
    # N = 2
    for N in 15:20
    
        parts = split(top_keys[N], ' ')
        dmy = split(parts[1], '-')
        d = Int(parse(Float64, dmy[1]))
        m = Int(parse(Float64, dmy[2]))
        y = Int(parse(Float64, dmy[3]))
        t0 = parse(Float64, parts[2])

        pblh = info_pbl_height[N]
        
        rh_fix = set_rh[N]
        temp_fix = set_temp[N]
        h_fix = set_h_for_rh[N] ./ pblh


        flux_fix = set_flux[N]
        back_fix = set_back[N]
        w2_fix = set_w2[N]
        h_fix_for_flux = set_h_for_flux[N] ./ pblh

    
        colors = cgrad([:purple, :green], 5, categorical = true)
        p = plot(layout=(1, 5), size=(2500, 450), left_margin = 15mm, bottom_margin = 20mm, xguidefont = 22, yguidefont = 22, ytickfont = font(16), xtickfont = font(16))
    
        hspan!(p[1], [1, 2], color = :lightgray, alpha = 0.5, label = false)
        scatter!(p[1], temp_fix, h_fix,  label=false, xlabel=L"Θ (K)", ylabel=L"H/H_{PBL} (-)",markerstrokecolor = colors[1],  ms = 5, marker=:circle, color=colors[1], ylim=[0, 1.2], xlim = [280, 310])
        vline!(p[1], [0], linestyle=:dot, color=:black, label=false)
        hline!(p[1], [1],  linestyle=:dot, color=:black, label=false)
        annotate!(p[1], (274, 1.15, text("a", :left, 18)))
        
        hspan!(p[2], [1, 2], color = :lightgray, alpha = 0.5, label = false)
        scatter!(p[2], rh_fix, h_fix,  label=false, xlabel=L"RH (\%)", ms = 5, colorbar = false,  marker=:circle, color=colors[2], ylim=[0, 1.2], xlim= [0, 100])
        vline!(p[2], [0], linestyle=:dot, color=:black, label=false)
        hline!(p[2], [1],  linestyle=:dot, color=:black, label=false)
        annotate!(p[2], (5, 1.15, text("b", :left, 18)))

        hspan!(p[3], [1, 2], color = :lightgray, alpha = 0.5, label = false)
        scatter!(p[3], back_fix, h_fix_for_flux,  label=false, xlabel= L"\beta\ (Mm^{-1}\ sr^{-1})", ms = 5, marker=:circle, color=colors[3], ylim=[0.0, 1.2], xlim = [-1.5, 10])
        vline!(p[3], [0], linestyle=:dot, color=:black, label=false)
        hline!(p[3], [1],  linestyle=:dot, color=:black, label=false)
        annotate!(p[3], (-0.2, 1.15, text("c", :left, 18)))

        hspan!(p[4], [1, 2], color = :lightgray, alpha = 0.5, label = false)
        scatter!(p[4], w2_fix,  h_fix_for_flux,  label=false, xlabel=L"<w'w'> (m^2s^{-2})", ms = 5, marker=:circle, color=colors[4], ylim=[0, 1.2], xlim = [-0.5, 4.0], xticks = ([ 0, 1, 2, 3], ["0", "1", "2", "3"]))
        vline!(p[4], [0], linestyle=:dot, color=:black, label=false)
        hline!(p[4], [1],  linestyle=:dot, color=:black, label=false)
        annotate!(p[4], (-0.3, 1.15, text("d", :left, 18)))
        
        hspan!(p[5], [1, 2], color = :lightgray, alpha = 0.5, label = false)
        scatter!(p[5], flux_fix, h_fix_for_flux,  label=false, xlabel=L"Flux \times 10^6 (s^{-1}sr^{-1})", ms = 5, marker=:circle, color=colors[5], ylim=[0, 1.2], xlims = [0, 700], xticks = ([ 0, 200, 400, 600], ["0", "200", "400", "600"]))
        vline!(p[5], [0], linestyle=:dot, color=:black, label=false)
        hline!(p[5], [1],  linestyle=:dot, color=:black, label=false)
        annotate!(p[5], (50, 1.15, text("e", :left, 18)))


        png(p, PATH_output_png * "FOR_PAPER_flux_for_one_day_$N.png")
        println(PATH_output_png * "FOR_PAPER_flux_for_one_day_$N.png")
    end 
    
    # output_file = PATH_output_txt * "FOR_PAPER_flux_for_one_day"
    # writedlm(output_file, hcat(ave_h_data, ave_f_data, std_f_data))
end 



function find_a_day_ver2()
    # PATH_output_png = "/home/ellai/test_arm_data/flux_calc/VER6/output_png/"
    # PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER6/output_txt/"

    # file_suffixes = ["fluxH_MOD_unstable_clean.txt", "fluxH_MOD_unstable_nonclean.txt",  "fluxH_MOD_neutral_clean.txt",  "fluxH_MOD_neutral_nonclean.txt"]
    # input_data_list = [readdlm(PATH_output_txt * suffix) for suffix in file_suffixes]
    # input_data = vcat(input_data_list...)
    input_file_raw = PATH_output_txt * "fluxH_MOD_norm_RAW_DATA.txt"
    input_data = readdlm(input_file_raw)

    height = input_data[:, 1] 
    flux_mean = input_data[:, 2] 
    backscat_mean, w2_mean = input_data[:, 4], input_data[:, 3] 
    day, month, year, time_in = input_data[:, 5], input_data[:, 6], input_data[:, 7], input_data[:, 8]
    number_of_the_profile = input_data[:, 9]

    time_f = time_in #./ 3600

    flux_mean = replace(flux_mean, "missing" => missing)
    w2_mean = replace(w2_mean, "missing" => missing)

    unique_profiles = unique(number_of_the_profile)

    set_count = Int[]
    for prof in unique_profiles
        mask = (number_of_the_profile .== prof) .& .!ismissing.(flux_mean) 
        push!(set_count, count(mask))
    end

    profile_counts = sort(collect(zip(unique_profiles, set_count)), by = x -> x[2], rev = true)

    # Take top 5 most repeated
    top5_profiles = profile_counts[1:40]

    for (prof, cnt) in top5_profiles
        idx = findfirst(number_of_the_profile .== prof)
        println("Profile $prof → count = $cnt, date = $(day[idx]).$(month[idx]).$(year[idx]) at time $(time_f[idx])")
    end
end 


function plot_fixed_day(fix_day, fix_month, fix_year, fix_time, gap_time)
    # PATH_output_png = "/home/ellai/test_arm_data/flux_calc/VER6/output_png/"
    # PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER6/output_txt/"
    # PATH_output_txt_p = "/home/ellai/test_arm_data/flux_calc/VER6/output_txt_for_paper/"

    # file_suffixes = ["fluxH_MOD_unstable_clean.txt", "fluxH_MOD_unstable_nonclean.txt",  "fluxH_MOD_neutral_clean.txt",  "fluxH_MOD_neutral_nonclean.txt"]
    # input_data_list = [readdlm(PATH_output_txt * suffix) for suffix in file_suffixes]
    # input_data = vcat(input_data_list...)
    input_file_raw = PATH_output_txt * "fluxH_MOD_norm_RAW_DATA.txt"
    input_data = readdlm(input_file_raw)

    height = input_data[:, 1] 
    flux_mean = input_data[:, 2] 
    backscat_mean, w2_mean = input_data[:, 4], input_data[:, 3] 
    day, month, year, time_in = input_data[:, 5], input_data[:, 6], input_data[:, 7], input_data[:, 8]
    number_of_the_profile = input_data[:, 9]

    time_f = time_in #./ 3600
    # println(time_f)
    #day, month, year, time_f, height, w2_mean, backscat_mean, flux_corr, w2_std, backscat_std, flux_std, time_range
    # day, month, year = input_data[:, 1], input_data[:, 2], input_data[:, 3]
    # time_f, time_range = input_data[:, 4], input_data[:, 12]
    # height = input_data[:, 5]
    # w2_mean, w2_std = input_data[:, 6], input_data[:, 9]
    # backscat_mean, backscat_std = input_data[:, 7], input_data[:, 10]
    # flux_mean, flux_std = input_data[:, 8], input_data[:, 11]
    # println(time_f[300:500]) 

    mask_1200 = (abs.(time_f .- fix_time) .<= gap_time) .& (day .== fix_day) .& (month .== fix_month) .& (year .== fix_year)
    # println(time_f[100:110], " ", fix_time)
    # println(sum(mask_1200))
    # sleep(100)
    time_f = time_f[mask_1200]
    w2_mean = w2_mean[mask_1200]
    flux_mean= flux_mean[mask_1200]
    backscat_mean= backscat_mean[mask_1200]
    day, month, year = day[mask_1200], month[mask_1200], year[mask_1200]
    height = height[mask_1200]
    println("amount of data ", length(height))
    println(unique(time_f))
    println(unique(day))
    println(unique(month))
    println(unique(year))

    
    time_in = time_f
    info_pbl_height = [] 
    input_file_pbl = PATH_output_txt * "pbl_aligned_with_lidar.txt"
    pbl_info = readdlm(input_file_pbl)

    for t_ind in 1:length(time_in)
        t = time_in[t_ind]
        norm_height = normalize_height(t*3600, day[t_ind], month[t_ind], year[t_ind], pbl_info) #true , false 
        push!(info_pbl_height, norm_height)
    end 

    # file_suffixes = ["fluxH_MOD_unstable_clean.txt", "fluxH_MOD_unstable_nonclean.txt",  "fluxH_MOD_neutral_clean.txt",  "fluxH_MOD_neutral_nonclean.txt"]
    # input_data_list = [readdlm(PATH_output_txt * suffix) for suffix in file_suffixes]
    # input_data = vcat(input_data_list...)
    file_sonde = "rh_aligned_with_lidar.txt"
    input_file_sonde =  PATH_output_txt * file_sonde 
    info_sonde = readdlm(input_file_sonde)
    day_sonde, month_sonde, year_sonde, time_sonde =  info_sonde[:, 1], info_sonde[:, 2], info_sonde[:, 3], info_sonde[:, 4]
    h_sonde = info_sonde[:, 5] #./ mean(info_pbl_height)
    rh = info_sonde[:, 6]
    temp = info_sonde[:, 7]
    # println(time_sonde[1:10])
    # println(rh[1:10])
    # println(temp[1:10])
    # sleep(100)
    mask_sonde = (abs.(time_sonde .- fix_time) .<= 12)  .& (day_sonde .== fix_day) .& (month_sonde .== fix_month) .& (year_sonde .== fix_year)
    # println(sum(mask_sonde))
    # println(info_pbl_height)
    h_sonde = h_sonde[mask_sonde] ./ mean(info_pbl_height)
    # println(unique(h_sonde))
    # println(mean(info_pbl_height))
    # sleep(100)
    rh = rh[mask_sonde] 
    temp = temp[mask_sonde] 

    # with pbl
    ave_f_data , ave_b_data, ave_w2_data, ave_h_data, std_f_data = [], [], [], [], []
    h_data = height #./ info_pbl_height
    nbins = 100
    h_edges = range(0, 2; length=nbins+1)
    h_centers = (h_edges[1:end-1] .+ h_edges[2:end]) ./ 2
    for i in 1:nbins
        inds = findall(h -> h_edges[i] ≤ h < h_edges[i+1], h_data)
        if !isempty(inds)
            # println(flux_mean)
            push!(ave_f_data, mean(flux_mean[inds]))
            push!(std_f_data, std(flux_mean[inds]))
            push!(ave_b_data, mean(backscat_mean[inds]))
            push!(ave_w2_data, mean(w2_mean[inds]))
            push!(ave_h_data, h_centers[i])
        end
    end

    # println(rh)
    # println(temp)
    # sleep(100)

    # # height bins
    ave_h_sonde, ave_rh_sonde, ave_temp_sonde, std_rh_sonde, std_temp_sonde = [], [], [], [], []
    nbins = 100
    h_edges = range(0, 2; length=nbins+1)
    println(h_edges)
    h_centers = (h_edges[1:end-1] .+ h_edges[2:end]) ./ 2
    for i in 1:nbins
        inds = findall(h -> h_edges[i] ≤ h < h_edges[i+1], h_sonde)
        if !isempty(inds)
            push!(ave_rh_sonde, mean(rh[inds]))
            push!(std_rh_sonde, std(rh[inds]))
            # if h_edges[i] > 1
            #     println(h_edges[i],  " ", temp[inds])
            # end
            push!(ave_temp_sonde, mean(temp[inds]))
            push!(std_temp_sonde, std(temp[inds]))
            push!(ave_h_sonde, h_centers[i])
        end
    end
    # println(ave_temp_sonde)
    # println(ave_h_sonde)



    colors = cgrad([:red, :blue], 5, categorical = true)
    p = plot(layout=(1, 5), size=(2500, 450), left_margin = 15mm, bottom_margin = 20mm, xguidefont = 22, yguidefont = 22, ytickfont = font(16), xtickfont = font(16), legendfont = font(16))
   
    # println(ave_temp_sonde)
    scatter!(p[1], ave_temp_sonde, ave_h_sonde,  label=false, xlabel=L"Θ\ (K)", ylabel=L"H/H_{PBL} (-)", ms = 5, marker=:circle, color=colors[3], ylim=[0, 1.2], xlim = [265, 315])
    hspan!(p[1], [1, 2], color = :white, alpha = 1, label = false)
    hspan!(p[1], [1, 2], color = :lightgray, alpha = 0.5, label = false)
    vline!(p[1], [0], linestyle=:dot, color=:black, label=false)
    hline!(p[1], [1],  linestyle=:dot, color=:black, label=false)
    annotate!(p[1], (270, 1.1, text("a", :left, 18)))
    
    # println(ave_rh_sonde)
    scatter!(p[2], ave_rh_sonde, ave_h_sonde,  label=false, xlabel=L"RH (\%)", ms = 5, marker=:circle, color=colors[3], ylim=[0, 1.2], xlim= [0, 100])
    hspan!(p[2], [1, 2], color = :white, alpha = 1, label = false)
    hspan!(p[2], [1, 2], color = :lightgray, alpha = 0.5, label = false)
    vline!(p[2], [0], linestyle=:dot, color=:black, label=false)
    hline!(p[2], [1],  linestyle=:dot, color=:black, label=false)
    annotate!(p[2], (10, 1.1, text("b", :left, 18)))


    hspan!(p[3], [1, 2], color = :lightgray, alpha = 0.5, label = false)
    scatter!(p[3], ave_w2_data,  ave_h_data,  label=false, xlabel=L"<w'w'> (m^2\ s^{-2})", ms = 5, marker=:circle, color=colors[3], ylim=[0, 1.2])#, xlims = [0, 400] , xticks = ([ 0, 1, 2, 3], ["0", "1", "2", "3"]))
    # vline!(p[3], [0], linestyle=:dot, color=:black, label=false)
    hline!(p[3], [1],  linestyle=:dot, color=:black, label=false)
    annotate!(p[3], (1, 1.1, text("c", :left, 18)))

    hspan!(p[4], [1, 2], color = :lightgray, alpha = 0.5, label = false)
    scatter!(p[4], ave_b_data, ave_h_data,  label=false, xlabel= L"\beta\ (Mm^{-1}\ sr^{-1})", ms = 5, marker=:circle, color=colors[3], ylim=[0.0, 1.2])#, xscale = :log10)
    # vline!(p[4], [0], linestyle=:dot, color=:black, label=false)
    hline!(p[4], [1],  linestyle=:dot, color=:black, label=false)
    annotate!(p[4], (0.4, 1.1, text("d", :left, 18)))


    # println(ave_f_data)
    hspan!(p[5], [1, 2], color = :lightgray, alpha = 0.5, label = false)
    scatter!(p[5], ave_f_data, ave_h_data,  label=false, xlabel=L"Flux \  (cm^{-2}\ s^{-1})", ms = 5, marker=:circle, color=colors[3], ylim=[0, 1.2])#,  xlims = [10, 200] ,xscale = :log10)
    # vline!(p[5], [0], linestyle=:dot, color=:black, label=false)
    hline!(p[5], [1],  linestyle=:dot, color=:black, label=false)
    annotate!(p[5], (12.0, 1.1, text("e", :left, 18)))

    png(p, PATH_output_png * "FOR_PAPER_flux_for_day_$(fix_day)_$(fix_month)_$(fix_year).png")

    png(p, PATH_output_png * "FOR_PAPER_flux_for_day_$(fix_day)_$(fix_month)_$(fix_year).png")
    println(PATH_output_png * "FOR_PAPER_flux_for_day_$(fix_day)_$(fix_month)_$(fix_year).png")
    
    # output_file = PATH_output_txt * "FOR_PAPER_flux_1200_for_day_$(fix_day)_$(fix_month)_$(fix_year).txt"
    # writedlm(output_file, hcat(ave_h_data, ave_f_data, std_f_data))
end 

function plot_rh_only(fix_day, fix_month, fix_year)
    # PATH_output_png = "/home/ellai/test_arm_data/flux_calc/VER6/output_png/"
    # PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER6/output_txt/"

    file_sonde = "rh_aligned_with_lidar.txt"
    input_file_sonde =  PATH_output_txt * file_sonde 
    info_sonde = readdlm(input_file_sonde)
    day_sonde, month_sonde, year_sonde, time_sonde =  info_sonde[:, 1], info_sonde[:, 2], info_sonde[:, 3], info_sonde[:, 4]
    h_sonde = info_sonde[:, 5] #./ mean(info_pbl_height)
    rh = info_sonde[:, 6]
    temp = info_sonde[:, 7]
    
    mask_sonde = (day_sonde .== fix_day) .& (month_sonde .== fix_month) .& (year_sonde .== fix_year)
    h_sonde = h_sonde[mask_sonde] ./ 2000
    rh = rh[mask_sonde] 
    temp = temp[mask_sonde] 

    ave_h_sonde, ave_rh_sonde, ave_temp_sonde, std_rh_sonde, std_temp_sonde = [], [], [], [], []
    nbins = 50
    h_edges = range(0, 2; length=nbins+1)
    h_centers = (h_edges[1:end-1] .+ h_edges[2:end]) ./ 2
    for i in 1:nbins
        inds = findall(h -> h_edges[i] ≤ h < h_edges[i+1], h_sonde)
        if !isempty(inds)
            push!(ave_rh_sonde, mean(rh[inds]))
            push!(std_rh_sonde, std(rh[inds]))
            push!(ave_temp_sonde, mean(temp[inds]))
            push!(std_temp_sonde, std(temp[inds]))
            push!(ave_h_sonde, h_centers[i])
        end
    end

    println(ave_temp_sonde)
    println()
    println(ave_h_sonde)

    colors = cgrad([:red, :blue], 5, categorical = true)
    p = plot(layout=(1, 2), size=(900, 450), left_margin = 15mm, bottom_margin = 20mm, xguidefont = 22, yguidefont = 22, ytickfont = font(16), xtickfont = font(16), legendfont = font(16))
   
    # println(ave_temp_sonde)
    scatter!(p[1], ave_temp_sonde, ave_h_sonde,  label=false, xlabel=L"Θ\ (K)", ylabel=L"H/H_{PBL} (-)", ms = 5, marker=:circle, color=colors[3], ylim=[0, 1.2], xlim = [265, 315])
    # hspan!(p[1], [1, 2], color = :white, alpha = 1, label = false)
    hspan!(p[1], [1, 2], color = :lightgray, alpha = 0.5, label = false)
    vline!(p[1], [0], linestyle=:dot, color=:black, label=false)
    hline!(p[1], [1],  linestyle=:dot, color=:black, label=false)
    annotate!(p[1], (270, 1.15, text("a", :left, 18)))
    
    # println(ave_rh_sonde)
    scatter!(p[2], rh, h_sonde,  label=false, xlabel=L"RH (\%)", ms = 1, marker=:circle, color=colors[3], ylim=[0, 1.2], xlim= [0, 100], alpha = 0.2)
    scatter!(p[2], ave_rh_sonde, ave_h_sonde,  label=false, xlabel=L"RH (\%)", ms = 5, marker=:circle, color=colors[3], ylim=[0, 1.2], xlim= [0, 100])
    # hspan!(p[2], [1, 2], color = :white, alpha = 1, label = false)
    hspan!(p[2], [1, 2], color = :lightgray, alpha = 0.5, label = false)
    vline!(p[2], [0], linestyle=:dot, color=:black, label=false)
    hline!(p[2], [1],  linestyle=:dot, color=:black, label=false)
    annotate!(p[2], (15, 1.15, text("b", :left, 18)))

    png(p, PATH_output_png * "FOR_PAPER_flux_for_day_test).png")

    png(p, PATH_output_png * "FOR_PAPER_flux_for_day_$(fix_day)_$(fix_month)_$(fix_year).png")
    println(PATH_output_png * "FOR_PAPER_flux_for_day_$(fix_day)_$(fix_month)_$(fix_year).png")

end 


# find_a_day()
# println("hey there")

# find_a_day_ver2()
# Profile 8049 → count = 53, date = 28.0.10.0.2021.0 at time 17.03
# Profile 9513 → count = 53, date = 28.0.10.0.2021.0 at time 20.28
# Profile 8733 → count = 52, date = 28.0.10.0.2021.0 at time 18.28
# Profile 2709 → count = 49, date = 4.0.8.0.2022.0 at time 17.279722222222222
# Profile 7226 → count = 49, date = 24.0.3.0.2022.0 at time 15.030277777777778
# Profile 7342 → count = 49, date = 24.0.3.0.2022.0 at time 15.28
# Profile 7629 → count = 48, date = 25.0.3.0.2022.0 at time 16.030277777777776
# Profile 9548 → count = 48, date = 28.0.10.0.2021.0 at time 20.529722222222222
# Profile 8090 → count = 47, date = 23.0.3.0.2022.0 at time 17.030277777777776
    # Profile 2383 → count = 46, date = 10.0.6.0.2022.0 at time 15.53
# Profile 8791 → count = 46, date = 28.0.10.0.2021.0 at time 18.529722222222222
# Profile 9014 → count = 46, date = 28.0.10.0.2021.0 at time 19.029722222222222
# Profile 11228 → count = 46, date = 25.0.3.0.2022.0 at time 13.030277777777778
# Profile 6980 → count = 45, date = 23.0.3.0.2022.0 at time 14.28
# Profile 7162 → count = 45, date = 12.0.6.0.2022.0 at time 14.78
# Profile 7457 → count = 45, date = 12.0.6.0.2022.0 at time 15.53
# Profile 7855 → count = 45, date = 23.0.3.0.2022.0 at time 16.53
    # Profile 11277 → count = 44, date = 10.0.6.0.2022.0 at time 13.28
# Profile 1483 → count = 43, date = 5.0.7.0.2022.0 at time 12.28
# Profile 7439 → count = 43, date = 23.0.3.0.2022.0 at time 15.53
    # Profile 2069 → count = 42, date = 4.0.10.0.2021.0 at time 14.524444444444445
# Profile 6907 → count = 42, date = 23.0.3.0.2022.0 at time 14.030277777777778
    # Profile 7021 → count = 42, date = 29.0.10.0.2021.0 at time 14.529722222222222
# Profile 8977 → count = 42, date = 23.0.3.0.2022.0 at time 18.78
# Profile 9039 → count = 42, date = 23.0.3.0.2022.0 at time 19.03
# Profile 9227 → count = 42, date = 23.0.3.0.2022.0 at time 19.529722222222222
# Profile 9628 → count = 42, date = 28.0.10.0.2021.0 at time 20.779722222222222
# Profile 10377 → count = 42, date = 12.0.6.0.2022.0 at time 16.03388888888889
    # Profile 11556 → count = 42, date = 25.0.3.0.2022.0 at time 15.28
# Profile 6952 → count = 41, date = 16.0.6.0.2022.0 at time 14.279722222222222
    # Profile 7227 → count = 41, date = 25.0.3.0.2022.0 at time 15.030277777777778
    # Profile 7258 → count = 41, date = 27.0.5.0.2022.0 at time 15.033611111111112
# Profile 7595 → count = 41, date = 23.0.3.0.2022.0 at time 16.03
# Profile 8133 → count = 41, date = 4.0.8.0.2022.0 at time 17.033333333333335
    # Profile 8968 → count = 41, date = 27.0.10.0.2021.0 at time 18.78
# Profile 1849 → count = 40, date = 12.0.6.0.2022.0 at time 13.53

# gap_time = 0.5
# fix_day = 4
# fix_month = 8
# fix_year = 2022
# fix_time_h = 17
# plot_fixed_day(fix_day, fix_month, fix_year, fix_time_h, gap_time)

# plot_rh_only(fix_day, fix_month, fix_year)




# gap 0.5
# fix_day = 10
# fix_month = 6
# fix_year = 2022
# fix_time_h = 17
# plot_fixed_day(fix_day, fix_month, fix_year, fix_time_h)


# gap = 0.15
# fix_day = 25
# fix_month = 3
# fix_year = 2022
# fix_time_h = 15
# plot_fixed_day(fix_day, fix_month, fix_year, fix_time_h)

gap = 0.15
fix_day = 27
fix_month = 5
fix_year = 2022
fix_time_h = 15
plot_fixed_day(fix_day, fix_month, fix_year, fix_time_h)


# gap_time = 0.1
# fix_day = 4
# fix_month = 10
# fix_year = 2021
# fix_time_h = 13.7
# plot_fixed_day(fix_day, fix_month, fix_year, fix_time_h, gap_time)
