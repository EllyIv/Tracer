using CSV
using DataFrames
using NCDatasets
using Dates
using Statistics
using Polynomials
using Plots
using Measures
using FFTW

function detrend_linear(data_in, time)
    fit_data = Polynomials.fit(time, data_in, 1)
    return data_in .- fit_data.(time)
end

function moving_average_time(time_sec, values, window_sec)
    n = length(values)
    out = fill(NaN, n)

    left = 1
    right = 1

    for i in 1:n
        t0 = time_sec[i] - window_sec / 2
        t1 = time_sec[i] + window_sec / 2

        while left <= n && time_sec[left] < t0
            left += 1
        end
        while right < n && time_sec[right + 1] <= t1
            right += 1
        end

        if right >= left
            out[i] = mean(values[left:right])
        end
    end

    return out
end

function tukey_window(N::Int; alpha::Float64=0.1)
    N <= 0 && return Float64[]
    N == 1 && return [1.0]

    alpha <= 0 && return ones(Float64, N)
    alpha >= 1 && return 0.5 .* (1 .- cos.(2π .* (0:N-1) ./ (N-1)))

    w = ones(Float64, N)
    M = N - 1

    for n in 0:M
        x = n / M
        if x < alpha/2
            w[n+1] = 0.5 * (1 + cos(π * (2x/alpha - 1)))
        elseif x <= 1 - alpha/2
            w[n+1] = 1.0
        else
            w[n+1] = 0.5 * (1 + cos(π * (2x/alpha - 2/alpha + 1)))
        end
    end

    return w
end

function clean_calc_cwt_mexhat(time, x)
    dt = mean(diff(time))
    N  = length(x)
    x  = collect(float.(x))

    s0 = 2.0 * dt
    dj = 0.25
    J = Int(floor((1/dj) * log2(N * dt / s0)))
    scales = s0 .* 2 .^ ((0:J) .* dj)

    fourier_factor = 2π / sqrt(2.5)
    freqs_Hz = fourier_factor ./ scales

    X     = fft(complex.(x))
    freqs = FFTW.fftfreq(N, 1/dt)
    ω     = 2π .* freqs

    W = Array{ComplexF64}(undef, length(scales), N)

    for (j, s) in enumerate(scales)
        Ψ = similar(X)
        @inbounds for k in eachindex(ω)
            if ω[k] > 0
                Ψ[k] = (2/sqrt(3)) * π^(-1/4) *
                       sqrt(2π*s/dt) *
                       ((s*ω[k])^2) *
                       exp(-0.5 * (s*ω[k])^2)
            else
                Ψ[k] = 0.0 + 0.0im
            end
        end
        W[j, :] .= ifft(X .* conj.(Ψ))
    end

    power = abs2.(W)
    P_cwt = vec(sum(power, dims=2)) ./ size(power, 2)

    return freqs_Hz, P_cwt, W, scales
end

function from_datetime_to_sec(set_time, day_in, month_in, year_in,
    hour_in, minute_in, second_in, time_zone)

    time_sec = Dates.value.(set_time .- set_time[1]) ./ 1000

    base_datetime = DateTime(year_in, month_in, day_in, hour_in, minute_in, second_in)
    total_time_dt = base_datetime .+ Second.(round.(Int, time_sec))
    dt_local = total_time_dt .+ Hour(time_zone)

    true_year = year.(dt_local)
    true_month = month.(dt_local)
    true_day = day.(dt_local)

    true_time_sec = Dates.value.(dt_local .- DateTime.(true_year, true_month, true_day)) ./ 1000

    return true_time_sec, true_day, true_month, true_year
end

function extract_day_data_all_files(target_year, target_month, target_day;
    PATH_folder_lidar = "/home/ellai/data/archive/DOE-SC0021074 (Tracer)/level 1/houdlfptM1/",
    outdir = "/home/ellai/test_arm_data/flux_calc/VER6/output_txt/",
    time_zone = -5
)
    set_files = filter(x -> endswith(x, ".cdf"), readdir(PATH_folder_lidar))

    set_files = filter(set_files) do file
        parts = split(file, ".")
        date_str = parts[3]
        year  = parse(Int, date_str[1:4])
        month = parse(Int, date_str[5:6])
        day   = parse(Int, date_str[7:8])
        (year == target_year) && (month == target_month) && (day == target_day)
    end

    println("Number of candidate files = ", length(set_files))

    all_time_sec = Float64[]
    all_time_min = Float64[]
    all_time_hr  = Float64[]
    all_height   = Float64[]
    all_vel      = Float64[]
    all_atback   = Float64[]
    all_backsc   = Float64[]
    all_vel_p    = Float64[]
    all_back_p   = Float64[]
    all_flux     = Float64[]
    all_source   = String[]

    for file in sort(set_files)
        file_parts = split(basename(file), ".")

        init_year  = parse(Int, file_parts[3][1:4])
        init_month = parse(Int, file_parts[3][5:6])
        init_day   = parse(Int, file_parts[3][7:8])

        start_hour   = parse(Int, file_parts[4][1:2])
        start_minute = parse(Int, file_parts[4][3:4])
        start_second = parse(Int, file_parts[4][5:6])

        PATH_file = joinpath(PATH_folder_lidar, file)
        println("\nChecking ", PATH_file)

        ds = NCDataset(PATH_file, "r")
        try
            height = ds["range"][:]
            # println(height)
            idx_h = argmin(abs.(height .- 30))
            chosen_h = Float64(height[idx_h])
            println("  chosen_h = ", chosen_h)

            time_in_datetime = ds["time"][:]
            time_sec_all, true_day, true_month, true_year =
                from_datetime_to_sec(
                    time_in_datetime,
                    init_day, init_month, init_year,
                    start_hour, start_minute, start_second,
                    time_zone
                )

            println("  local hr range = ",
                    minimum(time_sec_all)/3600, "  ",
                    maximum(time_sec_all)/3600)

            vel = ds["radial_velocity"][idx_h, :]
            atbacksc = ds["attenuated_backscatter"][idx_h, :]

            good = .!ismissing.(vel) .& .!ismissing.(atbacksc)
            println("  n(good) = ", sum(good))

            if !any(good)
                continue
            end

            time_sec = Float64.(time_sec_all[good])
            vel = Float64.(vel[good])
            atbacksc = Float64.(atbacksc[good])

            dh_vals = unique(diff(height))
            dh = dh_vals[1]

            LR = 50.0
            backsc = atbacksc ./ (1 .- 2 .* LR .* atbacksc .* dh)
            backsc = backsc .* 1e6

            vel_prime = detrend_linear(vel, time_sec)
            backsc_prime = detrend_linear(backsc, time_sec)
            flux_proxy = vel_prime .* backsc_prime

            append!(all_time_sec, time_sec)
            append!(all_time_min, time_sec ./ 60)
            append!(all_time_hr, time_sec ./ 3600)
            append!(all_height, fill(chosen_h, length(time_sec)))
            append!(all_vel, vel)
            append!(all_atback, atbacksc)
            append!(all_backsc, backsc)
            append!(all_vel_p, vel_prime)
            append!(all_back_p, backsc_prime)
            append!(all_flux, flux_proxy)
            append!(all_source, fill(file, length(time_sec)))
        finally
            close(ds)
        end
    end

    if isempty(all_time_sec)
        println("No data found for filename date $(target_year)-$(target_month)-$(target_day)")
        return nothing
    end

    df = DataFrame(
        year = fill(target_year, length(all_time_sec)),
        month = fill(target_month, length(all_time_sec)),
        day = fill(target_day, length(all_time_sec)),
        time_sec = all_time_sec,
        time_min = all_time_min,
        time_hr = all_time_hr,
        height_m = all_height,
        radial_velocity = all_vel,
        attenuated_backscatter = all_atback,
        backscatter = all_backsc,
        radial_velocity_prime = all_vel_p,
        backscatter_prime = all_back_p,
        flux_proxy = all_flux,
        source_file = all_source
    )

    sort!(df, :time_sec)

    # cut to 9:00–18:00 local
    df = df[(df.time_hr .>= 9.0) .& (df.time_hr .<= 18.0), :]

    if nrow(df) == 0
        println("No data left after 9:00–18:00 cut.")
        return nothing
    end

    df.flux_proxy_ma15 = moving_average_time(df.time_sec, df.flux_proxy, 15 * 60)

    # Tukey window + CWT flux
    w = tukey_window(nrow(df), alpha=0.1)

    vel_win = df.radial_velocity_prime .* w
    back_win = df.backscatter_prime .* w

    freqs_w, P_w, W_w_cwt, scale_cwt = clean_calc_cwt_mexhat(df.time_sec, vel_win)
    freqs_c, P_c, W_c_cwt, _         = clean_calc_cwt_mexhat(df.time_sec, back_win)

    dt = mean(diff(df.time_sec))
    dj = 0.25
    Cψ = 0.776
    scale_mat = reshape(scale_cwt, :, 1)

    fcwt_w_scale_time = (dj * dt / Cψ) .* real.(W_w_cwt .* conj.(W_c_cwt)) ./ scale_mat
    fcwt_w_time = vec(sum(fcwt_w_scale_time, dims=1))

    df.flux_cwt = fcwt_w_time

    println("\nFinal extracted points = ", nrow(df))
    println("Final time range [hr] = ",
            round(minimum(df.time_hr), digits=3), " to ",
            round(maximum(df.time_hr), digits=3))
    println("Unique source files used = ", length(unique(df.source_file)))

    outfile_csv = joinpath(
        outdir,
        "extracted_lidar_allfiles_$(target_year)_$(lpad(target_month,2,'0'))_$(lpad(target_day,2,'0'))_9to18.csv"
    )
    CSV.write(outfile_csv, df)
    println(outfile_csv)

    xmin = minimum(df.time_hr)
    xmax = maximum(df.time_hr)

    p1 = plot(
        df.time_hr, df.backscatter,
        xlabel = "Time (hour local)",
        ylabel = "Backscatter",
        legend = false,
        title = "Backscatter near 105 m",
        xlims = (xmin, xmax),
        left_margin = 10mm,
        bottom_margin = 8mm,
        guidefont = font(14),
        tickfont = font(10),
        # ylims = (-1, 5)
    )

    p2 = plot(
        df.time_hr, df.radial_velocity,
        xlabel = "Time (hour local)",
        ylabel = "Radial velocity",
        legend = false,
        title = "Radial velocity near 105 m",
        xlims = (xmin, xmax),
        left_margin = 10mm,
        bottom_margin = 8mm,
        guidefont = font(14),
        tickfont = font(10)
    )

    p3 = plot(
        df.time_hr, df.flux_proxy,
        xlabel = "Time (hour local)",
        ylabel = "Flux proxy",
        legend = false,
        title = "Raw flux proxy near 105 m",
        xlims = (xmin, xmax),
        left_margin = 10mm,
        bottom_margin = 8mm,
        guidefont = font(14),
        tickfont = font(10), 
        ylims = (-0.1, 0.1)
    )
    plot!(
        p3,
        df.time_hr, df.flux_proxy_ma15,
        lw = 2,
        color = :red,
        label = "15 min avg"
    )

    p4 = plot(
        df.time_hr, df.flux_cwt,
        xlabel = "Time (hour local)",
        ylabel = "Flux CWT",
        legend = false,
        title = "CWT flux with Tukey window",
        xlims = (xmin, xmax),
        left_margin = 10mm,
        bottom_margin = 8mm,
        guidefont = font(14),
        tickfont = font(10), 
        # ylims = (-0.5, 0.5)
    )

    p_all = plot(p1, p2, p3, p4, layout = (4, 1), size = (1200, 1200))

    outfile_png = joinpath(
        outdir,
        "extracted_lidar_allfiles_$(target_year)_$(lpad(target_month,2,'0'))_$(lpad(target_day,2,'0'))_9to18.png"
    )
    savefig(p_all, outfile_png)
    println(outfile_png)

    return df
end

df_day = extract_day_data_all_files(2022, 8, 16)