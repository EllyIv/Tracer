using Glob  # for globbing the file patterns
using CSV   # for reading CSV files
using Plots # for plotting
using Colors # for color normalization
using NCDatasets # for NetCDF
using Dates  # to convert dates in sec
using Statistics # for mean
using Dierckx     # For detrend (spline interpolation)
using Polynomials
using StatsBase 
using DSP  
using DelimitedFiles
using Measures
using LaTeXStrings
using Interpolations
using LsqFit #for curve fitting 
using LaTeXStrings
using GLM
using DataFrames
using StatsModels

# const PATH_output_png = "/home/ellai/test_arm_data/flux_calc/VER6/output_png/"
# const PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER6/output_txt/"
include("../paths_for_all.jl")

function find_number_of_the_profile(day, month, year, time_in)
    number_set = zeros(Int, length(time_in))
    unique_comb = unique(zip(time_in, day, month, year))

    for (k, (ti, d, m, y)) in enumerate(unique_comb)
        inds = findall(i -> time_in[i] == ti && day[i] == d && month[i] == m && year[i] == y, eachindex(time_in))
        number_set[inds] .= k
    end   
    return number_set
end 


function normalize_height(fix_t, day, month, year, input_data_pbl1)
    #[pbl1[1], pbl2[1], day[1], hours, month[1], year[1]]
    # day_lidar, m_lidar, y_lidar, t_lidar, pbl_set1
    day_pbl, month_pbl, year_pbl = input_data_pbl1[:, 1], input_data_pbl1[:, 2], input_data_pbl1[:, 3]
    time_pbl, pbl_h = input_data_pbl1[:, 4], input_data_pbl1[:, 5]
    
    fix_t = floor(Float64, fix_t)
    mask = (time_pbl .== fix_t) .&(day_pbl .== day) .& (month_pbl .== month) .& (year_pbl .== year)
    # println("clouds ", cld_h[mask])

    if !isempty(pbl_h[mask])
        return pbl_h[mask][1]
    else 
        return missing
    end
end  



function get_non_missing_data(raw_input_data)
    h0_1, f0_1, b0_1, w0_1, n0_1 = raw_input_data[:, 1], raw_input_data[:, 2], raw_input_data[:, 3], raw_input_data[:, 4], raw_input_data[:, 9]
    h0_1 = replace(h0_1, "missing" => missing)
    f0_1 = replace(f0_1, "missing" => missing)
    b0_1 = replace(b0_1, "missing" => missing)
    w0_1 = replace(w0_1, "missing" => missing)
    
    inds_missing = findall(i -> ismissing(h0_1[i]) || ismissing(f0_1[i]) || ismissing(b0_1[i]) || ismissing(w0_1[i]), eachindex(h0_1))

    keep_inds = setdiff(1:length(h0_1), inds_missing)

    h0_1 = h0_1[keep_inds]
    f0_1 = f0_1[keep_inds]
    b0_1 = b0_1[keep_inds]
    w0_1 = w0_1[keep_inds]
    n0_1 = n0_1[keep_inds]

    return h0_1, f0_1, b0_1, w0_1, n0_1 
end 


function find_regime(fix_t, day, month, year, data_rgm)
    day_rgm, month_rgm, year_rgm = data_rgm[:, 1], data_rgm[:, 2], data_rgm[:, 3]
    time_rgm, u_rgm, h_rgm = data_rgm[:, 4] , data_rgm[:, 5], data_rgm[:, 6]
    
    fix_t = floor(Float64, fix_t)
    mask = (time_rgm .== fix_t) .&(day_rgm .== day) .& (month_rgm .== month) .& (year_rgm .== year)

    if !isempty(u_rgm[mask]) && !isempty(h_rgm[mask])
        return u_rgm[mask][1], h_rgm[mask][1]
    else 
        return missing, missing
    end
end  


function normalized_flux(file_suffixes)
    println("hey")
    # input_data = readdlm(PATH_output_txt * suffix)
    input_data_list = [readdlm(PATH_output_txt * suffix) for suffix in file_suffixes]
    input_data = vcat(input_data_list...)

    #day, month, year, time_f, height, w2_mean, backscat_mean, flux_corr, w2_std, backscat_std, flux_std, time_range
    day, month, year = input_data[:, 1], input_data[:, 2], input_data[:, 3]
    time_in, time_range = input_data[:, 4], input_data[:, 12]
    height = input_data[:, 5]
    w2_mean, w2_std = input_data[:, 6], input_data[:, 9]
    backscat_mean, backscat_std = input_data[:, 7], input_data[:, 10]
    flux_mean, flux_std = input_data[:, 8], input_data[:, 11]
    stability, cleanliness  =  input_data[:, 13], input_data[:, 14]
    
    flux105  = []
    for i in eachindex(height)
        if abs(height[i] - 105) <= 10
            push!(flux105, flux_mean[i])
        else
            push!(flux105, missing)
        end
    end


    number_of_the_profile = find_number_of_the_profile(day, month, year, time_in)

    flux_mean = replace(flux_mean, "missing" => missing)
    println("maximum flux ", maximum(skipmissing(flux_mean)))
   
    info_pbl_height = [] 
    input_file_pbl = PATH_output_txt * "pbl_aligned_with_lidar_filtered.txt"
    pbl_info = readdlm(input_file_pbl)
    println("0")

    for t_ind in 1:length(time_in)
        t = time_in[t_ind]
        norm_height = normalize_height(t.*3600, day[t_ind], month[t_ind], year[t_ind], pbl_info) #true , false 
        push!(info_pbl_height, norm_height)
    end 
    h_data = height ./ info_pbl_height
    println("1")

    info_rgm_u = [] 
    info_rgm_h = [] 
    input_file_rgm  = PATH_output_txt * "regime_aligned_with_lidar_wo_grouping.txt" #sec
    rgm_info = readdlm(input_file_rgm)
    println("2")

    for t_ind in 1:length(time_in)
        t = time_in[t_ind]
        new_u, new_h = find_regime(t.*3600, day[t_ind], month[t_ind], year[t_ind], rgm_info)  
        push!(info_rgm_u, new_u)
        push!(info_rgm_h, new_h)
    end 

    println("3")

    new_suffix ="fluxH_MOD_norm_RAW_DATA2.txt"
    println(new_suffix)
    output_file_raw = PATH_output_txt * new_suffix
    writedlm(output_file_raw, hcat(h_data, flux_mean, backscat_mean, w2_mean, day, month, year, time_in, number_of_the_profile, info_rgm_u, info_rgm_h, stability, cleanliness, flux105))

end 

# file_suffixes = ["fluxH_MOD_neutral_nonclean.txt", "fluxH_MOD_neutral_clean.txt",  "fluxH_MOD_unstable_nonclean.txt",  "fluxH_MOD_unstable_clean.txt"]
# normalized_flux(file_suffixes)

file_suffixes = ["fluxH_MOD_stable_nonclean.txt", "fluxH_MOD_stable_clean.txt"]
normalized_flux(file_suffixes)

# file_suffixes = ["fluxH_MOD_neutral_nonclean.txt", "fluxH_MOD_neutral_clean.txt",  "fluxH_MOD_unstable_nonclean.txt",  "fluxH_MOD_unstable_clean.txt"]

function combine_rh(file_suffixes)
    println("hey")

    input_data_list = [readdlm(PATH_output_txt * suffix) for suffix in file_suffixes]
    input_data = vcat(input_data_list...)

    height_norm, rh, temp, profile_num = input_data[:, 1], input_data[:, 2], input_data[:, 3], input_data[:, 4]

    unique_profiles = unique(profile_num)
    count_profiles = [count(==(num), profile_num) for num in unique_profiles]
    println("1")

    max_prof = maximum(count_profiles)
    norm_profiles = count_profiles ./ max_prof

    mask_complete = norm_profiles .>= 0.8
    mask_incomplete = .!mask_complete
    println("1")


    num_complete = unique_profiles[mask_complete]
    num_incomplete = unique_profiles[mask_incomplete]

    complete_mask = map(p -> p in num_complete, profile_num)
    incomplete_mask = .!complete_mask
    println("2")

    complete_info = input_data[complete_mask, :]
    incomplete_info = input_data[incomplete_mask, :]

    output_file_comp = PATH_output_txt * "rh_complete.txt"
    writedlm(output_file_comp, complete_info)

    output_file_incomp = PATH_output_txt * "rh_incomplete.txt"
    writedlm(output_file_incomp, incomplete_info)

    println("rh_complete.txt")
    println("rh_incomplete.txt")
end



# file_suffixes_rh_raw_data = ["rh_height_filter_unstable_nonclean_1_RAW_DATA.txt", "rh_height_filter_unstable_nonclean_2_RAW_DATA.txt","rh_height_filter_unstable_nonclean_3_RAW_DATA.txt","rh_height_filter_unstable_nonclean_4_RAW_DATA.txt", 
#                     "rh_height_filter_unstable_clean_1_RAW_DATA.txt", "rh_height_filter_unstable_clean_2_RAW_DATA.txt","rh_height_filter_unstable_clean_3_RAW_DATA.txt","rh_height_filter_unstable_clean_4_RAW_DATA.txt",
#                     "rh_height_filter_neutral_nonclean_1_RAW_DATA.txt", "rh_height_filter_neutral_nonclean_2_RAW_DATA.txt","rh_height_filter_neutral_nonclean_3_RAW_DATA.txt","rh_height_filter_neutral_nonclean_4_RAW_DATA.txt",
#                     "rh_height_filter_neutral_clean_1_RAW_DATA.txt", "rh_height_filter_neutral_clean_2_RAW_DATA.txt","rh_height_filter_neutral_clean_3_RAW_DATA.txt","rh_height_filter_neutral_clean_4_RAW_DATA.txt"]
# combine_rh(file_suffixes_rh_raw_data)
# file_suffixes_rh = ["rh_height_filter_unstable_nonclean_1.txt", "rh_height_filter_unstable_nonclean_2.txt","rh_height_filter_unstable_nonclean_3.txt","rh_height_filter_unstable_nonclean_4.txt", 
#                     "rh_height_filter_unstable_clean_1.txt", "rh_height_filter_unstable_clean_2.txt","rh_height_filter_unstable_clean_3.txt","rh_height_filter_unstable_clean_4.txt",
#                     "rh_height_filter_neutral_nonclean_1.txt", "rh_height_filter_neutral_nonclean_2.txt","rh_height_filter_neutral_nonclean_3.txt","rh_height_filter_neutral_nonclean_4.txt",
#                     "rh_height_filter_neutral_clean_1.txt", "rh_height_filter_neutral_clean_2.txt","rh_height_filter_neutral_clean_3.txt","rh_height_filter_neutral_clean_4.txt"]
# file_suffixes_rh_raw_data = ["rh_height_filter_unstable_nonclean_1_RAW_DATA.txt", "rh_height_filter_unstable_nonclean_2_RAW_DATA.txt","rh_height_filter_unstable_nonclean_3_RAW_DATA.txt","rh_height_filter_unstable_nonclean_4_RAW_DATA.txt", 
#                     "rh_height_filter_unstable_clean_1_RAW_DATA.txt", "rh_height_filter_unstable_clean_2_RAW_DATA.txt","rh_height_filter_unstable_clean_3_RAW_DATA.txt","rh_height_filter_unstable_clean_4_RAW_DATA.txt",
#                     "rh_height_filter_neutral_nonclean_1_RAW_DATA.txt", "rh_height_filter_neutral_nonclean_2_RAW_DATA.txt","rh_height_filter_neutral_nonclean_3_RAW_DATA.txt","rh_height_filter_neutral_nonclean_4_RAW_DATA.txt",
#                     "rh_height_filter_neutral_clean_1_RAW_DATA.txt", "rh_height_filter_neutral_clean_2_RAW_DATA.txt","rh_height_filter_neutral_clean_3_RAW_DATA.txt","rh_height_filter_neutral_clean_4_RAW_DATA.txt"]
