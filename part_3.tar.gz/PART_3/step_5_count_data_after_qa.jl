using CSV
using DataFrames

const PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER6/output_txt/"

function stability_code(stab::AbstractString)
    s = lowercase(strip(stab))
    s == "unstable" && return -1
    s == "neutral"  && return 0
    s == "stable"   && return 1
    error("Unknown stability='$stab'. Use: unstable | neutral | stable")
end

function condition_code(cond::AbstractString)
    c = lowercase(strip(cond))
    c == "clean"    && return 1
    c == "nonclean" && return -1
    error("Unknown condition='$cond'. Use: clean | nonclean")
end

function main(stability::AbstractString, condition::AbstractString)
    file = joinpath(PATH_output_txt, "fluxH_MOD_norm_RAW_DATA2.txt")

    # Read as TSV, no header
    df = CSV.read(file, DataFrame;
        delim = '\t',
        header = false,
        missingstring = "missing",
        ignorerepeated = false
    )

    println("Read file with ncol(df) = ", ncol(df))

    # Define the *expected* first columns (based on how you wrote the file)
    base_names = Symbol[
        :h_data, :flux_mean, :backscat_mean, :w2_mean,
        :day, :month, :year, :time_in, :number_of_the_profile,
        :info_rgm_u, :info_rgm_h, :stability, :cleanliness, :flux105
    ]  # length = 14

    # If file has extra columns, name them :extra_1, :extra_2, ...
    if ncol(df) < length(base_names)
        error("File has only $(ncol(df)) columns, but at least $(length(base_names)) expected. Check delimiter / file format.")
    end

    names_to_set = copy(base_names)
    if ncol(df) > length(base_names)
        nextra = ncol(df) - length(base_names)
        append!(names_to_set, [Symbol("extra_", i) for i in 1:nextra])
    end

    rename!(df, names_to_set)

    # Now filter
    stab_const  = stability_code(stability)
    clean_const = condition_code(condition)

    df_filt = filter(r -> r.stability == stab_const && r.cleanliness == clean_const, df)

    println("Filtered rows: ", nrow(df_filt))
    println("Unique profiles: ", length(unique(df_filt.number_of_the_profile)))
    # println("Unique days: ", length(unique(zip(df_filt.year, df_filt.month, df_filt.day))))

    # return df_filt
end

# input
set_stab = ["stable"]#, "neutral", "unstable"]
set_cloud = ["nonclean", "clean"]
# stability = "stable"
# condition = "nonclean"
for stability in set_stab
    for condition in set_cloud
        println(stability,  " ", condition)
        df_selected = main(stability, condition)
        println()
    end 
end 
