using Glob 
using CSV   
using Plots 
using Colors 
using NCDatasets 
using Dates  
using Statistics 
using Dierckx     
using Polynomials
using StatsBase 
using DSP  
using DelimitedFiles
using Measures
using LaTeXStrings
using Interpolations
using LsqFit 
using Distributed
addprocs(64)

# @everywhere include("/home/ellai/test_arm_data/flux_calc/VER4/step_3_calc_flux_ll.jl")

# atexit(() -> rmprocs(workers()))

@everywhere using NCDatasets, Statistics, Interpolations, LsqFit, Dates, Polynomials
@everywhere using Glob, DelimitedFiles

@everywhere function from_datetime_to_sec(set_time, day_in, month_in, year_in, time_zone)
    time_sec = hour.(set_time) .* 3600 .+ minute.(set_time) .* 60 .+ second.(set_time) 
    
    base_datetime = DateTime(year_in, month_in, day_in)
    total_time_dt = base_datetime .+ Second.(time_sec)
    dt_local = total_time_dt .+ Hour(time_zone)

    true_year = year.(dt_local)
    true_month = month.(dt_local)
    true_day = day.(dt_local)

    true_time_sec = Dates.value.(dt_local .- DateTime.(true_year, true_month, true_day)) ./ 1000

    return true_time_sec, true_day, true_month, true_year
end 

@everywhere function shiftsignal(signal::Vector{<:Real}, shift::Int)
    return vcat(fill(NaN, shift), signal[1:end-shift])
end



@everywhere function block_division(set_time)
    pause_ind = vcat(findall(abs.(diff(set_time)) .> 2), length(set_time))  # find indices where step > 2 and add last index
    # println(pause_ind)
    # println(findall(abs.(diff(set_time)) .> 2))
    # sleep(5)
    # println(diff(set_time)[end-5:])
    # println(pause_ind)
    # println(set_time[end-5:end])
    # println(diff(set_time)[end-4:end])
    # println(length(diff(set_time)), " ", length(set_time))
    # println(" ")
    if pause_ind[1] != 1
        index_in = [1; pause_ind[1:end-1] .+ 1]
        index_out = pause_ind 
    else 
        index_in = pause_ind[1:end-1] .+ 1
        index_out = pause_ind[2:end]
    end
    # println(pause_ind)
    # println(index_in)
    # println(index_out)
    # println(set_time[index_in[end]: index_out[end]][end-5:end])
    # println(" ")
    # sleep(15)
    # println("dwd ", pause_ind) 
    # if pause_ind[end] == 3119
    #     println("hiii")
    #     println(index_in, " ", index_out)
    #     println( " ", length(set_time))
    #     println(set_time[index_in], set_time[index_out])
    #     println(diff(set_time)[end-3:end])
    # end  
    
    blocks = []
    for i in eachindex(index_in)
        block_size = index_out[i] - index_in[i]
        if block_size > 600 
            push!(blocks, (index_in[i], index_out[i], block_size)) 
        end
    end
    return blocks
end

@everywhere function is_signal_good(signal)
    diff_signal = signal .- shiftsignal(signal, 1)
    spikes = (diff_signal .> 1.5) .| (diff_signal .< -1.5)
    spike_ratio = sum(spikes) / length(diff_signal)
    # println("Spike ratio: ", spike_ratio, " ", sum(spikes), " ", length(diff_signal))
    
    if spike_ratio < 0.05
        return true  # signal is mostly good
    else
        # p1 = plot(signal)
        # PATH_output_png = "/home/ellai/test_arm_data/flux_calc/VER4/output_png/"
        # savefig(p1, PATH_output_png*"test_del.png")
        return false # too many spikes
    end
end

@everywhere function calc_flux(time_int, vel_int, back_int, month, year, day, diff_t, hh, stab_zl) 
    time_in = time_int[1] # beginning
    sample_period  = time_int[end] - time_int[1] # range 

    mean_w = mean(vel_int)
    std_w = std(vel_int)
    var_w = detrend(vel_int, time_int)
    mean_var_w2 = mean(var_w .* var_w)
    std_var_w2 = std(var_w .* var_w)

    mean_b = mean(back_int)
    std_b = std(back_int)
    var_b = detrend(back_int, time_int)
    mean_var_b = mean(var_b)
    std_var_b = std(var_b)

    flux_int = var_w .* var_b
    mean_f = mean(flux_int)
    std_f = std(flux_int)

    
    flag_good_signal = is_signal_good(var_w)

    lower = mean_var_b - 2 * std_var_b
    upper = mean_var_b + 2 * std_var_b

    good_mask = (var_b .>= lower) .& (var_b .<= upper)
    clean_var_b = var_b[good_mask]
    percent_of_filtering = length(clean_var_b)/length(var_b)
    # if percent_of_filtering < 0.95
    # if flag_good_signal == false  && day == 21 && month == 1 
        # println(day, " ", month," ", year, " ", time_int[1], " ", hh)
        # plot(var_w)
        # sleep(5)
    # end 
    # if flag_good_signal
    #     continue
    # else
    #     return []
    # end
    
    if mean_b <= 30 && std_b <= 30   && flag_good_signal && percent_of_filtering >= 0.95
        var_w = var_w[good_mask]
        var_b = var_b[good_mask]
        time_int = time_int[good_mask]
        flux_int = flux_int[good_mask]
        # if flag_good_signal == false 
        #     println(day, " ", month," ", year)
        #     # plot(var_w)
        #     sleep(10)
        # end 
        # LOD
        lag_range = 200:10:300
        # lod_fluxes = [calc_lod_lag_method(time_int, var_b, var_w, lag) for lag in lag_range]
        # println(time_int[end-2:end])
        # println(var_w)
        itp = extrapolate(interpolate((time_int,), var_w, Gridded(Linear())), NaN)
        lod_fluxes = [calc_lod_lag_method_prebuilt(itp, time_int, var_b, lag) for lag in lag_range]

        lod_mean = mean(lod_fluxes)
        
        if lod_mean < mean_f
            # equation 11 in Petters-2024
            delta_w, _ = calc_uncert_irregular(time_int, var_w)
            delta_b, _ = calc_uncert_irregular(time_int, var_b)
            delta_f, II_f = calc_uncert_irregular(time_int, flux_int)

            N = length(time_int)
            
            # random noise 
            err_noise2 = mean(var_b .^ 2) * delta_b / N + mean(var_w .^ 2) * delta_w / N
            err_noise = err_noise2 > 0 ? sqrt(err_noise2) : 0.0
            # random_noise_criteria = abs(f_uncert_noise/mean_f)
  
            # sample noise 
            err_sample = 2 * II_f/ sample_period *(mean_f - (std_w^2 - delta_w^2)*(std_b^2 - delta_b^2))
            # sample_noise_criteria = abs(err_sample/mean_f)
            
            # ensemble average 
            err_ensemble = 2 * II_f/ sample_period * mean_f
            # err_noise2 = mean(var_b .^ 2) * delta_b / N + mean(var_w .^ 2) * delta_w / N
            # f_uncert_noise = err_noise2 > 0 ? sqrt(err_noise2) : 0.0
            
            return [day, month, year, time_in, diff_t, hh, mean_b, std_b, mean_w, std_w, mean_var_w2, std_var_w2, mean_f, std_f, lod_mean,  err_noise, err_sample, err_ensemble, stab_zl]
        else
            # println("----------------------")
            return []
        end 
    else 
        return []    
    end 
end


@everywhere function detrend(data_in, time)
    data_in = replace(data_in, "missing" => missing)
    data_in = Float64.(data_in)
    fit_data = Polynomials.fit(time, data_in, 1)
    detrended_data = data_in .- fit_data.(time)
    return detrended_data
end



# since time is non uniform I can't use conv(signal1, reverse(signal2)), to get cross-correlation between signal1 and signal2 for all possible lags 
# unique(diff(t)) = [1, 2]  
@everywhere function calc_lod_lag_method(t, beta_prime, v_prime, lag_sec)
    itp_core = interpolate((t,), v_prime, Gridded(Linear()))
    itp = extrapolate(itp_core, NaN) 

    t_shifted = t .+ lag_sec
    v_lagged = itp.(t_shifted)

    valid_idx = .!isnan.(v_lagged)
    beta_valid = beta_prime[valid_idx]
    v_lagged_valid = v_lagged[valid_idx]
    lod_flux = mean(beta_valid .* v_lagged_valid)

    return lod_flux
end

@everywhere function calc_lod_lag_method_prebuilt(itp, t, beta_prime, lag_sec)
    t_shifted = t .+ lag_sec
    v_lagged = itp.(t_shifted)
    valid_idx = .!isnan.(v_lagged)
    beta_valid = beta_prime[valid_idx]
    v_lagged_valid = v_lagged[valid_idx]
    return mean(beta_valid .* v_lagged_valid)
end


@everywhere function calc_cov_irregular_time(t, x, lag_sec)
    itp = extrapolate(interpolate((t,), x, Gridded(Linear())), NaN)
    t_shifted = t .+ lag_sec
    x_lagged = itp.(t_shifted)
    valid = .!isnan.(x_lagged)
    return mean(x[valid] .* x_lagged[valid])
end

@everywhere function calc_uncert_irregular(t, signal_t)
    max_lag = 200
    lag_grid = 0:1:max_lag
    cvr = [calc_cov_irregular_time(t, signal_t, lag) for lag in lag_grid]

    min_lag_fit = 1
    max_lag_fit = 50
    for c in 1:(length(cvr) - 1)
        if cvr[c+1] <= 0 && cvr[c] > 0
            max_lag_fit = c + 1
            break
        end
    end

    x_fit = lag_grid[min_lag_fit:max_lag_fit]
    y_fit = cvr[min_lag_fit:max_lag_fit]
    model(x, p) = p[1] .* exp.(-p[2] .* x)
    fit = curve_fit(model, x_fit, y_fit, [1.0, 0.01])
    nu, k = fit.param

    if nu / k < 0
        nu = -nu
    end
    delta_noise = cvr[1] - nu
    I_noise = (2 / 5) * (nu / k)^(3 / 2)

    return (delta_noise, I_noise)
end

@everywhere function  calc_corr_factor(wind_info)
    # println(wind_info)
    corr_factors = []
    zm = 105 
    alpha = 7/8 
    tau = 10 
    nm = 0.085

    corr_factors = 1 .+ ((2 * pi * nm .* tau .* wind_info) ./ zm) .^ alpha
    # println("mean corr factor ", mean(skipmissing(corr_factors)), " max:", maximum(skipmissing(corr_factors)), " min:", minimum(skipmissing(corr_factors)))
    cf_clean = collect(skipmissing(corr_factors))

    if !isempty(cf_clean)
        println("mean corr factor: ", mean(cf_clean), " max: ", maximum(cf_clean), " min: ", minimum(cf_clean))
    else
        println("No valid correlation factors (all missing).")
    end
    # println(cf_clean)
    return corr_factors
end  

@everywhere function calc_105_flux(time_int, vel_int, back_int, month, year, day, diff_t, stab_zl) 
    time_in = time_int[1] # beginning
    # println(time_int)
    mean_w = mean(vel_int)
    std_w = std(vel_int)
    var_w = detrend(vel_int, time_int)
    mean_var_w2 = mean(var_w .* var_w)
    std_var_w2 = std(var_w .* var_w)

    mean_b = mean(back_int)
    std_b = std(back_int)
    var_b = detrend(back_int, time_int)
    
    flux_int = var_w .* var_b
    mean_f = mean(flux_int)
    std_f = std(flux_int)

    if mean_b <= 30 && std_b <= 30 
        # LOD
        lag_range = 200:10:300
        # lod_fluxes = [calc_lod_lag_method(time_int, var_b, var_w, lag) for lag in lag_range]
        # println(time_int[end-2:end])
        # println(var_w)
        itp = extrapolate(interpolate((time_int,), var_w, Gridded(Linear())), NaN)
        lod_fluxes = [calc_lod_lag_method_prebuilt(itp, time_int, var_b, lag) for lag in lag_range]

        lod_mean = mean(lod_fluxes)
        
        if lod_mean < mean_f
            # equation 11 in Petters-2024
            delta_w, _ = calc_uncert_irregular(time_int, var_w)
            delta_b, _ = calc_uncert_irregular(time_int, var_b)
            N = length(time_int)

            err_noise2 = mean(var_b .^ 2) * delta_b / N + mean(var_w .^ 2) * delta_w / N
            f_uncert_noise = err_noise2 > 0 ? sqrt(err_noise2) : 0.0
            # fcorr = mean_f *corr_coef

            return [day, month, year, time_in, diff_t, 105, mean_b, std_b, mean_w, std_w, mean_var_w2, std_var_w2, mean_f, std_f, lod_mean, f_uncert_noise, stab_zl]
        else
            println("----------------------")
            return []
        end 
    else 
        return []    
    end 
end


@everywhere function find_wind_speed(info_w, time_filtered, day_filtered, month_filtered, year_filtered, h_filtered)
    # [time_one, wind_spd, wind_dir, month[ind],  year[ind], day[ind]
    day_w = info_w[:, 1]    
    month_w = info_w[:, 2]
    year_w = info_w[:, 3]
    time_w = info_w[:, 4] 
    height_w = info_w[:, 5]
    wind_spd = info_w[:, 6]
    
    time_filtered = time_filtered ./3600
    inds = collect(eachindex(time_filtered))

    function compute_one(i)
        h_i = h_filtered[i]
        closest_h = height_w[argmin(abs.(height_w .- h_i))]
    
        if closest_h - h_i != 0 
            println("height for wind ", closest_h, " ", h_i)
        end    
    
        same_day_inds = findall(
            year_w .== year_filtered[i] .&&
            month_w .== month_filtered[i] .&&
            day_w .== day_filtered[i] .&&
            height_w .== closest_h
        )
    
        if !isempty(same_day_inds)
            diff_t = abs.(time_w[same_day_inds] .- time_filtered[i])
            close_inds = findall(diff_t .<= 1.0)
    
            if !isempty(close_inds)
                closest_idx = same_day_inds[argmin(diff_t[close_inds])]
                return wind_spd[closest_idx]
            end
        end
        return missing
    end
    # sleep(1000)
    
    # wind_result = Vector{Union{Missing, Float64}}(undef, length(time_filtered))

    # for i in eachindex(time_filtered)
    #     closest_h = height_w[argmin(abs.(height_w .- h_filtered[i]))] # 107 m  good enough for now! 
    #     # diffs_h = abs.(height_w .- h_filtered[i])
    #     # sorted_indices_h = sortperm(diffs_h)
    #     # i1, i2 = sorted_indices_h[1:2]
    #     # if height_w[i1] > height_w[i2]
    #     #     i1, i2 = i2, i1
    #     # end
    #     # x1, x2 = height_w[i1], height_w[i2]
        
    #     # y1, y2 = value_array[i1], value_array[i2]
    #     # closest_h = y1 + (h_filtered[i] - x1) * (y2 - y1) / (x2 - x1)
    #     if closest_h - h_filtered[i] != 0 
    #         println("height for wind ", closest_h, " ", h_filtered[i])
    #     end    
    #     same_day_inds = findall(year_w .== year_filtered[i] .&& month_w .== month_filtered[i] .&& day_w .== day_filtered[i] .&& height_w .== closest_h)
    #     # println("0 ", same_day_inds)
    #     if !isempty(same_day_inds)
    #         diff_t = abs.(time_w[same_day_inds] .- time_filtered[i])
    #         # println(time_w[same_day_inds] )
    #         # println(time_filtered[i])
    #         # sleep(5)
    #         close_inds = findall(diff_t .<= 1.0)
    #         # println("1 ", close_inds)
    #         if !isempty(close_inds)
    #             closest_idx = same_day_inds[argmin(diff_t[close_inds])]
    #             wind_result[i] = wind_spd[closest_idx]
    #         else
    #             wind_result[i] = missing
    #         end
    #     else
    #         wind_result[i] = missing
    #     end
    # end

    # return wind_result
    return pmap(compute_one, inds)

end



@everywhere function read_lidar_data_for_one_file(PATH_file, init_day, time_zone, init_month , init_year, filtered_time_info)
    dataset = NCDataset(PATH_file, "r")

    # variable_names = keys(dataset)
    # println("Variables in the dataset: ", variable_names)
    # sleep(100)
    day_fltr = filtered_time_info[:, 1]
    month_fltr = filtered_time_info[:, 2]
    year_fltr = filtered_time_info[:, 3]
    time_fltr = filtered_time_info[:, 4] #.* 3600
    
    pblh_fltr = filtered_time_info[:, 5] 
    cldh_fltr = filtered_time_info[:, 6] 
    stab_fltr = filtered_time_info[:, 7] 
    rh_fltr = filtered_time_info[:, 8] 

    cldh_fltr = [x == "missing" ? missing : (x isa String ? parse(Float64, x) : x) for x in cldh_fltr]
    pblh_fltr = [x == "missing" ? missing : (x isa String ? parse(Float64, x) : x) for x in pblh_fltr]    

    all_fltr_days = collect(zip(year_fltr, month_fltr, day_fltr))
    println("amounts of days ", size(all_fltr_days))
    
    all_info = []
    info_one_file = []
    # ind_h_in = 3
    # height = dataset["range"][:]
    # # ind_h_in = findall(x -> x == 105, h)

    # ind_h_in  = argmin(abs.(height .- 105)) 
    # check_105 = abs.(height .- 105)
    # println(check_105[1:5])
    # println(argmin(abs.(height .- 105)) )
    # # println()
    # if height[ind_h_in] >= 105 && ind_h_in != 1
    #     ind_h_in = ind_h_in - 1
    # end 
    # # if ind_h_in != 3 
    # println(ind_h_in, " ", height[ind_h_in], height[1:5])
    # # sleep(1)
    # # end 
    ind_h_in = 1 
    try 
        # height = dataset["range"][ind_h_in:end]
        height = dataset["range"][:]
        # println(height[1:3])
        # ind_h = argmin(abs.(height .- 2000)) # index where height is almost 2000 m
        # ind_h = argmin(abs.(height .- 105)) 

        dh = unique(diff(height))[1]
        if length(unique(diff(height))) > 1
            println( "You have a problem, dh is not always 30 m .. check  your code: ", unique(diff(height)))
            sleep(1000)
        end 
        # println("only for height <= ", height[ind_h], " m")
        

        time_in_datetime = dataset["time"][:] # sec in considered day (without taking into account day, month or year. and w/o timezome )
        time_in_sec, day, month, year =  from_datetime_to_sec(time_in_datetime, init_day, init_month, init_year, time_zone)
        set_blocks_ind = block_division(time_in_sec)



        # println(time_fltr[1:10])
        # println(time_in_sec[1:10])
        # sleep(100)
        if set_blocks_ind != false 
            for ind_t in set_blocks_ind
                # println(ind_t[1]," ",  ind_t[2])
                # println(time_in_sec[ind_t[1]], " ", time_in_sec[ind_t[2]])
                # println(diff(time_in_sec)[3115:end])
                # println(time_in_sec[3115:end])
                check_date = (year[ind_t[1]], month[ind_t[1]], day[ind_t[1]])
                if (check_date in all_fltr_days)
                    all_fltr_days_array = collect(all_fltr_days) 
                    idxs_fltr = findall(==(check_date), all_fltr_days_array)
                    for idx in idxs_fltr
                        if abs(time_fltr[idx] - time_in_sec[ind_t[1]]) <= 0.5                            
                            time_range = time_in_sec[ind_t[1]:ind_t[2]]
                            check_diff = diff(time_range)
                            bad_vals = filter(x -> x < 0 || x > 2, check_diff)

                            if !isempty(bad_vals)
                                println("Found values outside [0, 2]: ", unique(bad_vals))
                                sleep(100000)
                            end
                            if !ismissing(pblh_fltr[idx]) 
                                height_boundary = min(cldh_fltr[idx], pblh_fltr[idx])
                            else 
                                height_boundary = min(cldh_fltr[idx], 4000)
                            end 
                            ind_h = argmin(abs.(height .- height_boundary)) 
                            
                            for hh in 1:ind_h
                                # if height[hh] == 105 
                                #     println("im here , hello, ", hh)
                                #     sleep(5)
                                # end
                                if height[hh] <= rh_fltr[idx] 
                                    # if height[hh] == 105
                                    #     println("still im here , hello, ", hh)
                                    # end 
                                    vel = dataset["radial_velocity"][hh, ind_t[1]:ind_t[2]]
                                    atbacksc = dataset["attenuated_backscatter"][hh, ind_t[1]:ind_t[2]] 
                                    # spikes_filter(vel)
                                    #calculation of the real beta, not attenuated  
                                    LR = 50 # lidar ratio
                                    backsc = atbacksc ./ (1 .- 2 .* LR .* atbacksc .* dh)
                                    backsc = backsc .* 1e6

                                    if !any(ismissing.(vel)) && !any(ismissing.(atbacksc))
                                        info_one_file = calc_flux(time_range, vel, backsc, month[ind_t[1]], year[ind_t[1]], day[ind_t[1]], ind_t[3], height[hh], stab_fltr[idx])
                                    else
                                        println("aaa smth is missing ") 
                                    end 
                                    if length(info_one_file) != 0 
                                        # println("still here ")
                                        # println()
                                        # sleep(5)
                                        all_info = push!(all_info, info_one_file)
                                    end
                                end
                            end
                        end 
                    end 
                end 
            end 
        end
    finally 
        close(dataset)
    end
    # if size(all_info) != (0,)
    #     println(size(all_info))
    #     println(maximum([x[13] for x in all_info]), " ", [x[13] for x in all_info])
    #     sleep(2)
    # end 
    return all_info
end

@everywhere function process_lidar_file(file::String, PATH_folder_lidar::String,  time_zone, filtered_time_info)
    file_parts = split(basename(file), ".")
    day = file_parts[3][7:8]
    month = file_parts[3][5:6]
    year = file_parts[3][1:4]

    # delete this part 
    # if parse(Int, month) == 6
    PATH_file = joinpath(PATH_folder_lidar, file)
    return read_lidar_data_for_one_file(PATH_file, parse(Int, day), time_zone, parse(Int, month), parse(Int, year), filtered_time_info)
    # else
        # return []
    # end
end

function main(flag_condition, flag_stability)
    PATH_folder_lidar = "/home/ellai/data/archive/DOE-SC0021074 (Tracer)/level 1/houdlfptM1/"
    PATH_output_png = "/home/ellai/test_arm_data/flux_calc/VER6/output_png/"
    PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER6/output_txt/"
    
    input_file_w = PATH_output_txt * "wind_profile_interp.txt"
    info_wind = readdlm(input_file_w)

    file_name = "filtered_time_lidar_"*flag_stability*"_"*flag_condition*".txt"  #l_day, l_month, l_year, l_time, set_pbl_h, set_cld_h, set_stblt]
    filtered_time_info = readdlm(PATH_output_txt * file_name) # (3309, 4), (2461,); 933 - 608
    
    # file_name_rh = "sonde_interpolated_rh_$(flag_stability)_$(flag_clouds).txt"  #l_day, l_month, l_year, l_time, set_pbl_h, set_cld_h, set_stblt]
    # filtered_time_info_rh = readdlm(PATH_output_txt * file_name) 
    
    
    time_zone = -5 # houston 
    info_all_files = []

    set_files = filter(x -> endswith(x, ".cdf"), readdir(PATH_folder_lidar))
   
    info_all_files_list = pmap(file -> process_lidar_file(file, PATH_folder_lidar, time_zone, filtered_time_info), set_files)
    info_all_files = reduce(vcat, info_all_files_list)
    println("Final size: ", size(info_all_files))

    # for file in set_files
    #     println(file)
    #     file_parts = split(basename(file), ".")
    #     day = file_parts[3][7:8]
    #     month = file_parts[3][5:6]
    #     year = file_parts[3][1:4]
    #     # if  parse(Int, month) == 5  && parse(Int, day) == 12
    #     println("day ", day, " month ", month ," year ", year)
    #     if parse(Int, year) == fixyear   
    #         PATH_file = PATH_folder_lidar * file
    #         info_one_file = read_lidar_data_for_one_file(PATH_file, parse(Int, day), time_zone, parse(Int, month) , parse(Int, year), filtered_time_info)
    #         info_all_files = append!(info_all_files, info_one_file)
    #         println(size(info_all_files))
    #     end 
    # end 
    info_matrix = hcat(info_all_files...)' # convert info_all_files to a matrix if it's a vector of rows
    println("here ",size((info_matrix)))
    # correction flux 
    final_day = info_matrix[:, 1]
    final_month = info_matrix[:, 2]
    final_year = info_matrix[:, 3]
    final_time = info_matrix[:, 4]
    final_h = info_matrix[:, 6]
    # final_stab = info_matrix[:, 17]

    wind_val = find_wind_speed(info_wind, final_time, final_day, final_month, final_year, final_h)
    corr_factor = calc_corr_factor(wind_val)
    # println(size(corr_factor))
    # [day, month, year, time_in, diff_t, 105, mean_b, std_b, mean_w, std_w, mean_var_w2, std_var_w2, mean_f, std_f, lod_mean, f_uncert_noise, stab_zl]

    info_matrix = hcat(info_matrix, corr_factor)

    output_file_name = "fluxH_unc_$(flag_stability)_$(flag_condition).txt"
    output_file = PATH_output_txt * output_file_name
    println(output_file)
    writedlm(output_file, info_matrix)
end


function main_with_unc(flag_condition, flag_stability)
    PATH_output_png = "/home/ellai/test_arm_data/flux_calc/VER6/output_png/"
    PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER6/output_txt/"

    output_file_name = "fluxH_unc_$(flag_stability)_$(flag_condition).txt"

    output_file = PATH_output_txt * output_file_name
    info = readdlm(output_file)
    println(size(info))

    f = info[:, 13]
    err_noise =  info[:, 16]
    err_sample =  info[:, 17]
    err_ensemble =  info[:, 18]
    # daay = info[:, 1]
    # tiime = info[:, 4]

    h = info[:, 6]

    # idx = findall(x -> x == 105, h)
    # println(length(idx))
    # println("h, unique ", sort(unique(h)))
    # idx = findall(x -> x >= 105, h)
    # println("frfr ", length(idx), " ", length(h)," " ,  length(f))
    
    # Create masks
    mask_105 = [(h[i]  >= 105) for i in 1:length(f)]
    mask_noise = [(abs(f[i] / err_noise[i]) >= 1) && (f[i] != 0) for i in 1:length(f)]
    mask_sample = [(abs(f[i] / err_sample[i]) >= 1) && (f[i] != 0) for i in 1:length(f)]
    mask_ensemble = [(abs(f[i] / err_ensemble[i]) >= 1) && (f[i] != 0) for i in 1:length(f)]
    
    # Combine all masks
    final_mask = mask_noise .& mask_sample .& mask_ensemble .& mask_105

    println(sum(final_mask))
    h = h[final_mask]
    # println("h, unique ", sort(unique(h)))
    idx = findall(x -> x == 105, h)
    println(length(idx))

    # daay = daay[final_mask]
    # tiime = tiime[final_mask]

    # println(unique(daay))
    # println(unique(tiime./3600))


    # Filter rows of info from column 1 to 
    filtered_info = info[final_mask, 1:end]

    # Extract only columns 17 and 18 from filtered_info
    output_data = filtered_info[:, [1:16;19; 20]]
    # println(size(output_data))

    # Write to file
    output_file_name = "fluxH_$(flag_stability)_$(flag_condition).txt"
    output_file = PATH_output_txt * output_file_name
    writedlm(output_file, output_data)
    println(output_file)
end


# flag_clouds = "noclouds" # "noclouds/someclouds"
# flag_stability = "neutral" # "unstable/neutral"
# main(flag_clouds, flag_stability, fixyear)

# strange - should be  fixed 
# height for wind 1995.0 2145.0
# height for wind 1995.0 2415.0
# height for wind 1995.0 2025.0

# fixyear = 2022
# conditions_options = ["nonclean"] 
# stability_options = ["unstable"]

conditions_options = ["nonclean", "clean"] 
stability_options = ["neutral","unstable" ,"stable"]

# conditions_options = ["nonclean"] 
# stability_options = ["neutral"]

# cloud_options = ["noclouds", "someclouds"]
# stability_options = ["unstable", "neutral"]
# fixyear = 202

# main(flag_condition, flag_stability, fixyear)


for flag_condition in conditions_options
    for flag_stability in stability_options
        main(flag_condition, flag_stability)
        main_with_unc(flag_condition, flag_stability)
        # should calculate anout of profilers after it  - unique combination. 
    end
end


# initial index for h was incorrect.  filtered data in main_with_unc. have no idea why 
# mean corr factor: 1.4045636068187144 max: 2.283234370675359 min: 1.0357634442121055
# /home/ellai/test_arm_data/flux_calc/VER6/output_txt/fluxH_unc_stable_clean.txt
# (13098, 20)
# 8829
# 1035
# /home/ellai/test_arm_data/flux_calc/VER6/output_txt/fluxH_stable_clean.txt