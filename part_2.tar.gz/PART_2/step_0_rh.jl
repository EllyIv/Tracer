using Glob  
using CSV   
using Plots
using Colors 
using NCDatasets 
using Dates  
using Statistics 
using Dierckx     
using Polynomials
using StatsBase 
using DSP 
using DelimitedFiles
using NetCDF
using Measures
using CategoricalArrays
using Distributed
using Interpolations 
using DataFrames

addprocs(64)
atexit(() -> rmprocs(workers()))


@everywhere using NCDatasets, Statistics, Interpolations, LsqFit, Dates, Polynomials
@everywhere using Glob, DelimitedFiles

@everywhere function from_datetime_to_sec(set_time, day_in, month_in, year_in, time_zone)
    time_sec = hour.(set_time) .* 3600 .+ minute.(set_time) .* 60 .+ second.(set_time) 
    
    base_datetime = DateTime(year_in, month_in, day_in)
    total_time_dt = base_datetime .+ Second.(time_sec)
    dt_local = total_time_dt .+ Hour(time_zone)

    true_year = year.(dt_local)
    true_month = month.(dt_local)
    true_day = day.(dt_local)

    true_time_sec = Dates.value.(dt_local .- DateTime.(true_year, true_month, true_day)) ./ 1000

    return true_time_sec, true_day, true_month, true_year
end

@everywhere function read_sonde_data_PROFILE(PATH_file, time_zone, init_day, init_month, init_year)
    dataset = NCDataset(PATH_file, "r")
    all_info = []

    try
        # Read and convert time
        time_in_datetime = dataset["time"][:]
        time_in_sec, day, month, year = from_datetime_to_sec(time_in_datetime, init_day, init_month, init_year, time_zone)
        # println(time_in_sec[1:10]-time_in_sec[2:11])
        # sleep(100)
        time_in_h = time_in_sec ./ 3600

        # Read and mask height
        height_m = dataset["height"][:] .* 1000  # convert km to m
        mask_height = height_m .<= 4000
        height_m = height_m[mask_height]

        # Read variables
        rh_data = dataset["rh"][mask_height, :]
        t_data = dataset["potential_temp"][mask_height, :]

        # Create unique day keys
        date_keys = [(year[t], month[t], day[t]) for t in 1:length(time_in_h)]
        unique_dates = unique(date_keys)

        # 10-minute bin width in hours
        bin_width = 10 / 60

        for d in unique_dates
            # Get indices for current day
            indices = findall(==(d), date_keys)

            t_subset = time_in_h[indices]
            rh_subset = rh_data[:, indices]
            temp_subset = t_data[:, indices]

            # Define bin edges
            min_time = bin_width * floor(Int, minimum(t_subset) / bin_width)
            max_time = bin_width * ceil(Int, maximum(t_subset) / bin_width)
            edges = collect(min_time:bin_width:max_time)

            # Assign each time point to a bin
            bin_indices = [searchsortedlast(edges, t) for t in t_subset]
            n_bins = maximum(bin_indices)

            # Initialize binned arrays
            binned_time = Float64[]
            binned_rh = Array{Float64}(undef, length(height_m), n_bins)
            binned_temp = Array{Float64}(undef, length(height_m), n_bins)

            for i in 1:n_bins
                idxs = findall(==(i), bin_indices)
                if !isempty(idxs)
                    push!(binned_time, mean(t_subset[idxs]))
                    binned_rh[:, i] = mapslices(x -> mean(skipmissing(x)), rh_subset[:, idxs]; dims=2)[:]
                    binned_temp[:, i] = mapslices(x -> mean(skipmissing(x)), temp_subset[:, idxs]; dims=2)[:]
                else
                    push!(binned_time, edges[i] + bin_width / 2)
                    binned_rh[:, i] .= NaN
                    binned_temp[:, i] .= NaN
                end
            end

            # Save results
            for h in 1:length(height_m)
                for t in 1:length(binned_time)
                    push!(
                        all_info,
                        [d[3], d[2], d[1], binned_time[t], height_m[h], binned_rh[h, t], binned_temp[h, t]]
                    )
                end
            end
        end
    finally
        close(dataset)
    end

    return all_info
end

# @everywhere  function read_sonde_data_PROFILE(PATH_file, time_zone, init_day, init_month, init_year)
#     dataset = NCDataset(PATH_file, "r")
#     # variable_names = keys(dataset)
#     # println("Variables in the dataset: ", variable_names)
#     # sleep(100)
#     all_info = []
#     try 
#         time_in_datetime = dataset["time"][:] # + num_day + time_zone * 3600 # sec, measurements each 30 min
#         time_in_sec, day, month, year =  from_datetime_to_sec(time_in_datetime, init_day, init_month, init_year, time_zone)
        
#         time_in_h = time_in_sec ./3600  # in h 
#         # mask_time =  (abs.(time_in_h .- fix_t) .< 1)
        
#         height_m = dataset["height"] * 1000 # m 
#         mask_height = height_m .<= 2500
       
#         # time_in_h = time_in_h[mask_time]
#         height_m = height_m[mask_height]
#         rh_data = dataset["rh"][mask_height,:]
#         t_data = dataset["potential_temp"][mask_height, :]
#         # day, month, year = day[mask_time], month[mask_time], year[mask_time]

#         for h in 1:length(height_m)
#             for t in 1:length(time_in_h)
#                 push!(all_info, [day[t], month[t], year[t], time_in_h[t], height_m[h], rh_data[h, t], t_data[h, t]])
#             end 
#         end 
#     finally 
#         close(dataset)
#     end
    
#     return all_info
# end



@everywhere function collect_files_from_sonde_all()
    PATH_folder_sonde = "/home/ellai/data/archive/DOE-SC0021074 (Tracer)/level 1/houinterpolatedsondeM1/"  # for rh and temperature
    PATH_output_png = "/home/ellai/test_arm_data/flux_calc/VER6/output_png/"
    PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER6/output_txt/"
    
    time_zone = -5 # houston 
    # fix_year = 2021
    info_sonde_all_days = []
    set_files = filter(x -> endswith(x, ".nc"), readdir(PATH_folder_sonde))
    for file in set_files
        println(file)
        file_parts = split(basename(file), ".")
        day = parse(Int, file_parts[3][7:8])
        month = parse(Int, file_parts[3][5:6])
        year = parse(Int, file_parts[3][1:4])
        # if year == fix_year 
        println("day ", day, " month ", month, " year ", year)   
        file_new = PATH_folder_sonde * file
        info_one_file = read_sonde_data_PROFILE(file_new, time_zone, day, month, year) # [day_int, month_int, year_int, rh_d, t_d]
        append!(info_sonde_all_days, info_one_file)
        # end
         
    end
    println(size(info_sonde_all_days))
    info_matrix = hcat(info_sonde_all_days...)' 
    # output_file_name = "sonde_rh_$(fix_year).txt"
    output_file_name = "sonde_rh.txt"
    output_file = PATH_output_txt * output_file_name
    writedlm(output_file, info_matrix)
    println(output_file)

end 

@everywhere function match_sonde_to_lidar(day_lidar, month_lidar, year_lidar, time_lidar, data_sonde, avg_rh, avg_temp, month_headers, h_vals)
    day_sonde, month_sonde, year_sonde, time_sonde_full, h_sonde, rh_sonde, temp_sonde = data_sonde[:, 1], data_sonde[:, 2], data_sonde[:, 3], data_sonde[:, 4], data_sonde[:, 5], data_sonde[:, 6], data_sonde[:, 7]
    
    unique_lidar_days = unique([(day_lidar[i], month_lidar[i], year_lidar[i]) for i in 1:length(day_lidar)])
    unique_sonde_days = unique([(day_sonde[i], month_sonde[i], year_sonde[i]) for i in 1:length(day_sonde)])
    
    day_out, month_out, year_out, time_out = [], [], [], []
    rh_all, temp_all, h_all = [], [], []

    for (d, m, y) in unique_lidar_days
        time_inds = findall((day_lidar .== d) .& (month_lidar .== m) .& (year_lidar .== y))
        times_lidar_day = time_lidar[time_inds]

        if (d, m, y) in unique_sonde_days
            mask_sonde = (day_sonde .== d) .& (month_sonde .== m) .& (year_sonde .== y)
            time_sonde = time_sonde_full[mask_sonde]
            h_s = h_sonde[mask_sonde]
            rh_s = rh_sonde[mask_sonde]
            temp_s = temp_sonde[mask_sonde]

            for i in 1:length(times_lidar_day)
                t = times_lidar_day[i]
                valid_times = unique(time_sonde[(t .- time_sonde) .<= 1 .&& (t .>= time_sonde)])
                if !isempty(valid_times)
                    matched_time = valid_times[argmin(t .- valid_times)] # pick the closest one (i.e., the largest time ≤ t)
                    time_mask = time_sonde .== matched_time
                    push!(day_out, d)
                    push!(month_out, m)
                    push!(year_out, y)
                    push!(time_out, t)
                    push!(h_all, h_s[time_mask])
                    push!(rh_all, rh_s[time_mask])
                    push!(temp_all, temp_s[time_mask])
                    # println("------")
                end
            end
        else
            key = "$(y)-" * lpad(m, 2, '0')
            month_index = findfirst(month_headers .== key)
            if isnothing(month_index)
                continue
            end
        
            idx = month_index + 1

            for t in unique(times_lidar_day)
                push!(day_out, d)
                push!(month_out, m)
                push!(year_out, y)
                push!(time_out, t)
                push!(h_all, h_vals[2:end])
                push!(rh_all, avg_rh[2:end, idx])
                # println(avg_rh[:, idx])
                # sleep(10)
                push!(temp_all, avg_temp[2:end, idx])
            end
        end
    end
    # println(day_out)
    # # println(time_out[1])
    # # println(length(h_all))
    # # println(length(rh_all))
    # # println(length(temp_all))
    # sleep(100)
    # println("result ", length(h_all)) 
    return day_out, month_out, year_out, time_out, h_all, rh_all, temp_all
end  

@everywhere function align_data_with_lidar()
    PATH_output_png = "/home/ellai/test_arm_data/flux_calc/VER6/output_png/"
    PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER6/output_txt/"
    
    # DATA from LIDAR
    # combine info for 2021 and 2022
    input_file_height = "height_lidar.txt"
    input_file_time = "time_lidar.txt"
    input_file_rh = "sonde_rh.txt"

    input_data_height = readdlm(PATH_output_txt * input_file_height)[:, 1]
    input_data_time = readdlm(PATH_output_txt * input_file_time)         # day / month / year / time (LIDAR)
    input_data_rh = readdlm(PATH_output_txt * input_file_rh)             # day / month / year / time / h_all / rh_all / temp_all

    # Extract unique days from lidar time
    time_day_keys = [(input_data_time[i,1], input_data_time[i,2], input_data_time[i,3]) for i in 1:size(input_data_time,1)]
    unique_days = unique(time_day_keys)
    # println("im here")
    interpolated_rh = []

    for day in unique_days
        day_lidar, m_lidar, y_lidar = day

        # Get all lidar times for this day
        idxs_time = findall(x -> x[1]==day_lidar && x[2]==m_lidar && x[3]==y_lidar, time_day_keys)
        lidar_times = input_data_time[idxs_time, 4] ./3600

        # Filter RH data for the same day
        mask_day = (input_data_rh[:,1] .== day_lidar) .&
                   (input_data_rh[:,2] .== m_lidar) .&
                   (input_data_rh[:,3] .== y_lidar)

        rh_times    = input_data_rh[mask_day, 4]
        rh_heights  = input_data_rh[mask_day, 5]
        rh_values   = input_data_rh[mask_day, 6]
        temp_values   = input_data_rh[mask_day, 7]

        # println("here")
        # sleep(100)
        if isempty(rh_times)
            for t_lidar in lidar_times
                for h in input_data_height
                    push!(interpolated_rh, [day_lidar, m_lidar, y_lidar, t_lidar, h, NaN])
                end
            end
            continue
        end
        # println(lidar_times)
        # println(rh_times) 
        # sleep(100)
        for t_lidar in lidar_times
            time_diffs = abs.(rh_times .- t_lidar)
            if minimum(time_diffs) <= 1  # 1*3600  , 1 h gap 
                idx_closest = argmin(time_diffs)
                t_rh = rh_times[idx_closest]

                # Extract RH profile for that closest time
                idx_match = findall(rh_times .== t_rh)
                h_set1 = rh_heights[idx_match]
                rh_set1 = rh_values[idx_match]
                temp_set1 = temp_values[idx_match]
                # println("here")
                # sleep(100)
                # Interpolate RH to lidar heights
                if length(h_set1) >= 2
                    sort_idx = sortperm(h_set1)
                    interp_func = LinearInterpolation(h_set1[sort_idx], rh_set1[sort_idx], extrapolation_bc=NaN)
                    interp_func_2 = LinearInterpolation(h_set1[sort_idx], temp_set1[sort_idx], extrapolation_bc=NaN)
                    for h in input_data_height
                        rh_val = interp_func(h)
                        temp_val = interp_func_2(h)
                        push!(interpolated_rh, [day_lidar, m_lidar, y_lidar, t_lidar, h, rh_val, temp_val])
                    end
                else
                    for h in input_data_height
                        push!(interpolated_rh, [day_lidar, m_lidar, y_lidar, t_lidar, h, NaN, NaN])
                    end
                end
            else
                for h in input_data_height
                    push!(interpolated_rh, [day_lidar, m_lidar, y_lidar, t_lidar, h, NaN, NaN])
                end
            end
        end
    end
    writedlm(PATH_output_txt * "rh_aligned_with_lidar.txt", interpolated_rh)
    println(PATH_output_txt * "rh_aligned_with_lidar.txt")
end

@everywhere  function normalize_height(fix_t, day, month, year, input_data_pbl1)
    #[pbl1[1], pbl2[1], day[1], hours, month[1], year[1]]
    # day_lidar, m_lidar, y_lidar, t_lidar, pbl_set1
    day_pbl, month_pbl, year_pbl = input_data_pbl1[:, 1], input_data_pbl1[:, 2], input_data_pbl1[:, 3]
    time_pbl, pbl_h = input_data_pbl1[:, 4], input_data_pbl1[:, 5]
    # println(maximum(time_pbl))
    fix_t = floor(Float64, fix_t)
    println(fix_t, " ", day, " ", month)
    # println(time_pbl[1:10])
    # sleep(100)
    mask = (time_pbl .== fix_t) .&(day_pbl .== day) .& (month_pbl .== month) .& (year_pbl .== year)
    # println("clouds ", cld_h[mask])

    if !isempty(pbl_h[mask])
        return pbl_h[mask][1]
    else 
        return missing
    end
end  



@everywhere function norm_profiles()
    PATH_output_png = "/home/ellai/test_arm_data/flux_calc/VER6/output_png/"
    PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER6/output_txt/"

    input_file_rh = "rh_aligned_with_lidar.txt"
    info_rh = readdlm(PATH_output_txt * input_file_rh)    
    day_rh, month_rh, year_rh  =  info_rh[:, 1], info_rh[:, 2], info_rh[:, 3]
    time_rh = info_rh[:, 4] # h
    height_rh = info_rh[:, 5]
    rh_val = info_rh[:, 6]
    temp_val = info_rh[:, 7]
    # println(maximum(time_rh))

    println("0")
    info_pbl_height = [] 
    input_file_pbl = PATH_output_txt * "pbl_aligned_with_lidar.txt"
    pbl_info = readdlm(input_file_pbl)
    println("1")

    # for t_ind in 1:length(time_rh)
    #     t = time_rh[t_ind]
    #     norm_height = normalize_height(t.*3600, day_rh[t_ind], month_rh[t_ind], year_rh[t_ind], pbl_info) #true , false 
    #     push!(info_pbl_height, norm_height)
    # end 
    # height_rh = height_rh ./ info_pbl_height
    info_pbl_height = pmap(eachindex(time_rh)) do i
        normalize_height(time_rh[i]*3600, day_rh[i], month_rh[i], year_rh[i], pbl_info)
    end
    
    height_rh = height_rh ./ info_pbl_height


    output_file_raw = PATH_output_txt * "rh_norm_aligned_with_lidar.txt"
    writedlm(output_file_raw, hcat(day_lidar, m_lidar, y_lidar, t_lidar, height_rh, rh_val, temp_val))
end 

function check_interpolation(fixed_day, fixed_month, fixed_year, flag_stability, flag_clouds)
    PATH_output_png = "/home/ellai/test_arm_data/flux_calc/VER6/output_png/"
    PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER6/output_txt/"
    
    input_file_rh_modified = "sonde_interpolated_rh_$(flag_stability)_$(flag_clouds).txt"
    input_file_rh_initial = "sonde_rh.txt"

    input_data_modified = readdlm(PATH_output_txt * input_file_rh_modified)
    input_data_initial = readdlm(PATH_output_txt * input_file_rh_initial)  

    mask_mod = (input_data_modified[:,1] .== fixed_day) .&
               (input_data_modified[:,2] .== fixed_month) .&
               (input_data_modified[:,3] .== fixed_year) .&
               (abs.(input_data_modified[:,4] .- 12) .< 1.0)
    
    mod_data = input_data_modified[mask_mod, :]
    mod_heights = mod_data[:, 5]
    mod_rh = mod_data[:, 6]

    mask_ini = (input_data_initial[:,1] .== fixed_day) .&
               (input_data_initial[:,2] .== fixed_month) .&
               (input_data_initial[:,3] .== fixed_year) .&
               (abs.(input_data_initial[:,4] .- 12) .< 1.0)

    ini_data = input_data_initial[mask_ini, :]
    ini_heights = ini_data[:, 5]
    ini_rh = ini_data[:, 6]

    # println(mod_rh, mod_heights)
    plot(mod_rh, mod_heights, label="Interpolated RH", xlabel="RH (%)", ylabel="Height (m)", legend=:bottomright)
    plot!(ini_rh, ini_heights, label="Original RH", linestyle=:dash)
    savefig(PATH_output_png * "rh_profile_$(fixed_year)_$(fixed_month)_$(fixed_day).png")
end  



@everywhere function average_profiles_for_month(fix_t)
    PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER2/output_txt/"

    input_file = PATH_output_txt * "sonde_$(fix_t).txt"
    data = readdlm(input_file)

    # between 11 and 13 h
    mask_time = (data[:, 4] .>= fix_t-1) .& (data[:, 4] .<= fix_t+1)
    data = data[mask_time, :]

    months_all = unique([(data[i,3], data[i,2]) for i in 1:size(data,1)])
    sort!(months_all)

    h_set = sort(unique(data[:, 5]))

    rh_matrix = []
    t_matrix = []

    for (y, m) in months_all
        mask_month = (data[:,2] .== m) .& (data[:,3] .== y)
        sub = data[mask_month, :]  # rows for this month

        rh_avg = []
        t_avg = []

        for h in h_set
            mask_h = (sub[:,5] .== h)
            rh_vals = sub[mask_h, 6]
            t_vals = sub[mask_h, 7]

            push!(rh_avg, mean(skipmissing(rh_vals)))
            push!(t_avg, mean(skipmissing(t_vals)))
        end

        push!(rh_matrix, rh_avg)
        push!(t_matrix, t_avg)
    end

    rh_out = hcat(h_set, [rh_matrix[i] for i in 1:length(rh_matrix)]...)
    t_out = hcat(h_set, [t_matrix[i] for i in 1:length(t_matrix)]...)

    headers = ["height"; ["$(y)-$(lpad(m, 2, '0'))" for (y, m) in months_all]]

    rh_file = PATH_output_txt * "monthly_rh_profile_$(fix_t)h.txt"
    temp_file = PATH_output_txt * "monthly_temp_profile_$(fix_t)h.txt"

    open(rh_file, "w") do io
        println(io, join(headers, '\t'))
        for row in eachrow(rh_out)
            println(io, join(row, '\t'))
        end
    end

    open(temp_file, "w") do io
        println(io, join(headers, '\t'))
        for row in eachrow(t_out)
            println(io, join(row, '\t'))
        end
    end
end

# function rh_maximum(flag_stability, flag_clouds)
#     PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER4/output_txt/"
#     file_rh = PATH_output_txt * "sonde_interpolated_rh_$(flag_stability)_$(flag_clouds).txt"
#     info_rh = readdlm(file_rh)

#     day_rh = info_rh[:, 1]
#     month_rh = info_rh[:, 2]
#     year_rh = info_rh[:, 3]
#     time_rh = info_rh[:, 4]
#     h_rh = info_rh[:, 5]
#     rh_rh = info_rh[:, 6]
#     # day_lidar, m_lidar, y_lidar, t_lidar, h, rh_val, temp_val
#     df = DataFrame(time_rh = time_rh, day_rh = day_rh, month_rh = month_rh, year_rh = year_rh)
#     df_unique = unique(df)
#     # println(size(df_unique)[1])
#     # sleep(30)
#     new_info = []
#     for i in  1:size(df_unique, 1)
#         unique_time = df_unique[i, 1]
#         unique_day = df_unique[i, 2]
#         unique_month = df_unique[i, 3]
#         unique_year = df_unique[i, 4]
        
#         # println(unique_day, " ", unique_month," ",  unique_year)
#         # println(day_rh)

#         mask_time = findall((unique_day .== day_rh) .& (unique_month .== month_rh) .& (unique_year .== year_rh) .& (unique_time .== time_rh))
#         # println(sum(mask_time))
#         # sleep(20)
#         one_profile_h = h_rh[mask_time]
#         one_profile_rh = rh_rh[mask_time]
        
#         inds = findall(x -> x > 90, one_profile_rh)
#         if isempty(inds)
#             min_val_h = [missing]
#         else
#             min_val_h = one_profile_h[inds]
#             # println(one_profile_h[inds])
#             # vals = filter(x -> x > 100, one_profile_h[inds])
#             # min_val_h = isempty(vals) ? missing : minimum(vals)
#         end
#         for k in 1:length(min_val_h)
#         # sleep(90)
#             push!(new_info, [unique_day, unique_month, unique_year, unique_time, min_val_h[k]])
#         end 
#     end
#     writedlm(PATH_output_txt * "rh90_filter_$(flag_stability)_$(flag_clouds).txt", new_info)
#     println(PATH_output_txt * "rh90_filter_$(flag_stability)_$(flag_clouds).txt")
# end 

function filtered_rh()
    PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER6/output_txt/"
    file_rh = PATH_output_txt * "rh_aligned_with_lidar.txt"
    info_rh = readdlm(file_rh)

    file_pbl = PATH_output_txt * "pbl_aligned_with_lidar.txt"
    info_pbl = readdlm(file_pbl)


    day_rh = info_rh[:, 1]
    month_rh = info_rh[:, 2]
    year_rh = info_rh[:, 3]
    time_rh = info_rh[:, 4]
    h_rh = info_rh[:, 5]
    rh_rh = info_rh[:, 6]

    day_pbl = info_pbl[:, 1]
    month_pbl = info_pbl[:, 2]
    year_pbl = info_pbl[:, 3]
    time_pbl = info_pbl[:, 4]
    h_pbl = info_pbl[:, 5]

    # day_lidar, m_lidar, y_lidar, t_lidar, h, rh_val, temp_val
    df = DataFrame(time_rh = time_rh, day_rh = day_rh, month_rh = month_rh, year_rh = year_rh)
    df_unique = unique(df)

    new_info = []
    for i in  1:size(df_unique, 1)
        unique_time = df_unique[i, 1]
        unique_day = df_unique[i, 2]
        unique_month = df_unique[i, 3]
        unique_year = df_unique[i, 4]
        
        # println(unique_day, " ", unique_month," ",  unique_year)
        # println(day_rh)
        # 24.0	7.0	2022.0
        # println(unique_day, " ", )
        if (unique_day == 24) && (unique_month == 7) && (unique_year == 2022)
            mask_time_pbl = findall((unique_day .== day_pbl) .& (unique_month .== month_pbl) .& (unique_year .== year_pbl) .& (unique_time .== time_pbl))
            one_pblh = h_pbl[mask_time_pbl]
            if !ismissing(one_pblh) && length(one_pblh) != 0 
                one_pblh = one_pblh
            else
                one_pblh = NaN
            end        

            println(one_pblh, " ", length(one_pblh))
            # println(unique(rh_rh))
            mask_time_rh = findall((one_pblh .> h_rh) .& (unique_day .== day_rh) .& (unique_month .== month_rh) .& (unique_year .== year_rh) .& (unique_time .== time_rh))
            println("mask" , " ", sum(mask_time_rh))
            one_profile_h = h_rh[mask_time_rh]
            one_profile_rh = rh_rh[mask_time_rh]
            println(length(one_profile_rh))
            
            # println(unique(one_profile_rh))
            if length(unique(one_profile_rh)) >1
                inds = findall(x -> x > 90, one_profile_rh)
                L = length(one_profile_h)
                println(i, " ", L," ", length(inds), " ", (L-length(inds))/L*100)
            end 
            println()
        end 
        # if isempty(inds)
        #     min_val_h = [missing]
        # else
        #     min_val_h = one_profile_h[inds]
        #     # println(one_profile_h[inds])
        #     # vals = filter(x -> x > 100, one_profile_h[inds])
        #     # min_val_h = isempty(vals) ? missing : minimum(vals)
        # end
        # for k in 1:length(min_val_h)
        # # sleep(90)
        #     push!(new_info, [unique_day, unique_month, unique_year, unique_time, min_val_h[k]])
        # end 
    end
    # writedlm(PATH_output_txt * "rh90_filter_$(flag_stability)_$(flag_clouds).txt", new_info)
    # println(PATH_output_txt * "rh90_filter_$(flag_stability)_$(flag_clouds).txt")
end 

function check_rh(fixed_month, fixed_year)
    PATH_output_png = "/home/ellai/test_arm_data/flux_calc/VER6/output_png/"
    PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER6/output_txt/"
    
    file_pbl = PATH_output_txt * "pbl_aligned_with_lidar.txt"
    info_pbl = readdlm(file_pbl)
    pbl_day = info_pbl[:, 1]
    pbl_month = info_pbl[:, 2]
    pbl_year = info_pbl[:, 3]
    pbl_time = info_pbl[:, 4] # sec
    pbl_val = info_pbl[:, 5]
    pbl_val = replace(pbl_val, "missing" => missing)
     

    file_rh = PATH_output_txt * "rh_aligned_with_lidar.txt"
    info_rh = readdlm(file_rh)

    rh_day = info_rh[:, 1]
    rh_month = info_rh[:, 2]
    rh_year = info_rh[:, 3]
    rh_time = info_rh[:, 4] .* 3600 # sec
    rh_height = info_rh[:, 5]
    rh_val = info_rh[:, 6]
    rh_val = replace(rh_val, "missing" => missing)
    
    time_in = 11.0 * 3600 
    time_out = 12.0 * 3600 
    
    # println(rh_time[1:5]/3600)
    mask_time  = (rh_time .>= time_in) .& (rh_time .<= time_out) .& (rh_month .== fixed_month) .& (rh_year .== fixed_year)
    

    rh_day = rh_day[mask_time]
    rh_month = rh_month[mask_time]
    rh_year = rh_year[mask_time]
    rh_time = rh_time[mask_time]  
    rh_height = rh_height[mask_time]
    rh_val = rh_val[mask_time]
    # println(" first ", length(rh_day)) 

    # PBL H 
    pbl_for_rh = []
    for t in 1:length(rh_time)
        mask = (rh_day[t] .== pbl_day) .& (rh_month[t] .== pbl_month) .& (rh_year[t] .== pbl_year) .& (rh_time[t] .== pbl_time)
        pbl_time_new = pbl_time[mask]
        pbl_val_new = pbl_val[mask]

        if length(pbl_time_new) != 0  && !ismissing(pbl_val_new[1])
            push!(pbl_for_rh, pbl_val_new[1])         
        else
            push!(pbl_for_rh, missing)             
        end
    end
    # rh_height_norm = rh_height ./ pbl_for_rh 


    # println("1", rh_val)
    # ind_l_time_after_rh = []
    # set_rh_h = []
    # for t in 1:length(rh_time)
    #     mask = (rh_day[t] .== cld_day) .& (l_month[t] .== cld_month) .& (l_year[t] .== cld_year).& (l_time[t] .== cld_time)
    #     inds = findall(x -> x >= 90, rh_val_new)
    #     if length(inds) != 0
    #         min_h = minimum(rh_height_new[inds])
    #     else
    #         min_h = pbl_t
    #     end 

    #     mask_rh = (90 .>= rh_val_new)
    #     rh_height_new = rh_height_new[mask_rh]
    #     rh_val_new = rh_val_new[mask_rh]
    #     rh_time_new = rh_time_new[mask_rh]
    #     amount_of_data_2 = length(rh_height_new)

    #     percent_of_clean_data = amount_of_data_2/amount_of_data_1*100
        
    #     if  percent_of_clean_data > 50 && min_h >= pbl_t/2  # cutting all bad profiles 
    #         min_h_2 = minimum(rh_height_new) 
    #         # if condition_flag == "clean"
    #         #     if min_h >= pbl_t
    #         #         push!(ind_l_time_after_rh, t)
    #         #         push!(set_rh_h, pbl_t)
    #         #     end
    #         # elseif condition_flag == "nonclean"
    #         push!(ind_l_time_after_rh, t)
    #         push!(set_rh_h, min_h_2)
    #         # end 
    #     end         
    # end

    # rh_day = rh_day[ind_l_time_after_rh]
    # rh_month = rh_month[ind_l_time_after_rh]
    # rh_year = rh_year[ind_l_time_after_rh]
    # rh_time = rh_time[ind_l_time_after_rh]
    # rh_height = rh_height[ind_l_time_after_rh]
    # # rh_val = rh_val[ind_l_time_after_rh]
    # pbl_for_rh = pbl_for_rh[ind_l_time_after_rh]

    rh_val_new = rh_val
    # with pbl
    ave_rh_data, ave_h_data  = [], []
    h_data = rh_height ./ pbl_for_rh
    # println(rh_val_new)
    nbins = 75
    h_edges = range(0, 2; length=nbins+1)
    h_centers = (h_edges[1:end-1] .+ h_edges[2:end]) ./ 2
    for i in 1:nbins
        inds = findall(h -> h_edges[i] ≤ h < h_edges[i+1], h_data)
        if !isempty(inds)
            # push!(ave_rh_data, mean(skipmissing(rh_val_new[inds])))
            push!(ave_rh_data, mean(filter(!isnan, rh_val_new[inds])))
            push!(ave_h_data, h_centers[i])
        end
    end

    println(ave_rh_data)
    p1 = plot(rh_val_new, h_data, marker=:circle, label=false, xlabel="Flux", ylabel="Height (h)", ylim=(0, 2), alpha = 0.1, color=:red)
    plot!(p1, ave_rh_data, ave_h_data, marker=:circle, label=false, xlabel="Flux", ylabel="Height (h)", ylim=(0, 2),color=:blue)

    p =  plot(p1, layout=(1, 2), size = (1200, 500),  bottom_margin=10mm, left_margin=10mm)
    png(p, PATH_output_png * "rh_height_filter.png")
    println(PATH_output_png * "rh_height_filter.png")
    
end

function rh_norm()
    PATH_output_png = "/home/ellai/test_arm_data/flux_calc/VER6/output_png/"
    PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER6/output_txt/"
    
    file_pbl = PATH_output_txt * "pbl_aligned_with_lidar.txt"
    info_pbl = readdlm(file_pbl)
    pbl_day = info_pbl[:, 1]
    pbl_month = info_pbl[:, 2]
    pbl_year = info_pbl[:, 3]
    pbl_time = info_pbl[:, 4] # sec
    pbl_val = info_pbl[:, 5]
    pbl_val = replace(pbl_val, "missing" => missing)
     

    file_rh = PATH_output_txt * "rh_aligned_with_lidar.txt"
    info_rh = readdlm(file_rh)

    rh_day = info_rh[:, 1]
    rh_month = info_rh[:, 2]
    rh_year = info_rh[:, 3]
    rh_time = info_rh[:, 4] .* 3600 # sec
    rh_height = info_rh[:, 5]
    rh_val = info_rh[:, 6]
    rh_val = replace(rh_val, "missing" => missing)
    
    # time_in = 11.0 * 3600 
    # time_out = 12.0 * 3600 
    
    # println(rh_time[1:5]/3600)
    # mask_time  = (rh_time .>= time_in) .& (rh_time .<= time_out) .& (rh_month .== fixed_month) .& (rh_year .== fixed_year)
    

    # rh_day = rh_day[mask_time]
    # rh_month = rh_month[mask_time]
    # rh_year = rh_year[mask_time]
    # rh_time = rh_time[mask_time]  
    # rh_height = rh_height[mask_time]
    # rh_val = rh_val[mask_time]
    # println(" first ", length(rh_day)) 

    # PBL H 
    pbl_for_rh = []
    for t in 1:length(rh_time)
        mask = (rh_day[t] .== pbl_day) .& (rh_month[t] .== pbl_month) .& (rh_year[t] .== pbl_year) .& (rh_time[t] .== pbl_time)
        pbl_time_new = pbl_time[mask]
        pbl_val_new = pbl_val[mask]

        if length(pbl_time_new) != 0  && !ismissing(pbl_val_new[1])
            push!(pbl_for_rh, pbl_val_new[1])         
        else
            push!(pbl_for_rh, missing)             
        end
    end
    # rh_height_norm = rh_height ./ pbl_for_rh 


    # println("1", rh_val)
    # ind_l_time_after_rh = []
    # set_rh_h = []
    # for t in 1:length(rh_time)
    #     mask = (rh_day[t] .== cld_day) .& (l_month[t] .== cld_month) .& (l_year[t] .== cld_year).& (l_time[t] .== cld_time)
    #     inds = findall(x -> x >= 90, rh_val_new)
    #     if length(inds) != 0
    #         min_h = minimum(rh_height_new[inds])
    #     else
    #         min_h = pbl_t
    #     end 

    #     mask_rh = (90 .>= rh_val_new)
    #     rh_height_new = rh_height_new[mask_rh]
    #     rh_val_new = rh_val_new[mask_rh]
    #     rh_time_new = rh_time_new[mask_rh]
    #     amount_of_data_2 = length(rh_height_new)

    #     percent_of_clean_data = amount_of_data_2/amount_of_data_1*100
        
    #     if  percent_of_clean_data > 50 && min_h >= pbl_t/2  # cutting all bad profiles 
    #         min_h_2 = minimum(rh_height_new) 
    #         # if condition_flag == "clean"
    #         #     if min_h >= pbl_t
    #         #         push!(ind_l_time_after_rh, t)
    #         #         push!(set_rh_h, pbl_t)
    #         #     end
    #         # elseif condition_flag == "nonclean"
    #         push!(ind_l_time_after_rh, t)
    #         push!(set_rh_h, min_h_2)
    #         # end 
    #     end         
    # end

    # rh_day = rh_day[ind_l_time_after_rh]
    # rh_month = rh_month[ind_l_time_after_rh]
    # rh_year = rh_year[ind_l_time_after_rh]
    # rh_time = rh_time[ind_l_time_after_rh]
    # rh_height = rh_height[ind_l_time_after_rh]
    # # rh_val = rh_val[ind_l_time_after_rh]
    # pbl_for_rh = pbl_for_rh[ind_l_time_after_rh]

    rh_val_new = rh_val
    # with pbl
    ave_rh_data, ave_h_data  = [], []
    h_data = rh_height ./ pbl_for_rh
    # println(rh_val_new)
    nbins = 50
    h_edges = range(0, 2; length=nbins+1)
    h_centers = (h_edges[1:end-1] .+ h_edges[2:end]) ./ 2
    for i in 1:nbins
        inds = findall(h -> h_edges[i] ≤ h < h_edges[i+1], h_data)
        if !isempty(inds)
            push!(ave_rh_data, mean(filter(!isnan, rh_val_new[inds])))
            push!(ave_h_data, h_centers[i])
        end
    end

    println(ave_rh_data)
    p1 = plot(rh_val_new, h_data, marker=:circle, label=false, xlabel="Flux", ylabel="Height (h)", ylim=(0, 2), alpha = 0.1, color=:red)
    plot!(p1, ave_rh_data, ave_h_data, marker=:circle, label=false, xlabel="Flux", ylabel="Height (h)", ylim=(0, 2),color=:blue)

    p =  plot(p1, layout=(1, 2), size = (1200, 500),  bottom_margin=10mm, left_margin=10mm)
    png(p, PATH_output_png * "rh_norm_height.png")
    println(PATH_output_png * "rh_norm_height.png")
    
end



collect_files_from_sonde_all() # average for each 10 min  "sonde_rh.txt"
align_data_with_lidar() # "rh_aligned_with_lidar.txt"
# norm_profiles()


# check_rh(1, 2022)
# check_rh_year()
# filtered_rh()
# flag_stability = "unstable"
# flag_clouds = "noclouds"
# # align_data_with_lidar(flag_stability, flag_clouds)

# fixed_day = 2 
# fixed_month = 10 
# fixed_year = 2021
# check_interpolation(fixed_day, fixed_month, fixed_year, flag_stability, flag_clouds)


# cloud_options = ["noclouds", "someclouds"]
# stability_options = ["unstable", "neutral", "stable"]

# for flag_clouds in cloud_options
#     for flag_stability in stability_options
#         # align_data_with_lidar(flag_stability, flag_clouds)
#         rh_maximum(flag_stability, flag_clouds)
#     end
# end


# function check_inversion()
#     PATH_output_png = "/home/ellai/test_arm_data/flux_calc/VER6/output_png/"
#     PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER6/output_txt/"

#     file_rh = PATH_output_txt * "rh_aligned_with_lidar.txt"
#     info_rh = readdlm(file_rh)

#     rh_day = info_rh[:, 1]
#     rh_month = info_rh[:, 2]
#     rh_year = info_rh[:, 3]
#     rh_time = info_rh[:, 4] # sec
#     rh_height = info_rh[:, 5]
#     rh_val = info_rh[:, 7]
#     rh_val = replace(rh_val, "missing" => missing)
    

    
#     fixed_month = 3 
#     fixed_year = 2022
#     fixed_day = 24
#     # println(rh_time[1:5]/3600)
#     mask_time  =  (rh_month .== fixed_month) .& (rh_year .== fixed_year).& (rh_day .== fixed_day) .& (abs.(rh_time .- 15 ).<= 2)
    

#     rh_day = rh_day[mask_time]
#     rh_month = rh_month[mask_time]
#     rh_year = rh_year[mask_time]
#     rh_time = rh_time[mask_time]  
#     rh_height = rh_height[mask_time]./3600
#     rh_val = rh_val[mask_time]


#     p1 = scatter(rh_val, rh_height, marker=:circle, label=false, xlabel="Flux", ylabel="Height (h)", color=:red)
#     # plot!(p1, ave_rh_data, ave_h_data, marker=:circle, label=false, xlabel="Flux", ylabel="Height (h)", ylim=(0, 2),color=:blue)

#     p =  plot(p1, layout=(1, 1), size = (1000, 1000),  bottom_margin=10mm, left_margin=10mm)
#     png(p, PATH_output_png * "rh_test.png")


# end 



# check_inversion()



