using Glob  # for globbing the file patterns
using CSV   # for reading CSV files
using Plots # for plotting
using Colors # for color normalization
using NCDatasets # for NetCDF
using Dates  # to convert dates in sec
using Statistics # for mean
using Dierckx     # For detrend (spline interpolation)
using Polynomials
using StatsBase 
using DSP  # Import DSP package
using DelimitedFiles
using NetCDF
using Measures
using Interpolations
using LaTeXStrings

function quick_check()
    PATH_output_png = "/home/ellai/test_arm_data/flux_calc/VER6/output_png/"
    # PATH_output = "/home/ellai/test_arm_data/flux_calc/VER2/"

    data = readdlm(PATH_output * "calibration.txt", skipstart=1)  
    
    RH = data[:, 1]
    m1 = data[:, 2]
    m2 = data[:, 4]
    m3 = data[:, 6]

    p = plot(layout = (1,1), size = (800, 600), left_margin = 15mm, bottom_margin = 12mm, top_margin = 10mm,
             xguidefont = 20, yguidefont = 20, xtickfont = font(18), ytickfont = font(18), legendfont = font(18),
             yscale = :log10, xlims = (10, 95))

    plot!(p, RH, m1 .* 10^6, label = L"D \geq 0.53\ \mu m", marker = :circle, lw = 2, color = :blue)
    plot!(p, RH, m2 .* 10^6,  label = L"D \geq 1.03\ \mu m", marker = :square, lw = 2, color = :red)
    plot!(p, RH, m3 .* 10^6, label = L"D \geq 3.25\ \mu m", marker = :diamond, lw = 2, color = :black)

    xlabel!(p, L"RH\ (\%)")
    ylabel!(p, L"\frac{d\beta}{dN}\ (Mm^{-1}\ sr^{-1}\ cm^{3})")

    mkpath(PATH_output_png)
    savefig(p, PATH_output_png * "slopes_vs_rh.png")
end

function interpolate_by_two_nearest(x, x_vals, y_vals)
    diffs = abs.(x_vals .- x)
    i1 = argmin(diffs)
    diffs[i1] = Inf  # remove first minimum
    i2 = argmin(diffs)
    
    x1, x2 = x_vals[i1], x_vals[i2]
    y1, y2 = y_vals[i1], y_vals[i2]

    if x1 == x2
        return y1
    else
        return y1 + (y2 - y1) * (x - x1) / (x2 - x1)
    end
end

function main(flag_stability, flag_clouds)
    PATH_output_png = "/home/ellai/test_arm_data/flux_calc/VER6/output_png/"
    PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER6/output_txt/"

    info_calib = readdlm("/home/ellai/test_arm_data/flux_calc/VER6/output_txt/calibration.txt")
    info_calib = info_calib[2:end, :]
    info_calib_rh = info_calib[:, 1]
    info_calib_slp = info_calib[:, 2] * 10^6
    info_calib_int = info_calib[:, 3] * 10^6


    input_file = PATH_output_txt * "rh_aligned_with_lidar.txt" #day_out, month_out, year_out, time_out, h_all, rh_all, temp_all)
    data = readdlm(input_file)
    
    day, month , year = data[:, 1], data[:, 2], data[:,3]
    time, h = data[:, 4], data[:, 5]
    rh = data[:, 6]

    slp_vals = []
    int_vals = []
    
    for r in rh
        push!(slp_vals, interpolate_by_two_nearest(r, info_calib_rh, info_calib_slp))
        push!(int_vals, interpolate_by_two_nearest(r, info_calib_rh, info_calib_int))
    end

    
    p1 = scatter(rh, slp_vals, label="Matched Slope", marker=:diamond, color=:blue)
    plot!(p1, info_calib_rh, info_calib_slp, label="Original Slope", lw=2, marker=:circle, color=:red,
    xlabel="RH", ylabel="Slope (×10⁶)")

    p2 = scatter(rh, int_vals, label="Matched Intercept", marker=:diamond, color=:blue)
    plot!(p2, info_calib_rh, info_calib_int, label="Original Intercept", lw=2, marker=:circle, color=:red,
    xlabel="RH", ylabel="Intercept (×10⁶)")

    final_plot = plot(p1, p2, layout=(1,2), size=(1000,400), top_margin = 10mm , left_margin = 10mm, bottom_margin = 10mm)
    png(final_plot, PATH_output_png * "calibration_slope_intercept_plot_$(flag_stability)_$(flag_clouds).png")

    output_calib_file = PATH_output_txt * "calibration_slope_intercept_$(flag_stability)_$(flag_clouds).txt"
    calib_data = hcat(day, month, year, time, h, rh, int_vals, slp_vals)
    writedlm(output_calib_file, calib_data)
    println(output_calib_file)
end

# quick_check()


cloud_options = ["nonclean", "clean"]
stability_options = ["stable", "unstable","neutral"]

for flag_clouds in cloud_options
    for flag_stability in stability_options
        main(flag_stability, flag_clouds)
    end
end
