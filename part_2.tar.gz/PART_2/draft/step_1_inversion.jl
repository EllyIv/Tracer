using Glob  # for globbing the file patterns
using CSV   # for reading CSV files
using Plots # for plotting
using Colors # for color normalization
using NCDatasets # for NetCDF
using Dates  # to convert dates in sec
using Statistics # for mean
using Dierckx     # For detrend (spline interpolation)
using Polynomials
using StatsBase 
using DSP  # Import DSP package
using DelimitedFiles
using NetCDF
using Measures
using CategoricalArrays
using Distributed
using Interpolations 
using DataFrames

function check_inversion(fixed_month, fixed_year, fixed_day, fixed_time, info_rh)
    rh_day    = info_rh[:, 1]
    rh_month  = info_rh[:, 2]
    rh_year   = info_rh[:, 3]
    rh_time   = info_rh[:, 4] #./ 3600  # convert sec → hr
    rh_height = info_rh[:, 5]
    rh_val    = info_rh[:, 7]          # temperature
    
    rh_val    = replace(rh_val, "" => missing)
    rh_val    = replace(rh_val, "missing" => missing)
    # --- Filter by time window (±0.5 hr) ---
    mask_time = (rh_month .== fixed_month) .&
                (rh_year .== fixed_year) .&
                (rh_day .== fixed_day) .&
                (abs.(rh_time .- fixed_time) .<= 0.5)

    rh_height = rh_height[mask_time]
    rh_val    = rh_val[mask_time]
    println("2 ", unique(rh_val) )

    # Remove missing 
    mask_valid = .!ismissing.(rh_val)
    rh_height  = rh_height[mask_valid]
    rh_val     = rh_val[mask_valid]
    println("1 ", unique(rh_val) )
    # Handle empty dataset early 
    if isempty(rh_height)
        println("⚠️ No valid data found for this time window.")
        return missing, missing, missing, missing
    end

    # Sort by height
    idx = sortperm(rh_height)
    rh_height = rh_height[idx]
    rh_val    = rh_val[idx]
    println(unique(rh_val)) 

    # Average by unique height
    unique_h = sort(unique(rh_height))

    ave_h = Float64[]
    ave_t = Float64[]
    for h in unique_h
        vals = rh_val[rh_height .== h]
        push!(ave_h, h)
        println(vals)
        push!(ave_t, mean(vals))
    end

    # --- Handle case with only one level ---
    if length(ave_h) < 2
        println("⚠️ Not enough height levels to compute gradient.")
        return ave_t, ave_h, missing, missing
    end

    # --- Compute gradient ∂T/∂z ---
    grad_T = diff(ave_t) ./ diff(ave_h)

    # --- Detect inversion (∂T/∂z > 0.02 K/m) ---
    threshold = 0.015
    inv_idx = findfirst(grad_T .> threshold)
    inversion_height = isnothing(inv_idx) ? missing : ave_h[inv_idx]
    println("Inversion base height ≈ ", inversion_height, " m")


    # # --- Plot ---
    # p1 = plot(ave_t, ave_h, color=:blue, lw=2, xlabel="Temperature (K)",
    #           ylabel="Height (m)", label="Mean profile")
    # plot!(p1, ave_set_a, ave_set_b, color=:red, lw=2, xlabel="Temperature (K)",
    #           ylabel="Height (m)", label="Mean profile")
    # if !ismissing(inversion_height)
    #     hline!(p1, [inversion_height], color=:black, linestyle=:dash, label="Inversion base")
    # end
    # ylims!(p1, 0, maximum(ave_h))

    # p2 = plot(grad_T, ave_h[2:end], color=:blue, lw=2,
    #           xlabel="∂T/∂z (K/m)", ylabel="Height (m)", label="Gradient")
    # plot!(p2, grad_T2, ave_set_b[2:end], color=:red, lw=2,
    #           xlabel="∂T/∂z (K/m)", ylabel="Height (m)", label="Gradient")          
    # ylims!(p2, 0, maximum(ave_h))

    # plt = plot(p1, p2, layout=(1,2), size=(1000, 500), left_margin = 10mm , bottom_margin = 10mm )
    # png(plt, PATH_output_png * "temp_test.png")
    # println( PATH_output_png * "temp_test.png")
    return inversion_height
end


function main()
    PATH_output_png = "/home/ellai/test_arm_data/flux_calc/VER6/output_png/"
    PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER5/output_txt/"

    file_rh = PATH_output_txt * "rh_aligned_with_lidar.txt"
    info_rh = readdlm(file_rh)


    rh_day = info_rh[:, 1]
    rh_month = info_rh[:, 2]
    rh_year = info_rh[:, 3]
    rh_time = info_rh[:, 4] # h
    rh_height = info_rh[:, 5]
    rh_val = info_rh[:, 6]
    temp_val = info_rh[:, 7]

    rh_val = replace(rh_val, "missing" => missing)
    temp_val = replace(temp_val, "missing" => missing)


    # --- Create unique combinations (day, month, year, time) ---
    combos = unique([(rh_day[i], rh_month[i], rh_year[i], rh_time[i]) for i in eachindex(rh_day)])

    println("Total unique time combinations: ", length(combos))

    all_info =[]
    println("size ", size(combos))
    combos = combos[876:877]
    count = 1 
    # --- Loop through each combination ---
    for (day, month, year, time) in combos
        pbl = check_inversion(month, year, day, time, info_rh)
        push!(all_info, [day, month, year, time, pbl])
        count +=1 
        println(count)
    end

    output_file = "/home/ellai/test_arm_data/flux_calc/VER6/output_txt/" * "pbl__temp_inversion_p1.txt"
    writedlm(output_file, all_info)

    println("✅ Saved results to: ", output_file)

end 

# check_inversion(03, 2022, 24, 15)
main()