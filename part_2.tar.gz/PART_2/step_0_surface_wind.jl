using Glob  # for globbing the file patterns
using CSV   # for reading CSV files
using Plots # for plotting
using Colors # for color normalization
using NCDatasets # for NetCDF
using Dates  # to convert dates in sec
using Statistics # for mean
using Dierckx     # For detrend (spline interpolation)
using Polynomials
using StatsBase 
using DSP  # Import DSP package
using DelimitedFiles
using NetCDF
using DataFrames
using Measures
using LaTeXStrings


function from_datetime_to_sec(set_time, day_in, month_in, year_in, time_zone)
    time_sec = hour.(set_time) .* 3600 .+ minute.(set_time) .* 60 .+ second.(set_time) 
    
    base_datetime = DateTime(year_in, month_in, day_in)
    total_time_dt = base_datetime .+ Second.(time_sec)
    dt_local = total_time_dt .+ Hour(time_zone)

    true_year = year.(dt_local)
    true_month = month.(dt_local)
    true_day = day.(dt_local)

    true_time_sec = Dates.value.(dt_local .- DateTime.(true_year, true_month, true_day)) ./ 1000

    return true_time_sec, true_day, true_month, true_year
end


# # from dataset format to seconds
# function from_datetime_to_sec(set_time)
#     # println("herer ", set_time[1])
#     return hour.(set_time) .* 3600 .+ minute.(set_time) .* 60 .+ second.(set_time) .+ millisecond.(set_time) ./ 1000
# end

function block_division(set_time)
    pause_ind = vcat(findall(diff(set_time) .> 2), length(set_time))  # find indices where step > 2 and add last index

    index_in = [1; pause_ind[1:end-1] .+ 1]
    index_out = pause_ind

    valid_blocks = filter(i -> (index_out[i] - index_in[i]) > 600, eachindex(index_in))  # filter blocks where size > 600

    return [(index_in[i], index_out[i]) for i in valid_blocks]
end

function find_ind_for_time_gap(time)
    amount_of_full_days = floor.(Int, time/ 86400) # Number of days, 0 day does not exist
    time .= time .- amount_of_full_days * 86400  # Normalize time within the day
    time = convert(Vector{Union{Missing, Float64}}, time)
    # println("oops")
    time[amount_of_full_days .== -1] .= missing # set time to missing where amount_of_full_days == -1
    # println("hey")
    ind_in, ind_out = 1, length(time)  # Default indices
    
    ind_in = searchsortedlast(time, time_in)  # Find last index ≤ time_in
    ind_out = searchsortedfirst(time, time_out)  # Find first index > time_out

    # print(ind_in, " ", ind_out)
    # println("here")
    # println(ind_in," ", ind_out)
    # println(time[ind_in]/3600, " ", time[ind_out]/3600)
    # sleep(3)
    filt_ind = collect(ind_in:ind_out)
    init_ind = collect(1:(length(time)))
    cross_ind = intersect(filt_ind, init_ind)
     
    println(size(cross_ind))

    if length(cross_ind) == 1
        return false 
    else 
        return cross_ind
    end   
end


function read_met_data_for_one_file(PATH_file, init_day, time_zone,  init_month, init_year)
    dataset = NCDataset(PATH_file, "r")

    all_info = []
    # variable_names = keys(dataset)
    # println("Variables in the dataset: ", variable_names)
    # sleep(200)

    try 
        time_in_datetime = dataset["time"][:] # + num_day + time_zone * 3600 # sec
        time_in_sec, day, month, year =  from_datetime_to_sec(time_in_datetime, init_day, init_month, init_year, time_zone)
        # println(time_in_sec[1:10]- time_in_sec[2:11])
        # sleep(10)
        # time filter. for example +-1 h at 12:00(fix_time) 
        for ind in 1:length(time_in_sec)
            wind_spd = dataset["wspd_arith_mean"][ind] #wspd_vec_mean
            wind_dir = dataset["wdir_vec_mean"][ind] 
            # time_one = time_in_sec[ind]
            time_one = time_in_sec[ind] < 0 ? time_in_sec[ind] + 24*3600 : time_in_sec[ind]
            push!(all_info, [day[ind], month[ind], year[ind], time_one, wind_spd, wind_dir])
        end
    finally 
        close(dataset)
    end
    return all_info
end


function main()

    PATH_output_png = "/home/ellai/test_arm_data/flux_calc/VER6/output_png/"
    PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER6/output_txt/"
    PATH_folder_met = "/home/ellai/data/archive/DOE-SC0021074 (Tracer)/level 1/houmetM1/"

    time_zone = -5 # houston 
    
    set_files = filter(x -> endswith(x, ".cdf"), readdir(PATH_folder_met))
    # println("there are ", length(set_files), " in your folder")
    info_all_files = []
    for file in set_files
        println("processing file: $file")
        file_parts = split(basename(file), ".")
        day =  file_parts[3][7:8]
        month = file_parts[3][5:6]
        year = file_parts[3][1:4]
        println("day ", day, " month ", month, " year ", year)
        file_new = PATH_folder_met*file
        info_one_file = read_met_data_for_one_file(file_new, parse(Int, day), time_zone, parse(Int, month), parse(Int, year))
        info_all_files = vcat(info_all_files, info_one_file)
        println(size(info_all_files))    
    end
    output_file_name = "wind_surface_MET.txt"
    output_file = PATH_output_txt * output_file_name 
    writedlm(output_file, info_all_files )
end

function divide_by_bins(ind , time, wind)
    time = time[ind]
    wind = wind[ind]

    num_intervals = 24 * 2 
    interval_width = 24 / num_intervals
    bin_indices = floor.(Int, time / interval_width) .+ 1 #rounds a number down 

    number = [isempty(wind[bin_indices .== i]) ? NaN : count(!ismissing, wind[bin_indices .== i]) for i in 1:num_intervals]
    intensity = number./maximum(filter(!isnan, number))
    # println(number)
    # println(intensity)
    # intensity = replace(intensity, NaN => 0.0)

    avg_wind = [isempty(wind[bin_indices .== i]) ? NaN : mean(skipmissing(wind[bin_indices .== i])) for i in 1:num_intervals]
    # std_flux = [std(flux[bin_indices .== i]) for i in 1:num_intervals]
    std_wind = [isempty(wind[bin_indices .== i]) ? NaN : std(skipmissing(wind[bin_indices .== i])) for i in 1:num_intervals]
    # time_bins = collect(0:interval_width:24 - interval_width) .+ interval_width / 2
    bin_edges = 0:interval_width:24
    time_bins = bin_edges[1:end-1] .+ interval_width / 2

    upper = avg_wind .+ std_wind
    lower = avg_wind .- std_wind

    return [time_bins, avg_wind, upper, lower, intensity]

end 

function ave_wind_over_season()
    PATH_output_png = "/home/ellai/test_arm_data/flux_calc/VER6/output_png/"
    PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER6/output_txt/"

    output_file_name_w =  "wind_surface_MET.txt"
    input_file_w =  PATH_output_txt * output_file_name_w 
    info_w = readdlm(input_file_w)
    println(size(info_w))
    
    days = info_w[:, 1]
    months = info_w[:, 2]
    year = info_w[:, 3]
    time_w = info_w[:, 4] ./ 3600 
    spd_w = info_w[:, 5]
    

    ind_winter = (months .== 12.0) .| (months .== 1.0) .| (months .== 2.0) 
    ind_spring = (months .== 3) .| (months .== 4) .| (months .== 5) 
    ind_summer = (months .== 6) .| (months .== 7) .| (months .== 8) 
    ind_fall = (months .== 9) .| (months .== 10) .| (months .== 11) 
    
    # println(unique(days[ind_winter]))
    # println(unique(months[ind_winter]))
    # sleep(100)
    info_by_bins_winter = divide_by_bins(ind_winter, time_w, spd_w)
    info_by_bins_spring = divide_by_bins(ind_spring, time_w, spd_w)
    info_by_bins_summer = divide_by_bins(ind_summer, time_w, spd_w)
    info_by_bins_fall  = divide_by_bins(ind_fall, time_w, spd_w)

    colors = cgrad([:purple, :green], 4, categorical = true)
    p = plot(layout=(1, 4), size=(1600, 400), left_margin = 18mm, bottom_margin = 10mm , xguidefont = 18, yguidefont = 18, ytickfont = font(12), xtickfont = font(12), legendfont = font(12), xlim = [-0.2, 24.2])

    scatter!(p[1], info_by_bins_winter[1], info_by_bins_winter[2], label=false, xlabel=L"Time\ (h)", ylabel=L"Wind\ (m/s)", lw=2, marker=:circle, color=colors[1], legend=:topright, ylim=[0, 7],  title="winter", titlefont=font(18))
    plot!(p[1], info_by_bins_winter[1], info_by_bins_winter[3], fill_between=(info_by_bins_winter[4], info_by_bins_winter[3]), fillalpha=0.2, color=colors[1], label=false, lw=0)
    hline!(p[1], [0], color=:black, lw=1, linestyle=:dash, label=false)
    annotate!(p[1], (1, 6.7, text("e", :left, 16)))

    scatter!(p[2], info_by_bins_spring[1], info_by_bins_spring[2], label=false, xlabel=L"Time\ (h)", lw=2, marker=:circle, color=colors[2], legend=:topright,  ylim=[0, 7])
    plot!(p[2], info_by_bins_spring[1], info_by_bins_spring[3], fill_between=(info_by_bins_spring[4], info_by_bins_spring[3]), fillalpha=0.2, color=colors[2], label=false, lw=0)
    hline!(p[2], [0], color=:black, lw=1, linestyle=:dash, label=false)
    annotate!(p[2], (1, 6.7, text("f", :left, 16)))

    scatter!(p[3], info_by_bins_summer[1], info_by_bins_summer[2], label=false,  xlabel=L"Time\ (h)", lw=2, marker=:circle, color=colors[3], legend=:topright,  ylim=[0, 7])
    plot!(p[3], info_by_bins_summer[1], info_by_bins_summer[3], fill_between=(info_by_bins_summer[4], info_by_bins_summer[3]), fillalpha=0.2, color=colors[3], label=false, lw=0)
    hline!(p[3], [0], color=:black, lw=1, linestyle=:dash, label=false)
    annotate!(p[3], (1, 6.7, text("g", :left, 16)))

    scatter!(p[4], info_by_bins_fall[1], info_by_bins_fall[2], label=false, xlabel=L"Time\ (h)", lw=2, marker=:circle, color=colors[4], legend=:topright,  ylim=[0, 7])
    plot!(p[4], info_by_bins_fall[1], info_by_bins_fall[3], fill_between=(info_by_bins_fall[4], info_by_bins_fall[3]), fillalpha=0.2, color=colors[4], label=false, lw=0)
    hline!(p[4], [0], color=:black, lw=1, linestyle=:dash, label=false)
    annotate!(p[4], (1, 6.7, text("h", :left, 16)))

    println(PATH_output_png * "windD_over_season.png")
    savefig(PATH_output_png * "windD_over_season.png")

    data_winter = hcat(info_by_bins_winter[1], info_by_bins_winter[2], info_by_bins_winter[3], info_by_bins_winter[4])
    writedlm(PATH_output_txt * "wind_winter.txt", data_winter)

    data_spring = hcat(info_by_bins_spring[1], info_by_bins_spring[2], info_by_bins_spring[3], info_by_bins_spring[4])
    writedlm(PATH_output_txt * "wind_spring.txt", data_spring)

    data_summer = hcat(info_by_bins_summer[1], info_by_bins_summer[2], info_by_bins_summer[3], info_by_bins_summer[4])
    writedlm(PATH_output_txt * "wind_summer.txt", data_summer)

    data_fall = hcat(info_by_bins_fall[1], info_by_bins_fall[2], info_by_bins_fall[3], info_by_bins_fall[4])
    writedlm(PATH_output_txt * "wind_fall.txt", data_fall)
end 



function ave_wind_dir_over_season()
    PATH_output_png = "/home/ellai/test_arm_data/flux_calc/VER6/output_png/"
    PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER6/output_txt/"

    output_file_name_w =  "wind_surface_MET.txt"
    input_file_w =  PATH_output_txt * output_file_name_w 
    info_w = readdlm(input_file_w)
    println(size(info_w))
    
    days = info_w[:, 1]
    months = info_w[:, 2]
    year = info_w[:, 3]
    time_w = info_w[:, 4] ./ 3600 
    # spd_w = info_w[:, 5]
    spd_w = info_w[:, 6]

    ind_winter = (months .== 12.0) .| (months .== 1.0) .| (months .== 2.0) 
    ind_spring = (months .== 3) .| (months .== 4) .| (months .== 5) 
    ind_summer = (months .== 6) .| (months .== 7) .| (months .== 8) 
    ind_fall = (months .== 9) .| (months .== 10) .| (months .== 11) 
    
    # println(unique(days[ind_winter]))
    # println(unique(months[ind_winter]))
    # sleep(100)
    info_by_bins_winter = divide_by_bins(ind_winter, time_w, spd_w)
    info_by_bins_spring = divide_by_bins(ind_spring, time_w, spd_w)
    info_by_bins_summer = divide_by_bins(ind_summer, time_w, spd_w)
    info_by_bins_fall  = divide_by_bins(ind_fall, time_w, spd_w)

    colors = cgrad([:purple, :green], 4, categorical = true)
    p = plot(layout=(1, 4), size=(1600, 400), left_margin = 18mm, bottom_margin = 10mm , xguidefont = 18, yguidefont = 18, ytickfont = font(12), xtickfont = font(12), legendfont = font(12), xlim = [-0.2, 24.2])

    scatter!(p[1], info_by_bins_winter[1], info_by_bins_winter[2], label=false, xlabel=L"Time\ (h)", ylabel=L"Wind\ (m/s)", lw=2, marker=:circle, color=colors[1], legend=:topright, ylim=[100, 250],  title="winter", titlefont=font(18))
    plot!(p[1], info_by_bins_winter[1], info_by_bins_winter[3], fill_between=(info_by_bins_winter[4], info_by_bins_winter[3]), fillalpha=0.2, color=colors[1], label=false, lw=0)
    hline!(p[1], [0], color=:black, lw=1, linestyle=:dash, label=false)
    annotate!(p[1], (1, 6.7, text("e", :left, 16)))

    scatter!(p[2], info_by_bins_spring[1], info_by_bins_spring[2], label=false, xlabel=L"Time\ (h)", lw=2, marker=:circle, color=colors[2], legend=:topright,  ylim=[100, 250])
    plot!(p[2], info_by_bins_spring[1], info_by_bins_spring[3], fill_between=(info_by_bins_spring[4], info_by_bins_spring[3]), fillalpha=0.2, color=colors[2], label=false, lw=0)
    hline!(p[2], [0], color=:black, lw=1, linestyle=:dash, label=false)
    annotate!(p[2], (1, 6.7, text("f", :left, 16)))

    scatter!(p[3], info_by_bins_summer[1], info_by_bins_summer[2], label=false,  xlabel=L"Time\ (h)", lw=2, marker=:circle, color=colors[3], legend=:topright,  ylim=[100, 250])
    plot!(p[3], info_by_bins_summer[1], info_by_bins_summer[3], fill_between=(info_by_bins_summer[4], info_by_bins_summer[3]), fillalpha=0.2, color=colors[3], label=false, lw=0)
    hline!(p[3], [0], color=:black, lw=1, linestyle=:dash, label=false)
    annotate!(p[3], (1, 6.7, text("g", :left, 16)))

    scatter!(p[4], info_by_bins_fall[1], info_by_bins_fall[2], label=false, xlabel=L"Time\ (h)", lw=2, marker=:circle, color=colors[4], legend=:topright,  ylim=[100, 250])
    plot!(p[4], info_by_bins_fall[1], info_by_bins_fall[3], fill_between=(info_by_bins_fall[4], info_by_bins_fall[3]), fillalpha=0.2, color=colors[4], label=false, lw=0)
    hline!(p[4], [0], color=:black, lw=1, linestyle=:dash, label=false)
    annotate!(p[4], (1, 6.7, text("h", :left, 16)))

    println(PATH_output_png * "windD_over_season_dir.png")
    savefig(PATH_output_png * "windD_over_season_dir.png")

    data_winter = hcat(info_by_bins_winter[1], info_by_bins_winter[2], info_by_bins_winter[3], info_by_bins_winter[4])
    writedlm(PATH_output_txt * "wind_dir_winter.txt", data_winter)

    data_spring = hcat(info_by_bins_spring[1], info_by_bins_spring[2], info_by_bins_spring[3], info_by_bins_spring[4])
    writedlm(PATH_output_txt * "wind_dir_spring.txt", data_spring)

    data_summer = hcat(info_by_bins_summer[1], info_by_bins_summer[2], info_by_bins_summer[3], info_by_bins_summer[4])
    writedlm(PATH_output_txt * "wind_dir_summer.txt", data_summer)

    data_fall = hcat(info_by_bins_fall[1], info_by_bins_fall[2], info_by_bins_fall[3], info_by_bins_fall[4])
    writedlm(PATH_output_txt * "wind_dir_fall.txt", data_fall)
end 




# STEP 0 
# run to collect data  for whole campaing 
# main()

# plot duirnal pattern over the season 
# ave_wind_over_season()
ave_wind_dir_over_season()

