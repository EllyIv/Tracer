using Glob  # for globbing the file patterns
using CSV   # for reading CSV files
using Plots # for plotting
using Colors # for color normalization
using NCDatasets # for NetCDF
using Dates  # to convert dates in sec
using Statistics # for mean
using Dierckx     # For detrend (spline interpolation)
using Polynomials
using StatsBase 
using DSP  # Import DSP package
using DelimitedFiles
using NetCDF
using Measures

# from dataset format to seconds
function from_datetime_to_sec(set_time, day_in, month_in, year_in, time_zone)
    time_sec = hour.(set_time) .* 3600 .+ minute.(set_time) .* 60 .+ second.(set_time) 
    
    base_datetime = DateTime(year_in, month_in, day_in)
    total_time_dt = base_datetime .+ Second.(time_sec)
    dt_local = total_time_dt .+ Hour(time_zone)

    true_year = year.(dt_local)
    true_month = month.(dt_local)
    true_day = day.(dt_local)

    true_time_sec = Dates.value.(dt_local .- DateTime.(true_year, true_month, true_day)) ./ 1000

    return true_time_sec, true_day, true_month, true_year
end

function read_ecor_data_for_one_file(PATH_file,  init_day, time_zone, init_month , init_year)
    dataset = NCDataset(PATH_file, "r")
    # variable_names = keys(dataset)
    # println("Variables in the dataset: ", variable_names)
    # sleep(100)

    k = 0.40 # Karman constant
    g = 9.81 # gravity [m s-2]
    z = 3.0  # measurement Height [m]
    cp = 1005.5 # specific heat capacity [J kg-1 K-1] 

    all_info = []
    try 
        time_in_datetime = dataset["time"][:] # + num_day + time_zone * 3600 # sec, measurements each 30 min
        time_in_sec, day, month, year =  from_datetime_to_sec(time_in_datetime, init_day, init_month, init_year, time_zone)
        # println(time_in_sec[1:10]./3600 - time_in_sec[2:11]./3600)
        # sleep(100)
        for ind in 1:length(time_in_sec)
            u_star_one = dataset["ustar"][ind]# Friction velocity m/s
            heat_one = dataset["h"][ind] # Sensible heat flux W/m^2
            # u_star_one = dataset["ustar"][ind]# Friction velocity m/s
            # heat_one = dataset["h"][ind] # Sensible heat flux W/m^2
            time_one = time_in_sec[ind]
            # mean_t_one = dataset["mean_t"][ind] # Mean t temperature (sonic anemometer) K
            # rho_one = dataset["rho"][ind] # Moist air density kg/m^3
            # mr_one = dataset["mr"][ind] # Mixing ratio kg/kg
            # inv_L_one = - g * k * heat_one / (u_star_one^3 * mean_t_one * rho_one * cp) * (1 + 0.6 * mr_one)
            # z_L_one =  z *  inv_L_one  
            if u_star_one*heat_one !== missing 
                push!(all_info, [day[ind], month[ind], year[ind], time_one, u_star_one, heat_one])
                # continue
            # else 
            #     println(u_star_one, heat_one, mean_t_one, rho_one, mr_one, z_L_one)
            #     sleep(100)
            end
        end
    finally 
        close(dataset)
    end

    
    return all_info
end

# function read_ecor_data_for_one_file_ave(PATH_file,  init_day, time_zone, init_month , init_year)
#     dataset = NCDataset(PATH_file, "r")

#     all_info = []
#     try 
#         time_in_datetime = dataset["time"][:] # + num_day + time_zone * 3600 # sec, measurements each 30 min
#         time_in_sec, day, month, year =  from_datetime_to_sec(time_in_datetime, init_day, init_month, init_year, time_zone)
#         println(time_in_sec[1:10]- time_in_sec[2:11])
#         sleep(100)
#         for ind in 1:length(time_in_sec)
#             u_star_one = dataset["ustar"][ind]# Friction velocity m/s
#             heat_one = dataset["h"][ind] # Sensible heat flux W/m^2
#             push!(all_info, [day[ind], month[ind], year[ind], time_one, u_star_one, heat_one ])
#         end
#     finally 
#         close(dataset)
#     end

#     day_vec = [row[1] for row in all_info]
#     month_vec = [row[2] for row in all_info]
#     year_vec = [row[3] for row in all_info]
#     time = [row[4] for row in all_info]
#     ustar = [row[5] for row in all_info]
#     heat = [row[5] for row in all_info]

#     return [day_vec, month_vec, year_vec, time, ustar, heat]

    # hours = floor.(Int, time)
    # hours_unique = sort(unique(hours))
    # hours_unique_final = []

    # mean_zL = []
    # final_day = []
    # final_month = []
    # final_year = []
    # for uh in hours_unique
    #     ind_set = []
    #     for ih in 1:length(hours)
    #         if hours[ih] == uh
    #             push!(ind_set, ih)
    #         end
    #     end 
    #     z_L_for_h = mean(skipmissing(z_L[ind_set]))   
    #     if !isnan(z_L_for_h)       
    #         push!(mean_zL, z_L_for_h)
    #         push!(hours_unique_final, uh)
    #         push!(final_day, day_vec[ind_set[1]])
    #         push!(final_month, month_vec[ind_set[1]])
    #         push!(final_year, year_vec[ind_set[1]])
    #     end 
    # end

    # return [hours_unique_final, mean_zL, final_day, final_month, final_year]
# end

function main()
    PATH_folder_ecor = "/home/ellai/data/archive/DOE-SC0021074 (Tracer)/level 1/hou30ecorM1/" # for Obuh. L 
    PATH_output_png = "/home/ellai/test_arm_data/flux_calc/VER6/output_png/"
    PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER6/output_txt/"
    
 
    time_zone = -5 # houston 
    info_all_files = []

    set_files = filter(x -> endswith(x, ".cdf"), readdir(PATH_folder_ecor))
    for file in set_files
        println(file)
        
        file_parts = split(basename(file), ".")
        day = file_parts[3][7:8]
        month = file_parts[3][5:6]
        year = file_parts[3][1:4]
        println("day ", day, " month ", month, " year ", year)
        
        file_new = PATH_folder_ecor*file
        info_one_file = read_ecor_data_for_one_file(file_new, parse(Int, day), time_zone, parse(Int, month) , parse(Int, year)) #[num_day, month, year, z_L_m, z_L_d, z_L_e]
        # day[ind], month[ind], year[ind], time_one, z_L_one
        for row in info_one_file
            new_row = [row[1], row[2], row[3], row[4], row[5],  row[6]]
            push!(info_all_files, new_row)
        end        
        println(size(info_all_files))
    end 
    
    output_file_name = "turbulent_regime.txt"
    output_file = PATH_output_txt * output_file_name 
    println(output_file)
    writedlm(output_file, info_all_files)
end 

# separation by turbulent groups
function divide_by_group(a, b)
    if a === missing || b === missing
        return 0
    end

    heat_level_1 = 50
    heat_level_2 = 120 

    ustar_level_1 = 0.2
    ustar_level_2 = 0.4

    if 0 < a < ustar_level_1
        if 0 < b < heat_level_1
            return 1
        elseif heat_level_1 < b < heat_level_2
            return 4
        elseif b > heat_level_2
            return 7
        end
    elseif ustar_level_1 < a < ustar_level_2
        if 0 < b < heat_level_1
            return 2
        elseif heat_level_1 < b < heat_level_2
            return 5
        elseif b > heat_level_2
            return 8
        end
    elseif a > ustar_level_2
        if 0 < b < heat_level_1
            return 3
        elseif heat_level_1 < b < heat_level_2
            return 6
        elseif b > heat_level_2
            return 9
        end
    end

    return 0  # everything else
end

# function stability_mde()
#     PATH_output_png = "/home/ellai/test_arm_data/flux_calc/VER2/output_png/"
#     PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER2/output_txt/"
#     input_file = PATH_output_txt * "turbulent_regime.txt"
#     data = readdlm(input_file)

#     dates = unique(data[:, 1:3], dims=1) #unique dates

#     results = []
#     for date in eachrow(dates)
#         d, m, y = date
#         mask = data[:, 1] .== d .&& data[:, 2] .== m .&& data[:, 3] .== y
#         subdata = data[mask, :]
#         hours = subdata[:, 4]
#         values_ustar = subdata[:, 5]
#         values_heat = subdata[:, 5]

#         ranges = [(6, 8), (11, 13), (16, 18)]
#         avgs = []
    
#         for (low, high) in ranges
#             in_range = (hours .>= low) .& (hours .<= high)
#             selected_vals = values[in_range]
#             avg_val = isempty(selected_vals) ? NaN : mean(selected_vals)
#             push!(avgs, avg_val)
#         end
        
#         push!(results, hcat(d, m, y, avgs...))

#     end

#     output_file_name = "stability_conditions_mde.txt"
#     output_file = PATH_output_txt * output_file_name 
#     writedlm(output_file, reduce(vcat, results))

# end 


function align_data_with_lidar()
    PATH_output_png = "/home/ellai/test_arm_data/flux_calc/VER6/output_png/"
    PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER6/output_txt/"
    
    # DATA from LIDAR
    # combine info for 2021 and 2022
    input_file_time = "time_lidar.txt"
    input_file_stb = "turbulent_regime.txt"

    input_data_time = readdlm(PATH_output_txt * input_file_time)         # day / month / year / time (LIDAR)
    input_data_stb = readdlm(PATH_output_txt * input_file_stb)             # day / month / year / time / h_all / rh_all / temp_all
    println(size(input_data_time))

    # Extract unique days from lidar time
    time_day_keys = [(input_data_time[i,1], input_data_time[i,2], input_data_time[i,3]) for i in 1:size(input_data_time,1)]
    unique_days = unique(time_day_keys)
    interpolated_stb = []

    count, count_2 = 0, 0
    count_days, count_days_2 = [], []

    for day in unique_days
        day_lidar, m_lidar, y_lidar = day

        idxs_time = findall(x -> x[1]==day_lidar && x[2]==m_lidar && x[3]==y_lidar, time_day_keys)
        lidar_times = input_data_time[idxs_time, 4]

        mask_day = (input_data_stb[:,1] .== day_lidar) .&
                   (input_data_stb[:,2] .== m_lidar) .&
                   (input_data_stb[:,3] .== y_lidar)

        stb_times = input_data_stb[mask_day, 4]
        values_ustar = input_data_stb[mask_day, 5]
        values_heat = input_data_stb[mask_day, 6]

        
        if isempty(stb_times)
            for t_lidar in lidar_times
                push!(interpolated_stb, [day_lidar, m_lidar, y_lidar, t_lidar, missing, missing, missing]) 
                
                count += 1
                push!(count_days, [day_lidar, m_lidar, y_lidar])
            end
            continue
        end

        
        for t_lidar in lidar_times
            time_diffs = abs.(stb_times .- t_lidar)
            if minimum(time_diffs) <= 1 * 3600
                idx_closest = argmin(time_diffs)
                t_stb = stb_times[idx_closest]

                idx_match = findall(stb_times .== t_stb)
                ustar_set1 = values_ustar[idx_match][1]
                heat_set1 = values_heat[idx_match][1]
                group = divide_by_group(ustar_set1, heat_set1)
                push!(interpolated_stb, [day_lidar, m_lidar, y_lidar, t_lidar, ustar_set1, heat_set1, group])
                
            else
                push!(interpolated_stb, [day_lidar, m_lidar, y_lidar, t_lidar, missing, missing, missing])
                
                count_2 += 1
                push!(count_days_2, [day_lidar, m_lidar, y_lidar])
            end
        end
    end
    unique_days = unique(count_days)
    unique_days_2 = unique(count_days_2)

    println("missing days ", count, ", which is ", round(count/length(interpolated_stb)*100),"% from all data set,  or ", length(unique_days), " days")
    println("missing time gap ", count_2, ", which is ", round(count_2/length(interpolated_stb)*100),"% from all data set,  or ", length(unique_days_2), " days")
    println(size(interpolated_stb))
    writedlm(PATH_output_txt * "regime_aligned_with_lidar.txt", interpolated_stb)
    println(PATH_output_txt * "regime_aligned_with_lidar.txt")
    
    ustar_data = [x[5] for x in interpolated_stb]
    heat_data = [x[6] for x in interpolated_stb]
    # println(ustar_data)
    # println(heat_data)
    println(size(interpolated_stb), size(interpolated_stb[1]))
    plot(size = (750, 550), left_margin = 10mm, bottom_margin = 10mm, right_margin = 10mm,  xguidefont = 18, yguidefont = 18, ytickfont = font(12), xtickfont = font(12), legendfont = font(12))
    scatter!(ustar_data, heat_data, color=:yellow, label=false, marker=:circle, xlabel=L"u^* (m/s)", ylabel=L"H (W/m^2)", alpha=0.1, legend=:topright, markersize=3, ylim = (0, 350), xlims = (0,0.8))
    # scatter!(u_star_d, heat_d, color=:green, label="11:00–13:00", marker=:square, alpha=0.5, markersize=3)
    # scatter!(u_star_e, heat_e, color=:blue, label="16:00–18:00", marker=:diamond, alpha=0.5, markersize=3)

    hline!([0, 50, 120], linestyle=:dash, color=:gray, label="")
    vline!([0.2, 0.4], linestyle=:dash, color=:gray, label="")

    plot!([0.01, 0.05, 0.05, 0.01], [30, 30, 50, 50], seriestype = :shape, color = :white, alpha = 0.8, label = "")
    annotate!(0.03, 40, text("1", 12, :red))
    plot!([0.21, 0.25, 0.25, 0.21], [30, 30, 50, 50], seriestype = :shape, color = :white, alpha = 0.8, label = "")
    annotate!(0.23, 40, text("2", 12, :red))
    plot!([0.41, 0.45, 0.45, 0.41], [30, 30, 50, 50], seriestype = :shape, color = :white, alpha = 0.8, label = "")
    annotate!(0.43, 40, text("3", 12, :red))
    plot!([0.01, 0.05, 0.05, 0.01], [90, 90, 110, 110], seriestype = :shape, color = :white, alpha = 0.8, label = "")
    annotate!(0.03, 100, text("4", 12, :red))
    plot!([.21, 0.25, 0.25, 0.21], [90, 90, 110, 110], seriestype = :shape, color = :white, alpha = 0.8, label = "")
    annotate!(0.23, 100, text("5", 12, :red))
    plot!([0.41, 0.45, 0.45, 0.41], [90, 90, 110, 110], seriestype = :shape, color = :white, alpha = 0.8, label = "")
    annotate!(0.43, 100, text("6", 12, :red))
    plot!([0.01, 0.05, 0.05, 0.01], [140, 140, 160, 160], seriestype = :shape, color = :white, alpha = 0.8, label = "")
    annotate!(0.03, 150, text("7", 12, :red))
    plot!([.21, 0.25, 0.25, 0.21], [140, 140, 160, 160], seriestype = :shape, color = :white, alpha = 0.8, label = "")
    annotate!(0.23, 150, text("8", 12, :red))
    plot!([0.41, 0.45, 0.45, 0.41], [140, 140, 160, 160], seriestype = :shape, color = :white, alpha = 0.8, label = "")
    annotate!(0.43, 150, text("9", 12, :red))


    savefig(PATH_output_png*"turbulent_regime_all_campaing_unstable.png")



end



function align_data_with_lidar_wo_grouping()
    PATH_output_png = "/home/ellai/test_arm_data/flux_calc/VER6/output_png/"
    PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER6/output_txt/"
    
    # DATA from LIDAR
    # combine info for 2021 and 2022
    input_file_time = "time_lidar.txt"
    input_file_stb = "turbulent_regime.txt"

    input_data_time = readdlm(PATH_output_txt * input_file_time)         # day / month / year / time (LIDAR)
    input_data_stb = readdlm(PATH_output_txt * input_file_stb)             # day / month / year / time / h_all / rh_all / temp_all
    println(size(input_data_time))

    # Extract unique days from lidar time
    time_day_keys = [(input_data_time[i,1], input_data_time[i,2], input_data_time[i,3]) for i in 1:size(input_data_time,1)]
    unique_days = unique(time_day_keys)
    interpolated_stb = []

    count, count_2 = 0, 0
    count_days, count_days_2 = [], []

    for day in unique_days
        day_lidar, m_lidar, y_lidar = day

        idxs_time = findall(x -> x[1]==day_lidar && x[2]==m_lidar && x[3]==y_lidar, time_day_keys)
        lidar_times = input_data_time[idxs_time, 4]

        mask_day = (input_data_stb[:,1] .== day_lidar) .&
                   (input_data_stb[:,2] .== m_lidar) .&
                   (input_data_stb[:,3] .== y_lidar)

        stb_times = input_data_stb[mask_day, 4]
        values_ustar = input_data_stb[mask_day, 5]
        values_heat = input_data_stb[mask_day, 6]

        
        if isempty(stb_times)
            for t_lidar in lidar_times
                push!(interpolated_stb, [day_lidar, m_lidar, y_lidar, t_lidar, missing, missing]) 
                
                count += 1
                push!(count_days, [day_lidar, m_lidar, y_lidar])
            end
            continue
        end

        
        for t_lidar in lidar_times
            time_diffs = abs.(stb_times .- t_lidar)
            if minimum(time_diffs) <= 1 * 3600
                idx_closest = argmin(time_diffs)
                t_stb = stb_times[idx_closest]

                idx_match = findall(stb_times .== t_stb)
                ustar_set1 = values_ustar[idx_match][1]
                heat_set1 = values_heat[idx_match][1]
                push!(interpolated_stb, [day_lidar, m_lidar, y_lidar, t_lidar, ustar_set1, heat_set1])
                
            else
                push!(interpolated_stb, [day_lidar, m_lidar, y_lidar, t_lidar, missing, missing])
                
                count_2 += 1
                push!(count_days_2, [day_lidar, m_lidar, y_lidar])
            end
        end
    end
    
    writedlm(PATH_output_txt * "regime_aligned_with_lidar_wo_grouping.txt", interpolated_stb)
    println(PATH_output_txt * "regime_aligned_with_lidar_wo_grouping.txt")
end





main()
# align_data_with_lidar()
align_data_with_lidar_wo_grouping()
