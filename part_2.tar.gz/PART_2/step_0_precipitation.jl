using Glob  
using CSV   
using Plots 
using Colors 
using NCDatasets 
using Dates 
using Statistics 
using Dierckx    
using Polynomials
using StatsBase 
using DSP  
using DelimitedFiles
using NetCDF
using Measures



# const PATH_folder_sonde = "/home/ellai/data/archive/DOE-SC0021074 (Tracer)/level 1/houinterpolatedsondeM1/"
# const PATH_folder_sonde2 = "/home/ellai/data/archive/DOE-SC0021074 (Tracer)/level 1/houpblhtsonde1mcfarlM1/"
const PATH_output_png = "/home/ellai/test_arm_data/flux_calc/VER6/output_png/"
const PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER6/output_txt/"
const PATH_folder_sonde = "/home/ellai/data/archive/DOE-SC0021074 (Tracer)/level 1/houinterpolatedsondeM1/"  # for rh and temperature
const PATH_folder_beatm = "/home/ellai/data/archive/DOE-SC0021074 (Tracer)/level 1/houarmbeatmM1.c1/"  


const time_gap = 0.5 * 3600 # sec 
const time_zone = -5


function from_datetime_to_sec(set_time, day_in, month_in, year_in)
    time_sec = hour.(set_time) .* 3600 .+ minute.(set_time) .* 60 .+ second.(set_time) 
    
    base_datetime = DateTime(year_in, month_in, day_in)
    total_time_dt = base_datetime .+ Second.(time_sec)
    dt_local = total_time_dt .+ Hour(time_zone)

    true_year = year.(dt_local)
    true_month = month.(dt_local)
    true_day = day.(dt_local)

    true_time_sec = Dates.value.(dt_local .- DateTime.(true_year, true_month, true_day)) ./ 1000

    return true_time_sec, true_day, true_month, true_year
end


function read_sonde_data_for_one_file(PATH_file,  day_str, month_str, year_str)
    dataset = NCDataset(PATH_file, "r")
    init_day = parse(Int, day_str)
    init_month = parse(Int, month_str)
    init_year = parse(Int, year_str)

    # variable_names = keys(dataset)
    # println("Variables in the dataset: ", variable_names)
    # wind = dataset["u_wind"]
    # println(size(wind))
    # sleep(100)

    # precip_var = dataset["precip"]
    # println("Attributes for 'precip':")
    # for (key, value) in precip_var.attrib
    #     println("$key => $value")
    # end


    all_info = []
    try 
        time_in_datetime = dataset["time"][:] # + num_day + time_zone * 3600 # sec, measurements each 30 min
        time_in_sec, day, month, year =  from_datetime_to_sec(time_in_datetime, init_day, init_month, init_year) 
        # println(time_in_sec[1:10]- time_in_sec[2:11])
        # sleep(100)
        precip_data = dataset["precip"] # only 1 d
        for i in 1:length(time_in_sec)
            push!(all_info, [day[i], month[i], year[i], time_in_sec[i], precip_data[i]])
        end  
        
    finally 
        close(dataset)
    end
    return all_info
end




function align_data_with_lidar()
    # PATH_output_png = "/home/ellai/test_arm_data/flux_calc/VER4/output_png/"
    # PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER4/output_txt/"
    
    # DATA from LIDAR
    # combine info for 2021 and 2022
    input_file_time = "time_lidar.txt"
    input_file_prc_1 = "precipitation.txt"
    input_file_prc_2 = "precipitation_2.txt"

    # if option == 1
    #     input_file_prc = "precipitation.txt"
    # elseif  option == 2
    #     input_file_prc = "precipitation_2.txt"
    # end 

    input_data_time = readdlm(PATH_output_txt * input_file_time)         # day / month / year / time (LIDAR)
    input_data_prc_1 = readdlm(PATH_output_txt * input_file_prc_1)             # day / month / year / time / h_all / rh_all / temp_all
    input_data_prc_2 = readdlm(PATH_output_txt * input_file_prc_2)             # day / month / year / time / h_all / rh_all / temp_all

    input_data_prc = vcat(input_data_prc_1, input_data_prc_2)

    # println(size(input_data_time))

    # Extract unique days from lidar time
    time_day_keys = [(input_data_time[i,1], input_data_time[i,2], input_data_time[i,3]) for i in 1:size(input_data_time,1)]
    unique_days = unique(time_day_keys)
    interpolated_prc = []

    count, count_2 = 0, 0
    count_days, count_days_2 = [], []

    for day in unique_days
        day_lidar, m_lidar, y_lidar = day

        # Get all lidar times for this day
        idxs_time = findall(x -> x[1]==day_lidar && x[2]==m_lidar && x[3]==y_lidar, time_day_keys)
        lidar_times = input_data_time[idxs_time, 4]

        # Filter RH data for the same day
        mask_day = (input_data_prc[:,1] .== day_lidar) .&
                   (input_data_prc[:,2] .== m_lidar) .&
                   (input_data_prc[:,3] .== y_lidar)

        prc_times = input_data_prc[mask_day, 4]
        prc_values = input_data_prc[mask_day, 5]

        
        if isempty(prc_times)
            for t_lidar in lidar_times
                push!(interpolated_prc, [day_lidar, m_lidar, y_lidar, t_lidar, missing]) 
                
                count += 1
                push!(count_days, [day_lidar, m_lidar, y_lidar])
            end
            continue
        end

        
        for t_lidar in lidar_times
            time_diffs = abs.(prc_times .- t_lidar)
            if minimum(time_diffs) <= time_gap
                idx_closest = argmin(time_diffs)
                t_prc = prc_times[idx_closest]

                idx_match = findall(prc_times .== t_prc)
                prc_set1 = prc_values[idx_match][1]
                push!(interpolated_prc, [day_lidar, m_lidar, y_lidar, t_lidar, prc_set1])
                
            else
                push!(interpolated_prc, [day_lidar, m_lidar, y_lidar, t_lidar, missing])
                
                count_2 += 1
                push!(count_days_2, [day_lidar, m_lidar, y_lidar])
            end
        end
    end
    unique_days = unique(count_days)
    unique_days_2 = unique(count_days_2)

    println("missing days ", count, ", which is ", round(count/length(interpolated_prc)*100),"% from all data set,  or ", length(unique_days), " days")
    println("missing time gap ", count_2, ", which is ", round(count_2/length(interpolated_prc)*100),"% from all data set,  or ", length(unique_days_2), " days")
    println(size(interpolated_prc))
    # if option == 1
    writedlm(PATH_output_txt * "prc_aligned_with_lidar.txt", interpolated_prc)
    println(PATH_output_txt * "prc_aligned_with_lidar.txt")
    # elseif option == 2 
    #     writedlm(PATH_output_txt * "prc_aligned_with_lidar_2.txt", interpolated_prc)
    #     println(PATH_output_txt * "prc_aligned_with_lidar_2.txt")
    # end 
end

function main_part1()
    # PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER4/output_txt/"

    # time_zone = -5 # houston 
    
    info_sonde_all_days = []

    set_files = filter(x -> endswith(x, ".nc"), readdir(PATH_folder_sonde))
    for file in set_files
        file_parts = split(basename(file), ".")
        day = file_parts[3][7:8]
        month = file_parts[3][5:6]
        year = file_parts[3][1:4]
        println("day ", day, " month ", month, " year ", year)

        file_new = PATH_folder_sonde * file
        info_one_file = read_sonde_data_for_one_file(file_new, day, month, year) # [day_int, month_int, year_int, rh_d, t_d]
        append!(info_sonde_all_days, info_one_file)
    end

    #[day, month, year, time, ave_rh, ave_temp]

    output_file_name = "precipitation.txt"
    output_file = PATH_output_txt * output_file_name
    println(output_file)
    writedlm(output_file, info_sonde_all_days)
   
end 

function main_part2()
    # PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER4/output_txt/"

    file_1 = PATH_folder_beatm *  "houarmbeatmM1.c1.20211001.003000.nc"
    dataset_1 = NCDataset(file_1, "r")
   
    variable_names = keys(dataset_1)
    println("Variables in the dataset: ", variable_names)
    
    time_set_1 = dataset_1["time"][:] # + num_day + time_zone * 3600 # sec, measurements each 30 min
    precip_set_1 = dataset_1["precip_rate_sfc"][:]
    new_precip = []
    for i in 1:length(time_set_1)
        t = time_set_1[i]
        year_val  = year(t)
        month_val = month(t)
        day_val   = day(t)
        sec_val   = Dates.value(Dates.Time(t))
        push!(new_precip, [day_val, month_val, year_val, sec_val, precip_set_1[i]])
    end 

    file_2 = PATH_folder_beatm *  "houarmbeatmM1.c1.20220101.003000.nc"
    dataset_2 = NCDataset(file_2, "r")
    
    time_set_2 = dataset_2["time"][:] # + num_day + time_zone * 3600 # sec, measurements each 30 min
    precip_set_2 = dataset_2["precip_rate_sfc"][:]
    for i in 1:length(time_set_2)
        t = time_set_2[i]
        year_val  = year(t)
        month_val = month(t)
        day_val   = day(t)
        sec_val   = Dates.value(Dates.Time(t))÷ 1_000_000_000
        # println(t)
        # println(sec_val)
        # sleep(5) 
        push!(new_precip, [day_val, month_val, year_val, sec_val, precip_set_2[i]])
    end 

    output_file_name = "precipitation_2.txt"
    output_file = PATH_output_txt * output_file_name
    println(output_file)
    writedlm(output_file, new_precip)
end 
    # wind = dataset["u_wind"]
    # println(size(wind))
    # sleep(100)

    # precip_var = dataset["precip"]
    # println("Attributes for 'precip':")
    # for (key, value) in precip_var.attrib
    #     println("$key => $value")
    # endend 
# function read_sonde_data_PROFILE(PATH_file, time_zone, fix_t)
#     dataset = NCDataset(PATH_file, "r")
#     # variable_names = keys(dataset)
#     # println("Variables in the dataset: ", variable_names)
#     # sleep(100)
#     all_info = []
#     try 
#         time_in_datetime = dataset["time"][:] # + num_day + time_zone * 3600 # sec, measurements each 30 min
#         time_in_sec =  from_datetime_to_sec(time_in_datetime)
#         time_in_h = (time_in_sec  .+ time_zone*3600 )/3600  # in h 
#         mask = (time_in_h .>= 0) .& (abs.(time_in_h .- fix_t) .< 1)
#         time_in_h = time_in_h[mask]

#         height_m = dataset["height"] * 1000 # m 
#         rh_data = dataset["rh"]
#         t_data = dataset["potential_temp"]

#         rh_data = rh_data[:, mask] 
#         t_data = t_data[:, mask] 
#         rh_mean = [mean(skipmissing(rh_data[i, :])) for i in 1:size(rh_data, 1)]
#         t_mean = [mean(skipmissing(t_data[i, :])) for i in 1:size(t_data, 1)]
#         all_info = [height_m , rh_mean, t_mean]
#     finally 
#         close(dataset)
#     end
    
#     return all_info
# end

# function data_for_one_day(fix_d, fix_m, fix_y, fix_t)
#     PATH_folder_sonde = "/home/ellai/data/tracer/level 1/houinterpolatedsondeM1/"  # for rh and temperature
#     PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER2/output_txt/"

#     time_zone = -5 # houston 
    
#     info_sonde_all_days = []
#     # count = 0 
#     set_files = filter(x -> endswith(x, ".nc"), readdir(PATH_folder_sonde))
#     for file in set_files
#         file_parts = split(basename(file), ".")
#         day = file_parts[3][7:8]
#         month = file_parts[3][5:6]
#         year = file_parts[3][1:4]
#         if parse(Int, day)  == fix_d && fix_m == parse(Int, month) && fix_y == parse(Int, year) 
#             count = 1
#             println("day ", day, " month ", month, " year ", year)
#             file_new = PATH_folder_sonde * file
#             info_one_file = read_sonde_data_PROFILE(file_new, time_zone, fix_t) # [day_int, month_int, year_int, rh_d, t_d]
#             append!(info_sonde_all_days, info_one_file)
#         end 
#     end
#     # if count == 0 
#     #     println("ooops")
#     #     println("no info")
#     # end 
#     #[day, month, year, time, ave_rh, ave_temp]
    
#     if !isempty(info_sonde_all_days)
#         output_file_name = "DATA_sonde_rh_temp_PROFILE_for_"*string(fix_d)*"_"*string(fix_m)*"_"*string(fix_y)*".txt"
#         output_file = PATH_output_txt * output_file_name
#         writedlm(output_file, info_sonde_all_days, ',')
#     end
# end 

# main_part1()
# main_part2()
align_data_with_lidar()

# prc checked in 3 h gap: then we loose 5 %
# prc checked in 2 h gap: then we loose 6 %
# prc checked in 1 h gap: then we loose 7 %
# prc checked in 0.5 h gap: then we loose 7 % ! 

# missing days 0, which is 0.0% from all data set,  or 0 days
# missing time gap 4309, which is 13.0% from all data set,  or 53 days
# (32508,)


# 7 3 2022    #23 3 2022

# day = 13
# month = 6
# year = 2022
# time = 12 
# data_for_one_day(day, month, year, time)

# 7 3 2022    #23 3 2022  # 24 12 2021   [0.45, 0.5]
# 16.011.02021.0 23.012.02021.0   28.01.02022.0(!, 0.43, 140)  18.02.02022.0(!, 0.43, 248) 22.3.2022 (0.44 144) 8.5.2022 #13.6.2022(! 0.41 173)
