using DelimitedFiles
using Statistics
using Dates
using Plots
using Measures
using LaTeXStrings
using ColorSchemes
using Distributed
addprocs(64)

function find_closest(day_arr, month_arr, year_arr, time_arr, val_arr, day, month, year, time_sec)
    time_h = round.(time_sec ./ 3600, digits=1)
    mask = (day_arr .== day) .& (month_arr .== month) .& (year_arr .== year)
    if !any(mask)
        return missing
    end

    times = time_arr[mask]
    vals  = val_arr[mask]
    mask_valid = .!ismissing.(vals)
    if !any(mask_valid)
        return missing
    end

    times = times[mask_valid]
    vals  = vals[mask_valid]
    diffs = abs.(times .- time_h)
    idx = findmin(diffs)[2]
    return diffs[idx] <= 3 ? vals[idx] : missing
end



function main()
    PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER6/output_txt/"
    PATH_output_lidar = "/home/ellai/test_arm_data/flux_calc/VER6/output_txt/"
    

    # Read ceil PBL data
    file_ceil = PATH_output_txt * "pbl_ceil.txt"
    info_ceil = readdlm(file_ceil)

    ceil_day    = info_ceil[:, 1]
    ceil_month  = info_ceil[:, 2]
    ceil_year   = info_ceil[:, 3]
    ceil_time_h = round.(info_ceil[:, 4] ./3600, digits=1) # h 
    ceil_pbl    = info_ceil[:, 5]   
    ceil_pbl    = replace(ceil_pbl, "missing" => missing)


    # Read ceil PBL data
    file_inv = PATH_output_txt * "pbl_aligned_with_lidar_temp_inversion.txt"
    info_inv = readdlm(file_inv)

    inv_day    = info_inv[:, 1]
    inv_month  = info_inv[:, 2]
    inv_year   = info_inv[:, 3]
    inv_time_h = round.(info_inv[:, 4], digits=1) # h 
    inv_pbl    = info_inv[:, 5]   
    inv_pbl    = replace(inv_pbl, "missing" => missing)

    # Read sonde PBL data
    file_sonde = PATH_output_txt * "pbl_sonde.txt"
    info_sonde = readdlm(file_sonde)
    
    sonde_day    = info_sonde[:, 1]
    sonde_month  = info_sonde[:, 2]
    sonde_year   = info_sonde[:, 3]
    sonde_time_h = round.(info_sonde[:, 4] ./3600, digits=1) # h
    sonde_pbl1   = info_sonde[:, 5]
    sonde_pbl2   = info_sonde[:, 6]
    sonde_pbl3   = info_sonde[:, 7]
    sonde_pbl4   = info_sonde[:, 8]

    sonde_pbl1   = replace(sonde_pbl1, "missing" => missing)
    sonde_pbl2   = replace(sonde_pbl2, "missing" => missing)
    sonde_pbl3   = replace(sonde_pbl3, "missing" => missing)
    sonde_pbl4   = replace(sonde_pbl4, "missing" => missing)


    # Read lidar time grid
    file_lidar = PATH_output_lidar * "time_lidar.txt"
    info_lidar = readdlm(file_lidar)
    lidar_day    = info_lidar[:, 1]
    lidar_month  = info_lidar[:, 2]
    lidar_year   = info_lidar[:, 3]
    lidar_time = info_lidar[:, 4] # h
    lidar_dt     = round.(info_lidar[:, 5] ./ 3600, digits=1) # h


    combos = unique([(lidar_day[i], lidar_month[i], lidar_year[i], lidar_time[i], lidar_dt[i])
                     for i in eachindex(lidar_day)])
    println("Total lidar time points: ", length(combos))

    

    # Loop through lidar time
    results = Any[]
    for (day, month, year, time_sec, dt) in combos
        pbl_ceil   = find_closest(ceil_day, ceil_month, ceil_year, ceil_time_h, ceil_pbl, day, month, year, time_sec)
        pbl_sonde1 = find_closest(sonde_day, sonde_month, sonde_year, sonde_time_h, sonde_pbl1, day, month, year, time_sec)
        pbl_sonde2 = find_closest(sonde_day, sonde_month, sonde_year, sonde_time_h, sonde_pbl2, day, month, year, time_sec)
        pbl_sonde3 = find_closest(sonde_day, sonde_month, sonde_year, sonde_time_h, sonde_pbl3, day, month, year, time_sec)
        pbl_sonde4 = find_closest(sonde_day, sonde_month, sonde_year, sonde_time_h, sonde_pbl4, day, month, year, time_sec)
        pbl_inv    = find_closest(inv_day, inv_month, inv_year, inv_time_h, inv_pbl, day, month, year, time_sec)

        push!(results, [day, month, year, time_sec, pbl_ceil, pbl_sonde1, pbl_sonde2, pbl_sonde3, pbl_sonde4, pbl_inv])
    end


    # Save results
    output_file = PATH_output_txt * "pbl_aligned_with_lidar.txt"
    writedlm(output_file, results)
    println(output_file)
end


function plot_pbl_months()
    PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER6/output_txt/"
    PATH_output_png = "/home/ellai/test_arm_data/flux_calc/VER6/output_png/"

    # --- Read data ---
    file_pbl = PATH_output_txt * "pbl_aligned_with_lidar.txt"
    info_pbl = readdlm(file_pbl)

    day    = info_pbl[:, 1]
    month  = info_pbl[:, 2]
    year   = info_pbl[:, 3]
    time_h = info_pbl[:, 4]
    pbl_ceil   = info_pbl[:, 5]
    pbl_sonde1 = info_pbl[:, 6]
    pbl_sonde2 = info_pbl[:, 7]
    pbl_sonde3 = info_pbl[:, 8]
    pbl_sonde4 = info_pbl[:, 9]
    pbl_inv    = info_pbl[:, 10]


    pbl_ceil   = replace(pbl_ceil, "missing" => missing)
    pbl_sonde1 = replace(pbl_sonde1, "missing" => missing)
    pbl_sonde2 = replace(pbl_sonde2, "missing" => missing)
    pbl_sonde3 = replace(pbl_sonde3, "missing" => missing)
    pbl_sonde4 = replace(pbl_sonde4, "missing" => missing)
    pbl_inv    = replace(pbl_inv, "missing" => missing)


    # --- Filter daytime (9–18 h) ---
    mask_daytime = (time_h .>= 12) .& (time_h .<= 15)
    day    = day[mask_daytime]
    month  = month[mask_daytime]
    year   = year[mask_daytime]
    time_h = time_h[mask_daytime]
    pbl_ceil   = pbl_ceil[mask_daytime]
    pbl_sonde1 = pbl_sonde1[mask_daytime]
    pbl_sonde2 = pbl_sonde2[mask_daytime]
    pbl_sonde3 = pbl_sonde3[mask_daytime]
    pbl_sonde4 = pbl_sonde4[mask_daytime]
    pbl_inv    = pbl_inv[mask_daytime]

    # --- Plot per month ---
    label_map = Dict( "pbl_ceil"      => "Ceil",
                      "pbl_inv"       => "Temp Inv",
                      "pbl_sonde1"    => "Heffter",
                      "pbl_sonde2"    => "Liu-Liang",
                      "pbl_sonde3"    => "Richardson1",
                      "pbl_sonde4"    => "Richardson2")
    
    set_pbl_1 = pbl_sonde2
    set_pbl_2 = pbl_inv

    name_1 = "pbl_sonde2"
    name_2 = "pbl_inv"


    months = sort(unique(month))
    p = []
    for m in months
        mask_m = month .== m
        valid = .!(ismissing.(set_pbl_1[mask_m]) .| ismissing.(set_pbl_2[mask_m]))

        if any(valid)
            println(m , " ", length(set_pbl_1[mask_m][valid]))
            p_m = scatter(set_pbl_1[mask_m][valid], set_pbl_2[mask_m][valid],
                          xlabel=label_map[name_1],
                          ylabel=label_map[name_2],
                          title="Month = $m",
                          legend=false,
                          markersize=4,
                          alpha = 0.1,
                          color=:blue, 
                          xlims = [0, 3000], ylims = [0, 3000])
            plot!(p_m, [0, 3000], [0, 3000],
                          color=:red, linestyle=:dash, linewidth=1.5, label=false)
        else
            p_m = plot(title="Month = $m\n(no valid data)", grid=false, xlims = [0, 3000], ylims = [0, 3000])
        end

        push!(p, p_m)
    end
    # dx = 0.1
    # edges = 0:dx:5  # same bin width for all months

    # for m in months
    #     mask_m = month .== m
    #     valid = .!(ismissing.(set_pbl_1[mask_m]) .| ismissing.(set_pbl_2[mask_m]))

    #     if any(valid)
    #         data1 = set_pbl_1[mask_m][valid]
    #         data2 = set_pbl_2[mask_m][valid]

    #         ratio = data1./ data2
    #         ratio = ratio[.!isnan.(ratio) .& .!isinf.(ratio)]

    #         p_m = histogram(ratio,
    #                         bins=edges,             # fixed Δx
    #                         xlabel="Sonde / Ceil ratio",
    #                         ylabel="Count",
    #                         title="Month = $m",
    #                         legend=false,
    #                         color=:blue,
    #                         alpha=0.4,
    #                         linecolor=:black,
    #                         xlims=(0, 5), ylims=(0, 100))

    #         vline!(p_m, [1.0], color=:red, linestyle=:dash, linewidth=1.5, label=false)
    #     else
    #         p_m = plot(title="Month = $m\n(no valid data)",
    #                 grid=false, xlims=(0, 5), ylims=(0, 100))
    #     end

    #     push!(p, p_m)
    # end

    # --- Save plots ---
    layout_grid = (ceil(Int, length(months) / 3), 3)
    plt = plot(p..., layout=layout_grid, size=(500*4, 450*3), bottom_margin = 10mm, left_margin = 10mm)
    output_file = PATH_output_png * "pbl_sonde2_vs_ceil_by_month.png"
    savefig(plt, output_file)
    println(output_file)
end


function pbl_all_methods()
    PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER6/output_txt/"
    PATH_output_png = "/home/ellai/test_arm_data/flux_calc/VER6/output_png/"

    # Read data
    file_pbl = PATH_output_txt * "pbl_aligned_with_lidar.txt"
    info_pbl = readdlm(file_pbl)

    day    = info_pbl[:, 1]
    month  = info_pbl[:, 2]
    year   = info_pbl[:, 3]
    time_h = info_pbl[:, 4]
    pbl_ceil   = info_pbl[:, 5]
    pbl_sonde1 = info_pbl[:, 6]
    pbl_sonde2 = info_pbl[:, 7]
    pbl_sonde3 = info_pbl[:, 8]
    pbl_sonde4 = info_pbl[:, 9]
    pbl_inv    = info_pbl[:, 10]




    for v in [pbl_ceil, pbl_sonde1, pbl_sonde2, pbl_sonde3, pbl_sonde4, pbl_inv]
        replace!(v, "missing" => missing)
    end

    # println("Missing points: ", count(ismissing, pbl_sonde2))
    # println("Missing points: ", count(ismissing, pbl_inv))

    # Filter daytime 
    # mask_daytime = (time_h .>= 9) .& (time_h .<= 12)
    # day    = day[mask_daytime]
    # month  = month[mask_daytime]
    # year   = year[mask_daytime]
    # time_h = time_h[mask_daytime]
    # pbl_ceil   = pbl_ceil[mask_daytime]
    # pbl_sonde1 = pbl_sonde1[mask_daytime]
    # pbl_sonde2 = pbl_sonde2[mask_daytime]
    # pbl_sonde3 = pbl_sonde3[mask_daytime]
    # pbl_sonde4 = pbl_sonde4[mask_daytime]
    # pbl_inv    = pbl_inv[mask_daytime]

    # Label map
    label_map = Dict(
        "pbl_ceil"      => "Ceil",
        "pbl_inv"       => "Temp Inv",
        "pbl_sonde1"    => "Heffter",
        "pbl_sonde2"    => "Liu-Liang",
        "pbl_sonde3"    => "Richardson1",
        "pbl_sonde4"    => "Richardson2"
    )

    # All datasets in a Dict for flexible access
    data_map = Dict(
        "pbl_ceil"   => pbl_ceil,
        "pbl_inv"    => pbl_inv,
        "pbl_sonde1" => pbl_sonde1,
        "pbl_sonde2" => pbl_sonde2,
        "pbl_sonde3" => pbl_sonde3,
        "pbl_sonde4" => pbl_sonde4
    )

    # Define the pairs you want to compare
    pairs = [
        ("pbl_sonde2",   "pbl_sonde1"),
        ("pbl_sonde2",   "pbl_sonde3"),
        ("pbl_sonde2",   "pbl_sonde4"),
        ("pbl_sonde2",   "pbl_ceil"),
        ("pbl_sonde2",   "pbl_inv")
    ]

    # Plot 
    p = []
    for (name_x, name_y) in pairs
        set_x = data_map[name_x]
        set_y = data_map[name_y]
        valid = .!(ismissing.(set_x) .| ismissing.(set_y))

        if any(valid)
            p_m = scatter(set_x[valid], set_y[valid],
                          xlabel=label_map[name_x],
                          ylabel=label_map[name_y],
                          legend=false,
                          markersize=4,
                          alpha=0.15,
                          color=:blue,
                          xlims=[0, 3000], ylims=[0, 3000])
            plot!(p_m, [0, 3000], [0, 3000],
                  color=:red, linestyle=:dash, linewidth=1.5, label=false)
            upper_line = [500, 3500]
            lower_line = [-500, 2500]
            plot!(p_m, [0, 3000], upper_line, fillrange=lower_line, fillalpha=0.2, fillcolor=:blue, linecolor=:blue, linestyle=:dash, lw=1.5, label="±30% band")
            plot!(p_m, [0, 3000], [500, 3500], color=:blue, lw=1.5, linestyle=:dash, label="+30%")
            plot!(p_m, [0, 3000], [-500, 2500], color=:blue, lw=1.5, linestyle=:dash, label="-30%")
        else
            p_m = plot(title="$(label_map[name_y]) vs $(label_map[name_x])\n(no valid data)",
                       grid=false, xlims=[0, 3000], ylims=[0, 3000])
        end
        push!(p, p_m)
    end

    # Combine and save
    layout_grid = (ceil(Int, length(pairs) / 3), 3)
    plt = plot(p..., layout=layout_grid, size=(500*length(pairs), 450*2),
               left_margin=15mm, bottom_margin=10mm)
    output_file = PATH_output_png * "pbl_aligned_with_lidar_filtered.png"
    savefig(plt, output_file)
    println(output_file)
    
    both_numeric = .!ismissing.(pbl_inv) .& .!ismissing.(pbl_sonde2)
    diff_ok = abs.(pbl_inv .- pbl_sonde2) .<= 500
    bad_diff = both_numeric .& .!diff_ok

    pbl_inv[bad_diff] .= missing
    pbl_sonde2[bad_diff] .= missing
    mask = trues(length(pbl_inv))

    day        = day[mask]
    month      = month[mask]
    year       = year[mask]
    time_h_sec = time_h[mask] .* 3600
    pbl_sonde2 = pbl_sonde2[mask]
    pbl_inv    = pbl_inv[mask]

    println("Total points: ", length(pbl_inv))
    println("Missing points: ", count(ismissing, pbl_inv))

    results = hcat(day, month, year, time_h_sec, pbl_sonde2, pbl_inv)
    output_file = PATH_output_txt * "pbl_aligned_with_lidar_filtered.txt"
    writedlm(output_file, results)
    println(output_file)
 
end


function plot_pbl_mean()
    PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER6/output_txt/"
    PATH_output_png = "/home/ellai/test_arm_data/flux_calc/VER6/output_png/"


    file_pbl_f = PATH_output_txt * "pbl_aligned_with_lidar_filtered.txt"
    info_pbl_f = readdlm(file_pbl_f)
    pbl_f   = info_pbl_f[:, 5]
    pbl_f = replace(pbl_f, "missing" => missing)

    # === Read data ===
    file_pbl = PATH_output_txt * "pbl_aligned_with_lidar.txt"
    info_pbl = readdlm(file_pbl)

    day    = info_pbl[:, 1]
    month  = info_pbl[:, 2]
    year   = info_pbl[:, 3]
    time_h = info_pbl[:, 4]
    pbl_ceil   = info_pbl[:, 5]
    pbl_sonde2 = info_pbl[:, 7]
    pbl_inv    = info_pbl[:, 10]

    # === Clean missing ===
    for v in [pbl_ceil, pbl_sonde2, pbl_inv]
        replace!(v, "missing" => missing)
    end

    # === Filter daytime (12–15h) ===
    # mask_daytime = (time_h .>= 12) .& (time_h .<= 15)
    # pbl_ceil   = pbl_ceil[mask_daytime]
    # pbl_sonde2 = pbl_sonde2[mask_daytime]
    # pbl_inv    = pbl_inv[mask_daytime]

    # === Combine into matrix ===
    data = hcat(pbl_ceil, pbl_inv, pbl_sonde2)
    labels = ["Ceil", "Inv", "Sonde"]

    n = size(data, 1)
    method1 = Array{Union{Missing, Float64}}(undef, n)
    method2 = Array{Union{Missing, Float64}}(undef, n)
    method3 = Array{Union{Missing, Float64}}(undef, n)

    # === Initialize per-method counts ===
    chosen_counts1 = Dict("Ceil"=>0, "Inv"=>0, "Sonde"=>0)
    chosen_counts2 = Dict("Ceil"=>0, "Inv"=>0, "Sonde"=>0)

    # === Loop through data points ===
    for i in 1:n
        vals = data[i, :]
    
        # extract numeric values only
        numeric_vals = collect(skipmissing(vals))
        k = length(numeric_vals)
    
        # === CASE 1: all missing ===
        if k == 0
            method1[i] = missing
            method2[i] = missing
            method3[i] = missing
            continue
        end
    
        # === CASE 2: only 1 value numeric ===
        if k == 1
            v = numeric_vals[1]
            method1[i] = v
            method2[i] = v
            method3[i] = v
            continue
        end
    
        # === CASE 3: exactly 2 numeric values ===
        if k == 2
            v1, v2 = numeric_vals
            if abs(v1 - v2) <= 500
                # keep both; return both as is
                method1[i] = mean([v1, v2])   # or = v1 or v2 — your choice
                method2[i] = mean([v1, v2])
                method3[i] = mean([v1, v2])
            else
                # too different → missing
                method1[i] = missing
                method2[i] = missing
                method3[i] = missing
            end
            continue
        end
    
        # === CASE 4: 3 numeric values → full logic ===
        vals3 = numeric_vals
    
        # Method 1 — closest to mean
        m = mean(vals3)
        diffs = abs.(vals3 .- m)
        idx1 = argmin(diffs)
        method1[i] = vals3[idx1]
        chosen_counts1[labels[idx1]] += 1
    
        # Method 2 — minimal total deviation
        total_diff = [sum(abs.(vals3 .- vals3[j])) for j in 1:3]
        idx2 = argmin(total_diff)
        method2[i] = vals3[idx2]
        chosen_counts2[labels[idx2]] += 1
    
        # Method 3 — median
        method3[i] = median(vals3)
    end

    # === Report per-method percentages ===
    total_valid1 = sum(.!(ismissing.(method1)))
    total_valid2 = sum(.!(ismissing.(method2)))

    println("\n=== Method 1: Closest to Mean ===")
    for (k,v) in chosen_counts1
        perc = round(v / total_valid1 * 100, digits=1)
        println("  $k: $perc%")
    end

    println("\n=== Method 2: Pairwise Agreement ===")
    for (k,v) in chosen_counts2
        perc = round(v / total_valid2 * 100, digits=1)
        println("  $k: $perc%")
    end
    
    
    colors = ColorSchemes.viridis[range(0, 1, length=6)]
    # === Plot histograms ===
    p1 = histogram(pbl_sonde2, bins=30, label = "Sonde (Liu-Liang)", xlabel="PBLH (m)", ylabel="Count", color=colors[2], alpha = 1)
    histogram!(p1, pbl_ceil, bins=30, label = "Ceil",  color=colors[3], alpha = 0.7)
    histogram!(p1, pbl_inv, bins=30, label = "Temp Inv", color=colors[4], alpha = 0.7)
    annotate!(p1, (700, 6900, text("a", :left, 18)))
    p2 = histogram(method1, bins=30, xlabel="PBLH (m)", ylabel="Count", color=colors[1], alpha = 0.5, label = "combined" )
    histogram!(p2, pbl_f, bins=30, label = "filtered", xlabel="PBLH (m)", ylabel="Count", color=colors[5], alpha = 0.5)
    annotate!(p2, (700, 5600, text("b", :left, 18)))

    # p5 = histogram(method2, bins=30, title="Method 2 (Pairwise Agreement)", xlabel="PBLH, m", ylabel="Count", color=:green)
    # p3 = histogram(method3, bins=30, title="Method 3 (Median)", xlabel="PBLH, m", ylabel="Count", color=:orange)
    plt = plot(p1, p2,  layout=(1, 2), size=(1500, 450), left_margin=10mm, bottom_margin=10mm)

    # plt = plot(p1, p2, p3, p4, p6,
    #            layout=(2, 3), size=(1400, 800),
    #            left_margin=10mm, bottom_margin=10mm)

    output_file = PATH_output_png * "pbl_aligned_with_lidar_combine.png"
    savefig(plt, output_file)
    println(output_file)

    println(length(method1)) 
    results1 = hcat(day, month, year, time_h.*3600, method1)
    # results1 = hcat(day, month, year, time_h, method1)

    output_file1 = PATH_output_txt * "pbl_aligned_with_lidar_combine.txt"
    writedlm(output_file1, results1)
    println(output_file1)
    
end




@everywhere function process_profile(day, month, year, time, info_rh, info_pbl)
    # skip if time is outside 12–15
    if time < 12 || time > 13
        return nothing
    end

    rh_day, rh_month, rh_year, rh_time = info_rh[:, 1], info_rh[:, 2], info_rh[:, 3], info_rh[:, 4]
    rh_height, rh_val = info_rh[:, 5], info_rh[:, 7]
    rh_val = replace(rh_val, "missing" => missing)
    rh_val = replace(rh_val, "" => missing)

    pbl_day, pbl_month, pbl_year, pbl_time, pbl_val =
        info_pbl[:, 1], info_pbl[:, 2], info_pbl[:, 3], info_pbl[:, 4], info_pbl[:, 5]
    pbl_val = replace(pbl_val, "missing" => missing)

    mask_rh  = (rh_day .== day)  .& (rh_month .== month) .& (rh_year .== year) .& (abs.(rh_time .- time) .<= 0.5)
    mask_pbl = (pbl_day .== day) .& (pbl_month .== month) .& (pbl_year .== year) .& (abs.(pbl_time .- time) .<= 0.5)

    if !any(mask_pbl)
        return nothing
    end

    pbl = pbl_val[mask_pbl][1]
    if ismissing(pbl) || pbl == 0
        return nothing
    end

    h = rh_height[mask_rh]
    t = rh_val[mask_rh]
    valid = .!ismissing.(t)
    h = h[valid]
    t = t[valid]

    isempty(h) && return nothing

    z_norm = h ./ pbl
    return (t, z_norm)
end



function filter_pbl()

    PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER6/output_txt/"
    PATH_output_png = "/home/ellai/test_arm_data/flux_calc/VER6/output_png/"

    # ============================
    # Load SONDE–LIDAR aligned file
    # ============================
    file_pbl = PATH_output_txt * "pbl_aligned_with_lidar.txt"
    info_pbl = readdlm(file_pbl)

    # ============================
    # Extract columns
    # ============================
    day    = info_pbl[:, 1]
    month  = info_pbl[:, 2]
    year   = info_pbl[:, 3]
    time_h_sec = info_pbl[:, 4]

    pbl_sonde2 = info_pbl[:, 7]
    pbl_sonde3 = info_pbl[:, 8]
    pbl_sonde4 = info_pbl[:, 9]
    pbl_inv    = info_pbl[:, 10]

    # Convert strings "missing" → missing
    for v in (pbl_sonde2, pbl_sonde3, pbl_sonde4, pbl_inv)
        replace!(v, "missing" => missing)
    end

    N = length(pbl_sonde2)

    # ============================
    # FIX: allow Float64 + missing
    # ============================
    final_pbl = Vector{Union{Missing,Float64}}(missing, N)
    keep      = falses(N)

    # =======================================
    # APPLY ALL LOGIC
    # =======================================
    for i in 1:N

        p2 = pbl_sonde2[i]
        p3 = pbl_sonde3[i]
        p4 = pbl_sonde4[i]
        pi = pbl_inv[i]

        # Rule 1 — If pbl_sonde2 missing → drop
        if ismissing(p2)
            continue
        end

        # Rule 2 — If inversion missing → compare p2 with p3/p4
        if ismissing(pi)
            ok3 = (!ismissing(p3) && abs(p2 - p3) ≤ 500)
            ok4 = (!ismissing(p4) && abs(p2 - p4) ≤ 500)

            if ok3 || ok4
                keep[i] = true
                final_pbl[i] = p2
            end

            continue
        end

        # Rule 3a — p2 close to inversion
        if abs(p2 - pi) ≤ 500
            keep[i] = true
            final_pbl[i] = p2
            continue
        end

        # Rule 3b — check other sonde-derived heights
        ok3 = (!ismissing(p3) && abs(p3 - pi) ≤ 500)
        ok4 = (!ismissing(p4) && abs(p4 - pi) ≤ 500)

        if ok3
            keep[i] = true
            final_pbl[i] = p3
        elseif ok4
            keep[i] = true
            final_pbl[i] = p4
        end
    end


    results = hcat(
        day, month, year,
        time_h_sec,
        final_pbl
    )

    println("Total points: ", length(final_pbl))
    println("Missing points: ", count(ismissing, final_pbl))


    output_file = PATH_output_txt * "pbl_aligned_with_lidar_filtered.txt"
    writedlm(output_file, results)
    println(output_file)

end






# using DelimitedFiles, Plots, Measures

# function plot_normalized_profiles_parallel()
#     PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER6/output_txt/"
#     PATH_png = "/home/ellai/test_arm_data/flux_calc/VER6/output_png/"

#     info_rh       = readdlm(PATH_output_txt * "rh_aligned_with_lidar.txt")
#     info_pbl_thl  = readdlm(PATH_output_txt * "pbl_temp_inversion.txt")
#     info_pbl_LL   = readdlm(PATH_output_txt * "pbl_filtered.txt")
#     info_pbl_comb = readdlm(PATH_output_txt * "pbl_method1.txt")

#     combos = unique([(info_rh[i,1], info_rh[i,2], info_rh[i,3], info_rh[i,4]) 
#                      for i in 1:size(info_rh,1)])
    
#     # --- one-line helper ---
#     run_method(info_pbl) = filter(!isnothing, pmap(c ->
#         process_profile(c[1], c[2], c[3], c[4], info_rh, info_pbl), combos))

#     results = [
#         run_method(info_pbl_thl),
#         run_method(info_pbl_LL),
#         run_method(info_pbl_comb)
#     ]
#     println("efef", size(results))

#     labels = [L"z / PBL_{\theta}", L"z / PBL_{LL}", L"z / PBL_{comb}"]

#     # --- one-line creation of 3 subplots ---
#     subplots = [plot(xlabel=L"θ (K)", ylabel=labels[i], legend=false, ylims=(0,1.3)) for i=1:3]

#     # populate plots
#     for i in 1:3
#         println(i)
#         for (t, z) in results[i]
#             scatter!(subplots[i], t, z; color=:gray, markersize=1, alpha=0.02)
#             # println(i, " ", t, " ", z)
#         end
#     end

#     # --- one-line combined plot ---
#     plt = plot(subplots..., layout=(1,3), size=(1400,450), left_margin=10mm, bottom_margin=10mm)

#     savefig(plt, PATH_png * "pbl_aligned_with_lidar_combine.png")
#     println(PATH_png * "pbl_aligned_with_lidar_combine.png")
#     # --- one-line hcat for output ---
#     # data_out = hcat([(vcat([r[j] for r in results[i]]...)) for i in 1:3, j in 1:2]...)
#     all_t1 = vcat([r[1] for r in results[1]]...)
#     all_z1 = vcat([r[2] for r in results[1]]...)
#     data_out1 = hcat(all_t1, all_z1)
#     output_file1 = PATH_output_txt * "normalized_temp_profiles_12to15_temp.txt"
#     writedlm(output_file1, data_out1)
#     println(output_file1)

#     all_t2 = vcat([r[1] for r in results[2]]...)
#     all_z2 = vcat([r[2] for r in results[2]]...)
#     data_out2 = hcat(all_t2, all_z2)
#     output_file2 = PATH_output_txt * "normalized_temp_profiles_12to15_LL.txt"
#     writedlm(output_file2, data_out2)
#     println(output_file2)

#     all_t3 = vcat([r[1] for r in results[3]]...)
#     all_z3 = vcat([r[2] for r in results[3]]...)
#     data_out3 = hcat(all_t3, all_z3)
#     output_file3 = PATH_output_txt * "normalized_temp_profiles_12to15_comb.txt"
#     writedlm(output_file3, data_out3)
#     println(output_file3)

# end




# main()
# filter_pbl()

# pbl_all_methods()
plot_pbl_mean()

# plot_pbl_months()



