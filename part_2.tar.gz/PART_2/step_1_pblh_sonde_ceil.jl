using Glob  # for globbing the file patterns
using CSV   # for reading CSV files
using Plots # for plotting
using Colors # for color normalization
using NCDatasets # for NetCDF
using Dates  # to convert dates in sec
using Statistics # for mean
using Dierckx     # For detrend (spline interpolation)
using Polynomials
using StatsBase 
using DSP  # Import DSP package
using DelimitedFiles
using NetCDF


const PATH_folder_sonde_interp = "/home/ellai/data/archive/DOE-SC0021074 (Tracer)/level 1/houinterpolatedsondeM1/"
const PATH_folder_sonde = "/home/ellai/data/archive/DOE-SC0021074 (Tracer)/level 1/houpblhtsonde1mcfarlM1/"
const PATH_folder_CEIL = "/home/ellai/data/archive/DOE-SC0021074 (Tracer)/level 1/houceilpblhtM1.a0/"
const PATH_output_png = "/home/ellai/test_arm_data/flux_calc/VER6/output_png/"
const PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER6/output_txt/"

const time_gap = 3 * 3600 # sec 
const time_zone = -5


# from dataset format to seconds
function from_datetime_to_sec(set_time, day_in, month_in, year_in)
    time_sec = hour.(set_time) .* 3600 .+ minute.(set_time) .* 60 .+ second.(set_time) 
    
    base_datetime = DateTime(year_in, month_in, day_in)
    total_time_dt = base_datetime .+ Second.(time_sec)
    dt_local = total_time_dt .+ Hour(time_zone)

    true_year = year.(dt_local)
    true_month = month.(dt_local)
    true_day = day.(dt_local)

    true_time_sec = Dates.value.(dt_local .- DateTime.(true_year, true_month, true_day)) ./ 1000

    return true_time_sec, true_day, true_month, true_year
end

function read_ceil_data(PATH_file, num_day, month, year)
    dataset = NCDataset(PATH_file, "r")
    init_day = parse(Int, num_day)
    init_month = parse(Int, month)
    init_year = parse(Int, year)
   
    # variable_names = keys(dataset)
    # println("Variables in the dataset: ", variable_names)
    # println(size(dataset["bl_height_1"][:]))
    # sleep(100)

    try 
        # pbl1 = dataset["pbl_height_heffter"][:] # ONE VALUE PER FILE!!!
        pbl1 = dataset["bl_height_1"]
        # pbl2 = dataset["pbl_height_liu_liang"][:]
        time_in_datetime = dataset["time"] # + num_day + time_zone * 3600 # sec

        time_in_sec, day, month, year =  from_datetime_to_sec(time_in_datetime, init_day, init_month, init_year)
        # --- convert to hours ---
        time_in_hr = time_in_sec ./ 3600

        # --- bin averaging every 1 hour ---
        bins = floor.(time_in_hr)  # integer hour bins
        unique_bins = sort(unique(bins))

        ave_time = Float64[]
        ave_pbl  = Float64[]
        ave_day  = Int[]
        ave_month = Int[]
        ave_year  = Int[]

        for b in unique_bins
            mask = bins .== b
            vals = pbl1[mask]
            push!(ave_time, b * 3600)  # convert back to seconds
            push!(ave_pbl, mean(skipmissing(vals)))
            push!(ave_day, day[findfirst(mask)])
            push!(ave_month, month[findfirst(mask)])
            push!(ave_year, year[findfirst(mask)])
        end

        return [ave_day, ave_month, ave_year, ave_time, ave_pbl]
             
    finally 
        close(dataset)
    end
end


function read_sonde_data(PATH_file, num_day, month, year)
    dataset = NCDataset(PATH_file, "r")
    init_day = parse(Int, num_day)
    init_month = parse(Int, month)
    init_year = parse(Int, year)
   
    # variable_names = keys(dataset)
    # println("Variables in the dataset: ", variable_names)
    # println(size(dataset["bl_height_1"][:]))
    # sleep(100)

    try 
        pbl1 = dataset["pbl_height_heffter"][1] # ONE VALUE PER FILE!!!
        pbl2 = dataset["pbl_height_liu_liang"][:]
        pbl3 = dataset["pbl_height_bulk_richardson_pt25"][:]
        pbl4 = dataset["pbl_height_bulk_richardson_pt5"][:]

        time_in_datetime = dataset["time"] # + num_day + time_zone * 3600 # sec

        time_in_sec, day, month, year =  from_datetime_to_sec(time_in_datetime, init_day, init_month, init_year)
        time_in_hr = time_in_sec ./ 3600

        # --- bin averaging every 1 hour ---
        bins = floor.(time_in_hr)  # integer hour bins
        unique_bins = sort(unique(bins))

        ave_time = Float64[]
        ave_pbl1, ave_pbl2,ave_pbl3,ave_pbl4  = [],[],[],[]
        ave_day  = Int[]
        ave_month = Int[]
        ave_year  = Int[]
        
        for b in unique_bins
            mask = bins .== b

            push!(ave_time, b * 3600)  # convert back to seconds
            push!(ave_pbl1, pbl1)
            push!(ave_pbl2, pbl2[1])
            push!(ave_pbl3, pbl3[1])
            push!(ave_pbl4, pbl4[1])

            push!(ave_day, day[findfirst(mask)])
            push!(ave_month, month[findfirst(mask)])
            push!(ave_year, year[findfirst(mask)])
        end

        return [ave_day, ave_month, ave_year, ave_time, ave_pbl1, ave_pbl2, ave_pbl3, ave_pbl4 ]
             
    finally 
        close(dataset)
    end
end



# function read_sonde_interp_data(PATH_file, num_day, month, year)
#     dataset = NCDataset(PATH_file, "r")
#     init_day = parse(Int, num_day)
#     init_month = parse(Int, month)
#     init_year = parse(Int, year)
   
#     # variable_names = keys(dataset)
#     # println("Variables in the dataset: ", variable_names)
#     # println(dataset["height"][:])
#     # # println(dataset["time"][:])

#     # sleep(100)

#     try 
#         pbl1 = dataset["pbl_height_heffter"][1] # ONE VALUE PER FILE!!!
#         pbl2 = dataset["pbl_height_liu_liang"][:]
#         pbl3 = dataset["pbl_height_bulk_richardson_pt25"][:]
#         pbl4 = dataset["pbl_height_bulk_richardson_pt5"][:]

#         time_in_datetime = dataset["time"] # + num_day + time_zone * 3600 # sec

#         time_in_sec, day, month, year =  from_datetime_to_sec(time_in_datetime, init_day, init_month, init_year)
#         time_in_hr = time_in_sec ./ 3600

#         # --- bin averaging every 1 hour ---
#         bins = floor.(time_in_hr)  # integer hour bins
#         unique_bins = sort(unique(bins))

#         ave_time = Float64[]
#         ave_pbl1, ave_pbl2,ave_pbl3,ave_pbl4  = [],[],[],[]
#         ave_day  = Int[]
#         ave_month = Int[]
#         ave_year  = Int[]
        
#         for b in unique_bins
#             mask = bins .== b

#             push!(ave_time, b * 3600)  # convert back to seconds
#             push!(ave_pbl1, pbl1)
#             push!(ave_pbl2, pbl2[1])
#             push!(ave_pbl3, pbl3[1])
#             push!(ave_pbl4, pbl4[1])

#             push!(ave_day, day[findfirst(mask)])
#             push!(ave_month, month[findfirst(mask)])
#             push!(ave_year, year[findfirst(mask)])
#         end

#         return [ave_day, ave_month, ave_year, ave_time, ave_pbl1, ave_pbl2, ave_pbl3, ave_pbl4 ]
             
#     finally 
#         close(dataset)
#     end
# end


function pbl_ceil()
    set_files = filter(x -> endswith(x, ".nc"), readdir(PATH_folder_CEIL))
    println("there are ", length(set_files), " in your folder")
    info_all_files = []
    for file in set_files
        file_parts = split(basename(file), ".")
        day = file_parts[3][7:8]
        month = file_parts[3][5:6]
        year = file_parts[3][1:4]
        println(file_parts," ",  day,  " ", month ," ", year)
        file_new = PATH_folder_CEIL*file
        pbl_one_file  = read_ceil_data(file_new, day, month, year)
        for i in  1:length(pbl_one_file[1])
            info  = [pbl_one_file[1][i], pbl_one_file[2][i], pbl_one_file[3][i], pbl_one_file[4][i], pbl_one_file[5][i]]
            push!(info_all_files, info)
        end
    end 

    output_file_name = "pbl_ceil.txt"
    output_file = PATH_output_txt * output_file_name 
    writedlm(output_file, info_all_files)  
    println(output_file)
end


function pbl_sonde()
    set_files = filter(x -> endswith(x, ".cdf"), readdir(PATH_folder_sonde))
    println("there are ", length(set_files), " in your folder")
    info_all_files = []
    for file in set_files
        file_parts = split(basename(file), ".")
        day = file_parts[3][7:8]
        month = file_parts[3][5:6]
        year = file_parts[3][1:4]
        println(file_parts," ",  day,  " ", month ," ", year)
        file_new = PATH_folder_sonde*file
        pbl_one_file  = read_sonde_data(file_new, day, month, year)
        for i in  1:length(pbl_one_file[1])
            info  = [pbl_one_file[1][i], pbl_one_file[2][i], pbl_one_file[3][i], pbl_one_file[4][i], pbl_one_file[5][i], pbl_one_file[6][i], pbl_one_file[7][i], pbl_one_file[8][i]]
            push!(info_all_files, info)
        end
    end 
    

    output_file_name = "pbl_sonde.txt"
    output_file = PATH_output_txt * output_file_name 
    writedlm(output_file, info_all_files)  
    println(output_file)
end

# function pbl_sonde_interp()
#     set_files = filter(x -> endswith(x, ".nc"), readdir(PATH_folder_sonde_interp))
#     println("there are ", length(set_files), " in your folder")
#     info_all_files = []
#     for file in set_files
#         file_parts = split(basename(file), ".")
#         day = file_parts[3][7:8]
#         month = file_parts[3][5:6]
#         year = file_parts[3][1:4]
#         println(file_parts," ",  day,  " ", month ," ", year)
#         file_new = PATH_folder_sonde_interp*file
#         pbl_one_file  = read_sonde_interp_data(file_new, day, month, year)
#         for i in  1:length(pbl_one_file[1])
#             info  = [pbl_one_file[1][i], pbl_one_file[2][i], pbl_one_file[3][i], pbl_one_file[4][i], pbl_one_file[5][i], pbl_one_file[6][i], pbl_one_file[7][i], pbl_one_file[8][i]]
#             push!(info_all_files, info)
#         end
#     end 
    

#     output_file_name = "pbl_sonde_interp.txt"
#     output_file = PATH_output_txt * output_file_name 
#     writedlm(output_file, info_all_files)  
#     println(output_file)
# end



pbl_ceil()
pbl_sonde()

