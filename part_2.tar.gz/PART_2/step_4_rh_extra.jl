using Glob  # for globbing the file patterns
using CSV   # for reading CSV files
using Plots # for plotting
using Colors # for color normalization
using NCDatasets # for NetCDF
using Dates  # to convert dates in sec
using Statistics # for mean
using Dierckx     # For detrend (spline interpolation)
using Polynomials
using StatsBase 
using DSP  # Import DSP package
using DelimitedFiles
using NetCDF
using Measures
using DataFrames
using Distributed

addprocs(64)
# @everywhere include("/home/ellai/test_arm_data/flux_calc/VER4/step_3_calc_flux_ll.jl")

# atexit(() -> rmprocs(workers()))

@everywhere using NCDatasets, Statistics, Interpolations, LsqFit, Dates, Polynomials
@everywhere using Glob, DelimitedFiles

@everywhere function one_month(info_time_lidar, info_stab, info_pbl, info_clouds, info_precip, info_rh, time_in, time_out, month_flag, stability_flag, condition_flag)
    time_in = time_in * 3600
    time_out = time_out * 3600 

    println("------", month_flag)
    l_day = info_time_lidar[:, 1]
    l_month = info_time_lidar[:, 2]
    l_year = info_time_lidar[:, 3]
    l_time = info_time_lidar[:, 4]  # sec 


    stab_day = info_stab[:, 1]
    stab_month = info_stab[:, 2]
    stab_year = info_stab[:, 3]
    stab_time = info_stab[:, 4] # sec 
    stab_val = info_stab[:, 5]
    stab_val = replace(stab_val, "missing" => missing)

    pbl_day = info_pbl[:, 1]
    pbl_month = info_pbl[:, 2]
    pbl_year = info_pbl[:, 3]
    pbl_time = info_pbl[:, 4] # sec
    pbl_val = info_pbl[:, 5]
    pbl_val = replace(pbl_val, "missing" => missing)


    cld_day = info_clouds[:, 1]
    cld_month = info_clouds[:, 2]
    cld_year = info_clouds[:, 3]
    cld_time = info_clouds[:, 4] # sec
    cld_val = info_clouds[:, 5]
    cld_val = replace(cld_val, "missing" => missing)

    prcpt_day = info_precip[:, 1]
    prcpt_month = info_precip[:, 2]
    prcpt_year = info_precip[:, 3]
    prcpt_time = info_precip[:, 4] # sec
    prcpt_val = info_precip[:, 5]
    prcpt_val = replace(prcpt_val, "missing" => missing)
    
    
    rh_day = info_rh[:, 1]
    rh_month = info_rh[:, 2]
    rh_year = info_rh[:, 3]
    rh_time = info_rh[:, 4] .* 3600 # sec
    rh_height = info_rh[:, 5]
    rh_val = info_rh[:, 6]
    rh_val = replace(rh_val, "missing" => missing)
    rh_temp = info_rh[:, 7]
    rh_temp = replace(rh_temp, "missing" => missing)

    # println(size(cld_day))
    # println(size(pbl_day))
    # println(size(stab_day))
    # println(size(l_day))
    # println(size(prcpt_day))
    # sleep(100)
    println("total amount of profiles: ", length(l_time))
    if month_flag[1] == true 
        mask_time  = (l_time .>= time_in) .& (l_time .<= time_out) .& (l_month .== month_flag[2]) .& (l_year .== month_flag[3])
    else
        mask_time  = (l_time .>= time_in) .& (l_time .<= time_out) 
    end

    l_day = l_day[mask_time]
    l_month = l_month[mask_time]
    l_year = l_year[mask_time]
    l_time = l_time[mask_time]  
    println("for ", time_in/3600, "-", time_out/3600, " time range: ", length(l_time))
    N_total = length(l_time)


    # STABILITY
    ind_l_time_after_zl = []
    set_stblt = []
    for t in 1:length(l_time)
        mask = (l_day[t] .== stab_day) .& (l_month[t] .== stab_month) .& (l_year[t] .== stab_year) .& (l_time[t] .== stab_time) 
        stab_time_new = stab_time[mask]
        stab_val_new = stab_val[mask]
        if length(stab_time_new) != 0  && !ismissing(stab_val_new[1])
            if stability_flag == "neutral"
                if abs(stab_val_new[1]) <= 0.2
                    push!(ind_l_time_after_zl, t)
                    push!(set_stblt, stab_val_new[1])
                end   
            elseif  stability_flag == "unstable"
                if stab_val_new[1] < -0.2
                    push!(ind_l_time_after_zl, t)
                    push!(set_stblt, stab_val_new[1])
                end  
            elseif  stability_flag == "stable"
                if stab_val_new[1] > 0.2
                    push!(ind_l_time_after_zl, t)
                    push!(set_stblt, stab_val_new[1])
                end  
            end    
        end
    end

    l_day = l_day[ind_l_time_after_zl]
    l_month = l_month[ind_l_time_after_zl]
    l_year = l_year[ind_l_time_after_zl]
    l_time = l_time[ind_l_time_after_zl]
    println("after stability-filter: ", length(l_time), " ", length(set_stblt))
    N_zl = length(l_time)
    
    # PBL H 
    pbl_for_lidar = []
    for t in 1:length(l_time)
        mask = (l_day[t] .== pbl_day) .& (l_month[t] .== pbl_month) .& (l_year[t] .== pbl_year) .& (l_time[t] .== pbl_time)
        pbl_time_new = pbl_time[mask]
        pbl_val_new = pbl_val[mask]

        if length(pbl_time_new) != 0  && !ismissing(pbl_val_new[1])
            # diff_hours = abs.(pbl_time_new .- (l_time[t]))  
            # min_diff, min_idx = findmin(diff_hours)
            # if min_diff <= 3  # within ±1 hour
            push!(pbl_for_lidar, pbl_val_new[1])         
            # else 
                # push!(pbl_for_lidar, missing)         
            # end
        else
            push!(pbl_for_lidar, missing)             
        end
    end

    # pbl_for_lidar = replace(pbl_for_lidar, "missing" => missing)
    # missing_count = count(x -> ismissing(x) || x == "missing", pbl_for_lidar)
    # println("amount of missing for pbl: ", missing_count)

    # unique_days = unique(zip(l_year, l_month, l_day))
    # println("Number of unique days: ", length(unique_days))
  
    # CLOUDS
    ind_l_time_after_cld = []
    set_cld_h = []
    set_pbl_h = []
    for t in 1:length(l_time)
        mask = (l_day[t] .== cld_day) .& (l_month[t] .== cld_month) .& (l_year[t] .== cld_year).& (l_time[t] .== cld_time)
        cld_time_new = cld_time[mask]
        cld_val_new = cld_val[mask]
        pbl_t = pbl_for_lidar[t]
        if length(cld_time_new) != 0  && !ismissing(cld_val_new[1])
            if condition_flag == "clean"
                if !(ismissing(pbl_t)) && cld_val_new[1] != "missing" 
                    if cld_val_new[1] > pbl_t
                        push!(ind_l_time_after_cld, t)
                        push!(set_cld_h, cld_val_new[1])
                        push!(set_pbl_h, pbl_t)
                    end
                end 
            elseif condition_flag == "nonclean"
                if !(ismissing(pbl_t)) && cld_val_new[1] != "missing" 
                    if cld_val_new[1] > 100  && cld_val_new[1] < pbl_t
                        push!(ind_l_time_after_cld, t)
                        push!(set_cld_h, cld_val_new[1])
                        push!(set_pbl_h, pbl_t)
                    end 
                end
            end 
        end 
    end
    l_day = l_day[ind_l_time_after_cld]
    l_month = l_month[ind_l_time_after_cld]
    l_year = l_year[ind_l_time_after_cld]
    l_time = l_time[ind_l_time_after_cld]
    set_stblt = set_stblt[ind_l_time_after_cld]
    println("after cloud-filter: ", length(l_time), " ", length(set_stblt), " ", length(set_cld_h))
    N_clouds = length(l_day)

    # PRECIPITATION
    ind_l_time_after_prcpt = []
    for t in 1:length(l_time)
        mask = (l_day[t] .== prcpt_day) .& (l_month[t] .== prcpt_month) .& (l_year[t] .== prcpt_year).& (l_time[t] .== prcpt_time)
        prcpt_time_new = prcpt_time[mask]
        prcpt_val_new = prcpt_val[mask]
        if length(prcpt_time_new)!= 0 &&  !ismissing(prcpt_val_new[1])
            # diff_hours = abs.(prcpt_time_new .- (l_time[t]))  
            # min_diff, min_idx = findmin(diff_hours)
            # if min_diff <= 1  # within ±1 hour
                # println(min_diff)
                # println(min_idx)
            if prcpt_val_new[1] == 0
                push!(ind_l_time_after_prcpt, t)
            end
        end 
    end

    l_day = l_day[ind_l_time_after_prcpt]
    l_month = l_month[ind_l_time_after_prcpt]
    l_year = l_year[ind_l_time_after_prcpt]
    l_time = l_time[ind_l_time_after_prcpt]
    set_stblt = set_stblt[ind_l_time_after_prcpt]
    set_cld_h = set_cld_h[ind_l_time_after_prcpt]
    set_pbl_h = set_pbl_h[ind_l_time_after_prcpt]
    println("after precipitation-filter: ", length(l_time))
    N_prcpt = length(l_day)
    
    set_pbl_h = ifelse.(ismissing.(set_pbl_h), set_cld_h, set_pbl_h) # if no plh , replace for clouds level . 

    # RH 
    ind_l_time_after_rh = []
    set_rh_h, set_temp_t =  [], []
    for t in 1:length(l_time)
        mask = (l_day[t] .== rh_day) .& (l_month[t] .== rh_month) .& (l_year[t] .== rh_year).& (l_time[t] .== rh_time)
        original_inds = findall(mask)  
        rh_time_new = rh_time[original_inds]
        rh_val_new = rh_val[original_inds]
        rh_height_new = rh_height[original_inds]

        if !ismissing(set_pbl_h[t])
            pbl_t = set_pbl_h[t]
        else 
            pbl_t = NaN
        end
         
        # everything below pbl
        mask_h = (pbl_t .>= rh_height_new) 
        rh_height_new = rh_height_new[mask_h]
        rh_val_new = rh_val_new[mask_h]
        rh_time_new = rh_time_new[mask_h]
        original_inds = original_inds[mask_h]  # update indices after filtering

        # amount_of_data_1 = length(rh_height_new)
         
        # minimum hight with rh = 90
        inds = findall(x -> x >= 90, rh_val_new)
        if length(inds) != 0
            min_h = minimum(rh_height_new[inds])
        else
            min_h = pbl_t
        end 
        
        if condition_flag == "clean"
            if min_h >= pbl_t
                mask_h2 = (min_h .>= rh_height_new) 
                rh_height_new = rh_height_new[mask_h2]
                rh_val_new = rh_val_new[mask_h2]
                rh_time_new = rh_time_new[mask_h2]
                original_inds = original_inds[mask_h2]  # final filtered indices
                push!(ind_l_time_after_rh, t)
                push!(set_rh_h, min_h)
            end 
        elseif condition_flag == "nonclean"
            # if pbl_t != NaN
            # if min_h <= pbl_t
            #     continue
            # else 
            #     println("AAAAAAAAAAAAAAAA, ", min_h , " ", pbl_t)
            #     sleep(10)
            # end
            if min_h <= pbl_t
                mask_h2 = (min_h .>= rh_height_new) 
                rh_height_new = rh_height_new[mask_h2]
                rh_val_new = rh_val_new[mask_h2]
                rh_time_new = rh_time_new[mask_h2]
                original_inds = original_inds[mask_h2]  # final filtered indices
                push!(ind_l_time_after_rh, t)
                push!(set_rh_h, min_h) 
            end 
        end 


        # mask_h2 = (min_h .>= rh_height_new) 
        # rh_height_new = rh_height_new[mask_h2]
        # rh_val_new = rh_val_new[mask_h2]
        # rh_time_new = rh_time_new[mask_h2]
        # original_inds = original_inds[mask_h2]  # final filtered indices
        # push!(ind_l_time_after_rh, t)
        # push!(set_rh_h, min_h)

        # amount_of_data_2 = length(rh_height_new)

        #
        # mask_rh = (90 .>= rh_val_new)
        # rh_height_new = rh_height_new[mask_rh]
        # rh_val_new = rh_val_new[mask_rh]
        # rh_time_new = rh_time_new[mask_rh]

        # percent_of_clean_data = amount_of_data_2/amount_of_data_1*100
        
        # if  percent_of_clean_data > 50 && min_h >= pbl_t/2  # cutting all bad profiles 
        #     min_h_2 = minimum(rh_height_new) 
        #     if condition_flag == "clean"
        #         if min_h >= pbl_t
        #             push!(ind_l_time_after_rh, t)
        #             push!(set_rh_h, pbl_t)
        #         end
        #     elseif condition_flag == "nonclean"
        #         push!(ind_l_time_after_rh, t)
        #         push!(set_rh_h, min_h_2)
        #     end 
        # end         
    end
    
    println("MINIMUM ", set_rh_h)
    l_day = l_day[ind_l_time_after_rh]
    l_month = l_month[ind_l_time_after_rh]
    l_year = l_year[ind_l_time_after_rh]
    l_time = l_time[ind_l_time_after_rh]
    set_stblt = set_stblt[ind_l_time_after_rh]
    set_cld_h = set_cld_h[ind_l_time_after_rh]
    set_pbl_h = set_pbl_h[ind_l_time_after_rh]
    # set_rh_h
    println("after rh-filter: ", length(l_time))
    N_rh = length(l_day)

    # println(length(l_time), length(set_stblt))
    # println(length(l_day), length(l_month), length(l_year),  length(l_time))
    # println(length(set_pbl_h), length(set_cld_h), length(set_stblt),  length(set_rh_h))

    return N_total, N_zl, N_clouds, N_prcpt, N_rh, [l_day, l_month, l_year, l_time, set_pbl_h, set_cld_h, set_stblt, set_rh_h]
end


@everywhere function compute_one_month(d, info_time_lidar, info_stab, info_pbl, info_clouds, info_precip, info_rh, stability_flag, condition_flag)
    month_flag = [true, month(d), year(d)]
    true_time, true_N1, true_N2, true_N3, true_N4, true_N5 = Float64[], Float64[], Float64[], Float64[], Float64[], Float64[]
    filtered_time_lidar = (Int[], Int[], Int[], Int[], Float64[], Union{Missing, Float64}[], Union{Missing, Float64}[], Union{Missing, Float64}[])

    for t in 0:1.0:23.0
        N1, N2, N3, N4, N5, time_info = one_month(info_time_lidar, info_stab, info_pbl, info_clouds, info_precip, info_rh, t, t + 1.0, month_flag, stability_flag, condition_flag)
        push!(true_time, t)
        push!(true_N1, N1)
        push!(true_N2, N2)
        push!(true_N3, N3)
        push!(true_N4, N4)
        push!(true_N5, N5)
        for j in 1:length(time_info)
            append!(filtered_time_lidar[j], time_info[j])
        end
    end
    return (d, true_time, true_N1, true_N2, true_N3, true_N4, true_N5, filtered_time_lidar)
end


function main(stability_flag, condition_flag)
    PATH_output_png = "/home/ellai/test_arm_data/flux_calc/VER6/output_png/"
    PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER6/output_txt/"


    file_time_lidar = PATH_output_txt * "time_lidar.txt"
    info_time_lidar = readdlm(file_time_lidar)

    file_stab = PATH_output_txt * "stb_aligned_with_lidar.txt" # every 30 nim 
    info_stab = readdlm(file_stab)

    file_pbl = PATH_output_txt * "pbl_aligned_with_lidar_filtered.txt"
    info_pbl = readdlm(file_pbl)

    file_clouds = PATH_output_txt * "clouds_aligned_with_lidar_dl.txt" 
    info_clouds = readdlm(file_clouds)

    file_precip = PATH_output_txt * "prc_aligned_with_lidar.txt" # does not depend on hight 
    info_precip = readdlm(file_precip)

    file_rh = PATH_output_txt * "rh_aligned_with_lidar.txt"
    info_rh = readdlm(file_rh)



    # Time range: Sep 2021 to Sep 2022
    start_date = Date(2021, 8, 1)
    end_date = Date(2022, 10, 1)
    # start_date = Date(2022, 2, 1)
    # end_date = Date(2022, 3, 1)
    months_all = collect(start_date:Month(1):end_date)

    ncols = 4
    nrows = cld(length(months_all), ncols)
    plt = plot(layout=(nrows, ncols), size=(1200, 300 * nrows))
    filtered_time_lidar = (Int[], Int[], Int[], Int[],  Float64[], Union{Missing, Float64}[], Union{Missing, Float64}[], Union{Missing, Float64}[])

    total_N1 = 0.0
    total_N2 = 0.0 
    total_N3 = 0.0 
    total_N4 = 0.0 
    total_N5 = 0.0 

    results = pmap(d -> compute_one_month(d, info_time_lidar, info_stab, info_pbl, info_clouds, info_precip, info_rh, stability_flag, condition_flag), months_all)

    for (i, (d, true_time, true_N1, true_N2, true_N3, true_N4, true_N5, time_info)) in enumerate(results)
        total_N1 += sum(true_N1)
        total_N2 += sum(true_N2)
        total_N3 += sum(true_N3)
        total_N4 += sum(true_N4)
        total_N5 += sum(true_N5)

        bar!(plt, true_time, true_N1, bar_width=0.9, alpha=0.2, label="Total", color=:green, subplot=i, ylim=(0, 150))
        bar!(plt, true_time, true_N2, bar_width=0.6, alpha=0.5, label="ZL", color=:purple, subplot=i, ylim=(0, 150))
        bar!(plt, true_time, true_N3, bar_width=0.3, alpha=0.8, label="Clouds", color=:blue, subplot=i, ylim=(0, 150))
        bar!(plt, true_time, true_N5, bar_width=0.3, alpha=1.0, label="Precipitation+RH", color=:red, subplot=i, ylim=(0, 150))

        title!(plt[i], "$(month(d))/$(year(d))")
        xlabel!(plt[i], "Time (h)")
        ylabel!(plt[i], "N")

        for j in 1:length(filtered_time_lidar)
            append!(filtered_time_lidar[j], time_info[j])
        end
    end

    println("total: ", total_N1, " after zl: ", total_N2, " after clouds: ", total_N3,  " after perc: ", total_N4,  " after rh: ", total_N5)
    println(round(total_N1/total_N1*100, digits=1), " ", round(total_N2/total_N1*100, digits=1), " ", round(total_N3/total_N1*100, digits=1), " ", round(total_N4/total_N1*100, digits=1), " ", round(total_N5/total_N1*100, digits=1))

    data = hcat(filtered_time_lidar...)
    writedlm(PATH_output_txt * "filtered_time_lidar_"* stability_flag*"_"*condition_flag*".txt", data)
    savefig(PATH_output_png * "monthly_time_vs_N_panel_"* stability_flag*"_"*condition_flag*".png")

    # for (i, d) in enumerate(months_all)
    #     month_flag = [true, month(d), year(d)]

    #     true_time, true_N1, true_N2, true_N3, true_N4, true_N5 = Float64[], Float64[], Float64[], Float64[], Float64[], Float64[]

    #     for t in 0:1.0:23.0
    #         in = t
    #         out = t + 1.0
    #         N1, N2, N3, N4, N5, time_info = one_month(info_time_lidar, info_stab, info_pbl, info_clouds, info_precip, info_rh, in, out, month_flag, stability_flag, condition_flag)
    #         push!(true_time, t)
    #         push!(true_N1, N1)
    #         push!(true_N2, N2)
    #         push!(true_N3, N3)
    #         push!(true_N4, N4)
    #         push!(true_N5, N5)
    #         # println(size(time_info))
    #         for j in 1:length(time_info)
    #             # println(time_info[j])
    #             # println(time_info[j])
    #             # println(j, " ", size(filtered_time_lidar[j]))
    #             # println(j, " ", size(time_info[j]), " ", time_info[j])
    #             append!(filtered_time_lidar[j], time_info[j])
    #         end 
    #     end
    #     total_N1 += sum(true_N1)
    #     total_N2 += sum(true_N2)
    #     total_N3 += sum(true_N3)
    #     total_N4 += sum(true_N4)
    #     total_N5 += sum(true_N5)

    #     bar!(plt, true_time, true_N1, bar_width=0.9, alpha=0.2, label="Total", color=:green, subplot=i, ylim=(0, 150))
    #     bar!(plt, true_time, true_N2, bar_width=0.6, alpha=0.5, label="ZL", color=:purple, subplot=i, ylim=(0, 150))
    #     bar!(plt, true_time, true_N3, bar_width=0.3, alpha=0.8, label="Clouds", color=:blue, subplot=i, ylim=(0, 150))
    #     bar!(plt, true_time, true_N5, bar_width=0.3, alpha=1.0, label="Precipitation+RH", color=:red, subplot=i, ylim=(0, 150))
     
    #     title!(plt[i], "$(month(d))/$(year(d))")
    #     xlabel!(plt[i], "Time (h)")
    #     ylabel!(plt[i], "N")
    # end
    # println("total: ", total_N1, " after zl: ", total_N2, " after clouds: ", total_N3,  " after perc: ", total_N4,  " after rh: ", total_N5)
    # println(round(total_N1/total_N1*100, digits=1), " ", round(total_N2/total_N1*100, digits=1), " ", round(total_N3/total_N1*100, digits=1), " ", round(total_N4/total_N1*100, digits=1), " ", round(total_N5/total_N1*100, digits=1))
    # # println(filtered_time_lidar)
    # data = hcat(filtered_time_lidar...)  # convert tuple of vectors to a matrix
    # writedlm(PATH_output_txt * "filtered_time_lidar_"* stability_flag*"_"*condition_flag*".txt", data)
    # savefig(PATH_output_png * "monthly_time_vs_N_panel_"* stability_flag*"_"*condition_flag*".png")
end 

function check_rh(stability_flag, condition_flag)
    PATH_output_png = "/home/ellai/test_arm_data/flux_calc/VER6/output_png/"
    PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER6/output_txt/"


    file_pbl = PATH_output_txt * "pbl_aligned_with_lidar_filtered.txt"
    info_pbl = readdlm(file_pbl)

    pbl_day = info_pbl[:, 1]
    pbl_month = info_pbl[:, 2]
    pbl_year = info_pbl[:, 3]
    pbl_time = info_pbl[:, 4] # sec
    pbl_height = info_pbl[:, 5]
    pbl_height = replace(pbl_height, "missing" => missing)

    file_rh = PATH_output_txt * "rh_aligned_with_lidar.txt"
    info_rh = readdlm(file_rh)

    file_c = PATH_output_txt * "filtered_time_lidar_" * stability_flag * "_"*condition_flag * ".txt"
    info_c = readdlm(file_c)
    #    return N_total, N_zl, N_clouds, N_prcpt, N_rh, [l_day, l_month, l_year, l_time, set_pbl_h, set_cld_h, set_stblt, set_rh_h]

    rh_day = info_rh[:, 1]
    rh_month = info_rh[:, 2]
    rh_year = info_rh[:, 3]
    rh_time = info_rh[:, 4] .* 3600 # sec
    rh_height = info_rh[:, 5]
    rh_val = info_rh[:, 6]
    rh_val = replace(rh_val, "missing" => missing)

    c_day = info_c[:, 1]
    c_month = info_c[:, 2]
    c_year = info_c[:, 3]
    c_time = info_c[:, 4]  # sec
    c_pbl_h = info_c[:, 5]
    c_cld_h = info_c[:, 6]
    c_rh_h = info_c[:, 8]



    final_rh_set = []
    final_height_set = []
    
    mask_time = (c_time .>= 11*3600) .& (c_time .<= 12*3600)

    c_day = c_day[mask_time]
    c_month = c_month[mask_time]
    c_year = c_year[mask_time]
    c_time = c_time[mask_time]
    c_pbl_h = c_pbl_h[mask_time]
    c_cld_h = c_cld_h[mask_time]
    c_rh_h = c_rh_h[mask_time]


    # mask_time = (pbl_time .>= 11*3600) .& (pbl_time .<= 12*3600)
    # pbl_day = pbl_day[mask_time]
    # pbl_month = pbl_month[mask_time]
    # pbl_year = pbl_year[mask_time]
    # pbl_time = pbl_time[mask_time]
    # pbl_height = pbl_height[mask_time]
    
    
    for i in 1:length(c_day)
        minimum_h = minimum([c_pbl_h[i], c_cld_h[i], c_rh_h[i]])
        println(c_pbl_h[i], " ", minimum_h, " ", c_cld_h[i], " ", c_rh_h[i])
        mask_for_rh = (c_day[i] .== rh_day) .& (c_month[i] .== rh_month) .& (c_year[i] .== rh_year) .& (c_time[i] .== rh_time) .& (minimum_h .>= rh_height)
        println(i, " out of ", length(c_day))
        rh_val_new = rh_val[mask_for_rh]
        rh_height_new = rh_height[mask_for_rh]

        mask_for_pbl = (c_day[i] .== pbl_day) .& (c_month[i] .== pbl_month) .& (c_year[i] .== pbl_year) .& (c_time[i] .== pbl_time) 
        pbl_height_new = pbl_height[mask_for_pbl]

        # println(size(rh_height_new) , size(pbl_height_new), " ", pbl_height_new)
        # rh_height_new = replace(rh_height_new, missing => 3000)

        if !ismissing(pbl_height_new)
            rh_height_new = rh_height_new ./ pbl_height_new
            for j in 1:length(rh_val_new)
                push!(final_rh_set, rh_val_new[j])
                push!(final_height_set, rh_height_new[j])
            end 
        end 

        
    end 
    # println(final_height_set)
    final_height_set = replace(final_height_set, NaN => missing)

    ave_rh_data, ave_h_data =[], []
    nbins = 75
    h_edges = range(0, 2; length=nbins+1)
    h_centers = (h_edges[1:end-1] .+ h_edges[2:end]) ./ 2
    for i in 1:nbins
        inds = findall(h -> !ismissing(h) && !isnan(h) && h_edges[i] ≤ h < h_edges[i+1], final_height_set)
        if !isempty(inds)
            # push!(ave_rh_data, mean(skipmissing(rh_val_new[inds])))
            push!(ave_rh_data, mean(filter(!isnan, final_rh_set[inds])))
            push!(ave_h_data, h_centers[i])
        end
    end
    println(ave_rh_data)
    println(ave_h_data)
    p1 = plot(final_rh_set, final_height_set, marker=:circle, label=false, xlabel="RH", ylabel="Height (h)", ylim=(0, 2), alpha = 0.1, color=:red)
    plot!(p1, ave_rh_data, ave_h_data, marker=:circle, label=false, xlabel="RH", ylabel="Height (h)", ylim=(0, 2),color=:blue)

    p =  plot(p1, layout=(1, 2), size = (1200, 500),  bottom_margin=10mm, left_margin=10mm)
    png(p, PATH_output_png * "rh_height_filter_$(stability_flag)_$(condition_flag).png")
    println(PATH_output_png * "rh_height_filter_$(stability_flag)_$(condition_flag).png")

end 


@everywhere function process_single_profile(i, c_day, c_month, c_year, c_time, c_pbl_h, c_cld_h, c_rh_h,
    rh_day, rh_month, rh_year, rh_time, rh_height, rh_val, rh_temp,
    pbl_day, pbl_month, pbl_year, pbl_time, pbl_height)
    minimum_h = minimum([c_pbl_h[i], c_cld_h[i], c_rh_h[i]])
    mask_for_rh = (c_day[i] .== rh_day) .& (c_month[i] .== rh_month) .& (c_year[i] .== rh_year) .& (c_time[i] .== rh_time) .& (minimum_h .>= rh_height)

    rh_val_new = rh_val[mask_for_rh]
    rh_temp_new = rh_temp[mask_for_rh]
    rh_height_new = rh_height[mask_for_rh]

    mask_for_pbl = (c_day[i] .== pbl_day) .& (c_month[i] .== pbl_month) .& (c_year[i] .== pbl_year) .& (c_time[i] .== pbl_time)
    pbl_height_new = pbl_height[mask_for_pbl]

    if !ismissing(pbl_height_new)
        rh_height_new ./= pbl_height_new
        return [(c_day[i], c_month[i], c_year[i], c_time[i], rh_height_new[j], rh_val_new[j], rh_temp_new[j]) for j in 1:length(rh_val_new)]
    else
        return []
    end
end

function check_rh_for_season(stability_flag, condition_flag, num_season)
    PATH_output_png = "/home/ellai/test_arm_data/flux_calc/VER6/output_png/"
    PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER6/output_txt/"


    file_pbl = PATH_output_txt * "pbl_aligned_with_lidar_filtered.txt"
    info_pbl = readdlm(file_pbl)

    pbl_day = info_pbl[:, 1]
    pbl_month = info_pbl[:, 2]
    pbl_year = info_pbl[:, 3]
    pbl_time = info_pbl[:, 4] # sec
    pbl_height = info_pbl[:, 5]
    pbl_height = replace(pbl_height, "missing" => missing)

    file_rh = PATH_output_txt * "rh_aligned_with_lidar.txt"
    info_rh = readdlm(file_rh)

    file_c = PATH_output_txt * "filtered_time_lidar_" * stability_flag * "_"*condition_flag * ".txt"
    info_c = readdlm(file_c)
    #    return N_total, N_zl, N_clouds, N_prcpt, N_rh, [l_day, l_month, l_year, l_time, set_pbl_h, set_cld_h, set_stblt, set_rh_h]

    rh_day = info_rh[:, 1]
    rh_month = info_rh[:, 2]
    rh_year = info_rh[:, 3]
    rh_time = info_rh[:, 4] .* 3600 # sec
    rh_height = info_rh[:, 5]
    rh_val = info_rh[:, 6]
    rh_val = replace(rh_val, "missing" => missing)
    rh_temp = info_rh[:, 7]
    rh_temp = replace(rh_temp, "missing" => missing)
    rh_temp = replace(rh_temp, "" => missing)

    c_day = info_c[:, 1]
    c_month = info_c[:, 2]
    c_year = info_c[:, 3]
    c_time = info_c[:, 4]  # sec
    c_pbl_h = info_c[:, 5]
    c_cld_h = info_c[:, 6]
    c_rh_h = info_c[:, 8]



    final_rh_set = []
    final_temp_set = []
    final_height_set = []
    
    mask_time = (c_time .>= 0*3600) .& (c_time .<= 24*3600)

    c_day = c_day[mask_time]
    c_month = c_month[mask_time]
    c_year = c_year[mask_time]
    c_time = c_time[mask_time]
    c_pbl_h = c_pbl_h[mask_time]
    c_cld_h = c_cld_h[mask_time]
    c_rh_h = c_rh_h[mask_time]

    if num_season == 1
        mask_ssn = (c_month .== 1) .| (c_month .== 2) .| (c_month .== 12)
    elseif num_season == 2
        mask_ssn = (c_month .== 3) .| (c_month .== 4) .| (c_month .== 5)
    elseif num_season == 3
        mask_ssn = (c_month .== 6) .| (c_month .== 7) .| (c_month .== 8)
    elseif num_season == 4
        mask_ssn = (c_month .== 9) .| (c_month .== 10) .| (c_month .== 11)
    end
    

    c_day = c_day[mask_ssn]
    c_month = c_month[mask_ssn]
    c_year = c_year[mask_ssn]
    c_time = c_time[mask_ssn]
    c_pbl_h = c_pbl_h[mask_ssn]
    c_cld_h = c_cld_h[mask_ssn]
    c_rh_h = c_rh_h[mask_ssn]

    # mask_time = (pbl_time .>= 11*3600) .& (pbl_time .<= 12*3600)
    # pbl_day = pbl_day[mask_time]
    # pbl_month = pbl_month[mask_time]
    # pbl_year = pbl_year[mask_time]
    # pbl_time = pbl_time[mask_time]
    # pbl_height = pbl_height[mask_time]
    
    inds = collect(1:length(c_day))
    results = pmap(i -> process_single_profile(i, c_day, c_month, c_year, c_time, c_pbl_h, c_cld_h, c_rh_h,
                                               rh_day, rh_month, rh_year, rh_time, rh_height, rh_val, rh_temp,
                                               pbl_day, pbl_month, pbl_year, pbl_time, pbl_height), inds)

    # c_day_new = []
    # c_month_new = []
    # c_year_new = []
    # c_time_new =[]

    # for i in 1:length(c_day)
    #     minimum_h = minimum([c_pbl_h[i], c_cld_h[i], c_rh_h[i]])
    #     println(c_pbl_h[i], " ", minimum_h, " ", c_cld_h[i], " ", c_rh_h[i])
    #     mask_for_rh = (c_day[i] .== rh_day) .& (c_month[i] .== rh_month) .& (c_year[i] .== rh_year) .& (c_time[i] .== rh_time) .& (minimum_h .>= rh_height)
    #     println(i, " out of ", length(c_day))
    #     rh_val_new = rh_val[mask_for_rh]
    #     rh_temp_new = rh_temp[mask_for_rh]
    #     rh_height_new = rh_height[mask_for_rh]

    #     mask_for_pbl = (c_day[i] .== pbl_day) .& (c_month[i] .== pbl_month) .& (c_year[i] .== pbl_year) .& (c_time[i] .== pbl_time) 
    #     pbl_height_new = pbl_height[mask_for_pbl]

    #     # println(size(rh_height_new) , size(pbl_height_new), " ", pbl_height_new)
    #     # rh_height_new = replace(rh_height_new, missing => 3000)

    #     if !ismissing(pbl_height_new)
    #         rh_height_new = rh_height_new ./ pbl_height_new
    #         for j in 1:length(rh_val_new)
    #             push!(final_rh_set, rh_val_new[j])
    #             push!(final_temp_set, rh_temp_new[j])
    #             push!(final_height_set, rh_height_new[j])
    #             push!(c_day_new, c_day[i])
    #             push!(c_month_new, c_month[i])
    #             push!(c_year_new, c_year[i])
    #             push!(c_time_new, c_time[i])
    #         end 
    #     end 
    # end 

    # find number of unique profiles 
    # number_set = zeros(Int, length(c_time_new))
    # unique_comb = unique(zip(c_time_new, c_day_new, c_month_new, c_year_new))
    # for (k, (ti, d, m, y)) in enumerate(unique_comb)
    #     inds = findall(i -> c_time_new[i] == ti && c_day_new[i] == d && c_month_new[i] == m && c_year_new[i] == y, eachindex(c_time_new))
    #     number_set[inds] .= k
    # end   
    
    flat_results = reduce(vcat, results)
    final_rh_set = [r[6] for r in flat_results]
    final_temp_set = replace([r[7] for r in flat_results], NaN => missing)
    final_height_set = replace([r[5] for r in flat_results], NaN => missing)
    c_day_new = [r[1] for r in flat_results]
    c_month_new = [r[2] for r in flat_results]
    c_year_new = [r[3] for r in flat_results]
    c_time_new = [r[4] for r in flat_results]

    number_set = zeros(Int, length(c_time_new))
    unique_comb = unique(zip(c_time_new, c_day_new, c_month_new, c_year_new))
    for (k, (ti, d, m, y)) in enumerate(unique_comb)
        inds = findall(i -> c_time_new[i] == ti && c_day_new[i] == d && c_month_new[i] == m && c_year_new[i] == y, eachindex(c_time_new))
        number_set[inds] .= k
    end
    # final_height_set = replace(final_height_set, NaN => missing)
    # final_temp_set = replace(final_temp_set, NaN => missing)

    ave_rh_data, ave_temp_data, ave_h_data =[], [], []
    nbins = 50
    h_edges = range(0, 2; length=nbins+1)
    h_centers = (h_edges[1:end-1] .+ h_edges[2:end]) ./ 2
    for i in 1:nbins
        inds = findall(h -> !ismissing(h) && !isnan(h) && h_edges[i] ≤ h < h_edges[i+1], final_height_set)
        if !isempty(inds)
            # push!(ave_rh_data, mean(skipmissing(rh_val_new[inds])))
            push!(ave_rh_data, mean(filter(!isnan, final_rh_set[inds])))
            push!(ave_temp_data, mean(skipmissing(final_temp_set[inds])))
            push!(ave_h_data, h_centers[i])
        end
    end
    # println(ave_rh_data)
    # println(ave_h_data)

    output_file_raw = PATH_output_txt *  "rh_height_filter_$(stability_flag)_$(condition_flag)_$(num_season)_RAW_DATA.txt"
    writedlm(output_file_raw, hcat(final_height_set, final_rh_set, final_temp_set, number_set))


    output_file = PATH_output_txt *  "rh_height_filter_$(stability_flag)_$(condition_flag)_$(num_season).txt"
    writedlm(output_file, hcat(ave_h_data, ave_rh_data, ave_temp_data))

    # p1 = plot(final_rh_set, final_height_set, marker=:circle, label=false, xlabel="RH", ylabel="Height (h)", ylim=(0, 2), alpha = 0.1, color=:red)
    # plot!(p1, ave_rh_data, ave_h_data, marker=:circle, label=false, xlabel="RH", ylabel="Height (h)", ylim=(0, 2),color=:blue)

    # p =  plot(p1, layout=(1, 2), size = (1200, 500),  bottom_margin=10mm, left_margin=10mm)
    # png(p, PATH_output_png * "rh_height_filter_$(stability_flag)_$(condition_flag)_$(num_season).png")
    println(PATH_output_png * "rh_height_filter_$(stability_flag)_$(condition_flag)_$(num_season).txt")

end 


function check_rh_for_regime(num_regime)
    PATH_output_png = "/home/ellai/test_arm_data/flux_calc/VER6/output_png/"
    PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER6/output_txt/"


    file_pbl = PATH_output_txt * "pbl_aligned_with_lidar_filtered.txt"
    info_pbl = readdlm(file_pbl)

    pbl_day = info_pbl[:, 1]
    pbl_month = info_pbl[:, 2]
    pbl_year = info_pbl[:, 3]
    pbl_time = info_pbl[:, 4] # sec
    pbl_height = info_pbl[:, 5]
    pbl_height = replace(pbl_height, "missing" => missing)

    file_rh = PATH_output_txt * "rh_aligned_with_lidar.txt"
    info_rh = readdlm(file_rh)

    file_c_1 = PATH_output_txt * "filtered_time_lidar_unstable_clean.txt"
    file_c_2 = PATH_output_txt * "filtered_time_lidar_neutral_clean.txt"
    info_c_1 = readdlm(file_c_1)
    info_c_2 = readdlm(file_c_2)
    info_c = vcat(info_c_1, info_c_2)
    #    return N_total, N_zl, N_clouds, N_prcpt, N_rh, [l_day, l_month, l_year, l_time, set_pbl_h, set_cld_h, set_stblt, set_rh_h]

    file_rgm = PATH_output_txt * "regime_aligned_with_lidar.txt"
    info_rgm = readdlm(file_rgm)
    rgm_day = info_rgm[:, 1]
    rgm_month = info_rgm[:, 2]
    rgm_year = info_rgm[:, 3]
    rgm_time = info_rgm[:, 4]
    rgm_val = info_rgm[:, 7]
    rgm_val = replace(rgm_val, "missing" => missing)
 
    # println(rgm_val)
    # println(num_regime)
    mask_rgm = (rgm_val .== num_regime)
    mask_rgm = replace(mask_rgm, missing => false)

    # println("hhh", sum(mask_rgm))
    # println(size(mask_rgm), " ", size(rgm_val))
    # println("hey", rgm_val[mask_rgm])
    rgm_day = rgm_day[mask_rgm]
    rgm_month = rgm_month[mask_rgm]
    rgm_year = rgm_year[mask_rgm]
    rgm_time = rgm_time[mask_rgm]


    rh_day = info_rh[:, 1]
    rh_month = info_rh[:, 2]
    rh_year = info_rh[:, 3]
    rh_time = info_rh[:, 4] .* 3600 # sec
    rh_height = info_rh[:, 5]
    rh_val = info_rh[:, 6]
    rh_val = replace(rh_val, "missing" => missing)
    rh_temp = info_rh[:, 7]
    rh_temp = replace(rh_temp, "missing" => missing)
    rh_temp = replace(rh_temp, "" => missing)

    c_day = info_c[:, 1]
    c_month = info_c[:, 2]
    c_year = info_c[:, 3]
    c_time = info_c[:, 4]  # sec
    c_pbl_h = info_c[:, 5]
    c_cld_h = info_c[:, 6]
    c_rh_h = info_c[:, 8]
    
    # filtration based on regime
    mask_zero = [any(j -> c_day[i] == rgm_day[j] && c_month[i] == rgm_month[j] && c_year[i] == rgm_year[j] && c_time[i] == rgm_time[j], 1:length(rgm_day)) for i in 1:length(c_day)]

    c_day = c_day[mask_zero]
    c_month =c_month[mask_zero]
    c_year = c_year[mask_zero]
    c_time = c_time[mask_zero]
    c_pbl_h = c_pbl_h[mask_zero]
    c_cld_h = c_cld_h[mask_zero]
    c_rh_h = c_rh_h[mask_zero]


    final_rh_set = []
    final_temp_set = []
    final_height_set = []
    
    mask_time = (c_time .>= 0*3600) .& (c_time .<= 24*3600)

    c_day = c_day[mask_time]
    c_month = c_month[mask_time]
    c_year = c_year[mask_time]
    c_time = c_time[mask_time]
    c_pbl_h = c_pbl_h[mask_time]
    c_cld_h = c_cld_h[mask_time]
    c_rh_h = c_rh_h[mask_time]

    # if num_season == 1
    #     mask_ssn = (c_month .== 1) .| (c_month .== 2) .| (c_month .== 12)
    # elseif num_season == 2
    #     mask_ssn = (c_month .== 3) .| (c_month .== 4) .| (c_month .== 5)
    # elseif num_season == 3
    #     mask_ssn = (c_month .== 6) .| (c_month .== 7) .| (c_month .== 8)
    # elseif num_season == 4
    #     mask_ssn = (c_month .== 9) .| (c_month .== 10) .| (c_month .== 11)
    # end
    

    # c_day = c_day[mask_ssn]
    # c_month = c_month[mask_ssn]
    # c_year = c_year[mask_ssn]
    # c_time = c_time[mask_ssn]
    # c_pbl_h = c_pbl_h[mask_ssn]
    # c_cld_h = c_cld_h[mask_ssn]
    # c_rh_h = c_rh_h[mask_ssn]

    # mask_time = (pbl_time .>= 11*3600) .& (pbl_time .<= 12*3600)
    # pbl_day = pbl_day[mask_time]
    # pbl_month = pbl_month[mask_time]
    # pbl_year = pbl_year[mask_time]
    # pbl_time = pbl_time[mask_time]
    # pbl_height = pbl_height[mask_time]
    
    c_day_new = []
    c_month_new = []
    c_year_new = []
    c_time_new =[]

    for i in 1:length(c_day)
        minimum_h = minimum([c_pbl_h[i], c_cld_h[i], c_rh_h[i]])
        println(c_pbl_h[i], " ", minimum_h, " ", c_cld_h[i], " ", c_rh_h[i])
        mask_for_rh = (c_day[i] .== rh_day) .& (c_month[i] .== rh_month) .& (c_year[i] .== rh_year) .& (c_time[i] .== rh_time) .& (minimum_h .>= rh_height)
        println(i, " out of ", length(c_day))
        rh_val_new = rh_val[mask_for_rh]
        rh_temp_new = rh_temp[mask_for_rh]
        rh_height_new = rh_height[mask_for_rh]

        mask_for_pbl = (c_day[i] .== pbl_day) .& (c_month[i] .== pbl_month) .& (c_year[i] .== pbl_year) .& (c_time[i] .== pbl_time) 
        pbl_height_new = pbl_height[mask_for_pbl]

        # println(size(rh_height_new) , size(pbl_height_new), " ", pbl_height_new)
        # rh_height_new = replace(rh_height_new, missing => 3000)

        if !ismissing(pbl_height_new)
            rh_height_new = rh_height_new ./ pbl_height_new
            for j in 1:length(rh_val_new)
                push!(final_rh_set, rh_val_new[j])
                push!(final_temp_set, rh_temp_new[j])
                push!(final_height_set, rh_height_new[j])
                push!(c_day_new, c_day[i])
                push!(c_month_new, c_month[i])
                push!(c_year_new, c_year[i])
                push!(c_time_new, c_time[i])
            end 
        end 
    end 

    # find number of unique profiles 
    number_set = zeros(Int, length(c_time_new))
    unique_comb = unique(zip(c_time_new, c_day_new, c_month_new, c_year_new))
    for (k, (ti, d, m, y)) in enumerate(unique_comb)
        inds = findall(i -> c_time_new[i] == ti && c_day_new[i] == d && c_month_new[i] == m && c_year_new[i] == y, eachindex(c_time_new))
        number_set[inds] .= k
    end   
    


    # println(final_height_set)
    # println(final_temp_set)
    final_height_set = replace(final_height_set, NaN => missing)
    final_temp_set = replace(final_temp_set, NaN => missing)

    ave_rh_data, ave_temp_data, ave_h_data =[], [], []
    nbins = 50
    h_edges = range(0, 2; length=nbins+1)
    h_centers = (h_edges[1:end-1] .+ h_edges[2:end]) ./ 2
    for i in 1:nbins
        inds = findall(h -> !ismissing(h) && !isnan(h) && h_edges[i] ≤ h < h_edges[i+1], final_height_set)
        if !isempty(inds)
            # push!(ave_rh_data, mean(skipmissing(rh_val_new[inds])))
            push!(ave_rh_data, mean(filter(!isnan, final_rh_set[inds])))
            push!(ave_temp_data, mean(skipmissing(final_temp_set[inds])))
            push!(ave_h_data, h_centers[i])
        end
    end
    # println(ave_rh_data)
    # println(ave_h_data)

    output_file_raw = PATH_output_txt *  "rh_height_filter_$(num_regime)_RAW_DATA.txt"
    writedlm(output_file_raw, hcat(final_height_set, final_rh_set, final_temp_set, number_set))


    output_file = PATH_output_txt *  "rh_height_filter_$(num_regime).txt"
    writedlm(output_file, hcat(ave_h_data, ave_rh_data, ave_temp_data))

    # p1 = plot(final_rh_set, final_height_set, marker=:circle, label=false, xlabel="RH", ylabel="Height (h)", ylim=(0, 2), alpha = 0.1, color=:red)
    # plot!(p1, ave_rh_data, ave_h_data, marker=:circle, label=false, xlabel="RH", ylabel="Height (h)", ylim=(0, 2),color=:blue)

    # p =  plot(p1, layout=(1, 2), size = (1200, 500),  bottom_margin=10mm, left_margin=10mm)
    # png(p, PATH_output_png * "rh_height_filter_$(stability_flag)_$(condition_flag)_$(num_season).png")
    println(PATH_output_png * "rh_height_filter_$(num_regime).txt")

end 


# stability_flag = "unstable" # "neutral/unstable"
# clouds_flag = "someclouds" # "someclouds/noclouds"

# main(stability_flag, clouds_flag)

# main("unstable", "clean")
# total: 35496.0 after zl: 3736.0 after clouds: 1380.0 after perc: 1255.0 after rh: 1094.0
# 100.0 10.5 3.9 3.5 3.1
# total: 35496.0 after zl: 3736.0 after clouds: 1289.0 after perc: 1176.0 after rh: 1106.0
# 100.0 10.5 3.6 3.3 3.1

# main("unstable", "nonclean")
# total: 35496.0 after zl: 3736.0 after clouds: 2360.0 after perc: 2111.0 after rh: 2111.0
# 100.0 10.5 6.6 5.9 5.9
# total: 35496.0 after zl: 3736.0 after clouds: 2341.0 after perc: 2092.0 after rh: 2092.0
# 100.0 10.5 6.6 5.9 5.9
# total: 35496.0 after zl: 3736.0 after clouds: 955.0 after perc: 911.0 after rh: 911.0
# 100.0 10.5 2.7 2.6 2.6

# main("neutral", "clean")
# total: 35496.0 after zl: 23730.0 after clouds: 6226.0 after perc: 5211.0 after rh: 4226.0
# 100.0 66.9 17.5 14.7 11.9
# total: 35496.0 after zl: 23740.0 after clouds: 5633.0 after perc: 4674.0 after rh: 4063.0
# 100.0 66.9 15.9 13.2 11.4

# main("neutral", "nonclean")
# total: 35496.0 after zl: 23730.0 after clouds: 18502.0 after perc: 15299.0 after rh: 15299.0
# 100.0 66.9 52.1 43.1 43.1
# total: 35496.0 after zl: 23740.0 after clouds: 18463.0 after perc: 15290.0 after rh: 15290.0
# 100.0 66.9 52.0 43.1 43.1
# total: 35496.0 after zl: 23740.0 after clouds: 10670.0 after perc: 9137.0 after rh: 9137.0
# 100.0 66.9 30.1 25.7 25.7

# main("stable", "clean")
# total: 35496.0 after zl: 7226.0 after clouds: 2458.0 after perc: 2093.0 after rh: 1598.0
# 100.0 20.4 6.9 5.9 4.5
# total: 35496.0 after zl: 7234.0 after clouds: 2378.0 after perc: 2034.0 after rh: 1909.0
# 100.0 20.4 6.7 5.7 5.4

# main("stable", "nonclean")
# total: 35496.0 after zl: 7226.0 after clouds: 3658.0 after perc: 3111.0 after rh: 3111.0
# 100.0 20.4 10.3 8.8 8.8
# total: 35496.0 after zl: 7234.0 after clouds:..  after perc: .. after rh: 3106.0
# 100.0 20.4 10.3 8.8 8.8
# total: 35496.0 after zl: 7234.0 after clouds: 797.0 after perc: 714.0 after rh: 714.0
# 100.0 20.4 2.2 2.0 2.0

#################################
# main("unstable",  "clean")
# check_rh("unstable", "clean")
# check_rh_for_season("unstable", "clean", 1)
# check_rh_for_regime(1) # 480

# for i in 1:4
#     check_rh_for_season("unstable", "clean", i)
# end 

for i in 1:4
    check_rh_for_season("unstable", "nonclean", i)
end 

for i in 1:4
    check_rh_for_season("neutral", "clean", i)
end 

for i in 1:4
    check_rh_for_season("neutral", "nonclean", i)
end 

for i in 1:4
    check_rh_for_season("stable", "clean", i)
end 

for i in 1:4
    check_rh_for_season("stable", "nonclean", i)
end 
# check_rh_for_season("stable", "nonclean", 4)

# check_rh_for_regime(1) # 480 
# check_rh_for_regime(2) # 384
# check_rh_for_regime(3) # 159
# check_rh_for_regime(4) 
# check_rh_for_regime(5) # 521
# check_rh_for_regime(6) # 139
# check_rh_for_regime(7)
# check_rh_for_regime(8)
# check_rh_for_regime(9)

# cloud_options = ["noclouds", "someclouds"]
# stability_options = ["unstable", "neutral"]

# for flag_clouds in cloud_options
#     for flag_stability in stability_options
#         main(flag_stability, flag_clouds)
#     end
# end




# # time_in = 11
# # time_out = 13 
# # month_flag = [false, 10, 2021] # or [false]
# # N_set  = main(info_time_lidar, info_stab, info_pbl, info_clouds, time_in, time_out, month_flag)

# ds = Dataset("/home/ellai/test_arm_data/flux_calc/VER3/hpbl.2022.nc", "r")  # open in read-only mode
# println("Variables in the file:")
# for (varname, _) in ds
#     println(" - ", varname)
# end


# ooops = ds["y"]
# for (key, value) in ooops.attrib
#     println("$key => $value")
# end

# # sleep(100)
# time = ds["time"][:]
# lat = ds["lat"][:]
# lon = ds["lon"][:]
# y = ds["y"][:]
# x = ds["x"][:]
# hpbl = ds["hpbl"]
# println(size(hpbl))
# println(size(y))
# println(size(x))

# sleep(100)

# println("Latitude range: ", minimum(lat), " to ", maximum(lat))
# println("Longitude range: ", minimum(lon), " to ", maximum(lon))

# target_lat = 29.75
# target_lon = -95.35
# # Find nearest index
# lat_idx = findmin(abs.(lat .- target_lat))[2]
# lon_idx = findmin(abs.(lon .- target_lon))[2]

# println("Nearest lat: ", lat[lat_idx], " at index ", lat_idx)
# println("Nearest lon: ", lon[lon_idx], " at index ", lon_idx)


# println(size(hpbl))
# println(size(lat), size(lon), size(time))
# println(ds["lat"][:])