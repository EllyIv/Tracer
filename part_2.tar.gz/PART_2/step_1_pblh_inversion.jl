using Glob  # for globbing the file patterns
using CSV   # for reading CSV files
using Plots # for plotting
using Colors # for color normalization
using NCDatasets # for NetCDF
using Dates  # to convert dates in sec
using Statistics # for mean
using Dierckx     # For detrend (spline interpolation)
using Polynomials
using StatsBase 
using DSP  # Import DSP package
using DelimitedFiles
using NetCDF
using Measures
using CategoricalArrays
using Distributed
using Interpolations 
using DataFrames

using Distributed
addprocs(32)

@everywhere begin
    using DelimitedFiles, Statistics

    # Make sure check_inversion is defined on all workers
    function check_inversion(fixed_month, fixed_year, fixed_day, fixed_time, info_rh)
        rh_day    = info_rh[:, 1]
        rh_month  = info_rh[:, 2]
        rh_year   = info_rh[:, 3]
        rh_time   = info_rh[:, 4]
        rh_height = info_rh[:, 5]
        rh_val    = info_rh[:, 7]          # temperature

        rh_val    = replace(rh_val, "" => missing)
        rh_val    = replace(rh_val, "missing" => missing)

        mask_time = (rh_month .== fixed_month) .&
                    (rh_year .== fixed_year) .&
                    (rh_day .== fixed_day) .&
                    (abs.(rh_time .- fixed_time) .<= 0.5)

        rh_height = rh_height[mask_time]
        rh_val    = rh_val[mask_time]
        mask_valid = .!ismissing.(rh_val)
        rh_height = rh_height[mask_valid]
        rh_val    = rh_val[mask_valid]
        if isempty(rh_height)
            return missing
        end

        idx = sortperm(rh_height)
        rh_height = rh_height[idx]
        rh_val    = rh_val[idx]
        unique_h = sort(unique(rh_height))
        ave_h = Float64[]
        ave_t = Float64[]
        for h in unique_h
            vals = rh_val[rh_height .== h]
            push!(ave_h, h)
            push!(ave_t, mean(vals))
        end
        if length(ave_h) < 2
            return missing
        end
        grad_T = diff(ave_t) ./ diff(ave_h)
        threshold = 0.015
        inv_idx = findfirst(grad_T .> threshold)
        inversion_height = isnothing(inv_idx) ? missing : ave_h[inv_idx]
        println(inversion_height)
        return inversion_height
    end
end

function main()
    PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER5/output_txt/"
    file_rh = PATH_output_txt * "rh_aligned_with_lidar.txt"
    info_rh = readdlm(file_rh)

    rh_day, rh_month, rh_year, rh_time = info_rh[:, 1], info_rh[:, 2], info_rh[:, 3], info_rh[:, 4]
    combos = unique([(rh_day[i], rh_month[i], rh_year[i], rh_time[i]) for i in eachindex(rh_day)])
    println("Total unique combinations: ", length(combos))
    # Broadcast data to all workers just once
    @everywhere const INFO_RH_GLOBAL = $info_rh

    
    # Parallel mapping
    results = pmap(combos) do (day, month, year, time)
        pbl = check_inversion(month, year, day, time, INFO_RH_GLOBAL)
        [day, month, year, time, pbl]
    end

    output_file = "/home/ellai/test_arm_data/flux_calc/VER6/output_txt/pbl_aligned_with_lidar_temp_inversion.txt"
    writedlm(output_file, results)
    println(output_file)
end


function plot_normalized_profiles()
    PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER6/output_txt/"
    PATH_output_png = "/home/ellai/test_arm_data/flux_calc/VER6/output_png/"

    # Read temperature profile data
    file_rh = "/home/ellai/test_arm_data/flux_calc/VER5/output_txt/" * "rh_aligned_with_lidar.txt"
    info_rh = readdlm(file_rh)

    rh_day    = info_rh[:, 1]
    rh_month  = info_rh[:, 2]
    rh_year   = info_rh[:, 3]
    rh_time   = info_rh[:, 4]
    rh_height = info_rh[:, 5]
    rh_val    = info_rh[:, 7]  # temperature

    rh_val = replace(rh_val, "missing" => missing)
    rh_val = replace(rh_val, "" => missing)

    # Read computed inversion heights
    file_pbl = PATH_output_txt * "pbl_temp_inversion.txt"
    info_pbl = readdlm(file_pbl)

    pbl_day   = info_pbl[:, 1]
    pbl_month = info_pbl[:, 2]
    pbl_year  = info_pbl[:, 3]
    pbl_time  = info_pbl[:, 4]
    pbl_val   = info_pbl[:, 5]
    pbl_val = replace(pbl_val, "missing" => missing)

    # Prepare plot
    plt = plot(xlabel="Temperature (K)", ylabel="z / PBL height", legend=false,
               xlims=(minimum(skipmissing(rh_val)) - 1, maximum(skipmissing(rh_val)) + 1),
               ylims=(0, 2))

    # For each unique (day, month, year, time) combination
    combos = unique([(rh_day[i], rh_month[i], rh_year[i], rh_time[i]) for i in eachindex(rh_day)])
    println("Total profiles: ", length(combos))

    for (day, month, year, time) in combos
        # Skip times outside 12–15 h 
        if time < 12 || time > 15
            continue
        end

        mask_rh = (rh_day .== day) .& (rh_month .== month) .& (rh_year .== year) .& (rh_time .== time)
        mask_pbl = (pbl_day .== day) .& (pbl_month .== month) .& (pbl_year .== year) .& (pbl_time .== time)

        if !any(mask_pbl)
            continue
        end

        pbl = pbl_val[mask_pbl][1]
        if ismissing(pbl) || pbl == 0
            continue
        end

        h = rh_height[mask_rh]
        t = rh_val[mask_rh]
        valid = .!ismissing.(t)
        h = h[valid]
        t = t[valid]
        if isempty(h)
            continue
        end

        # Normalize by inversion height
        z_norm = h ./ pbl

        # Plot each profile as a faint blue scatter 
        scatter!(plt, t, z_norm, color=:blue, alpha=0.1, markersize=2)
    end

    # Save
    output_file = PATH_output_png * "normalized_temp_profiles_12to15.png"
    savefig(plt, output_file)
    println( output_file)
end


@everywhere function process_profile(day, month, year, time, info_rh, info_pbl)
    # skip if time is outside 12–15
    if time < 12 || time > 15
        return nothing
    end

    rh_day, rh_month, rh_year, rh_time = info_rh[:, 1], info_rh[:, 2], info_rh[:, 3], info_rh[:, 4]
    rh_height, rh_val = info_rh[:, 5], info_rh[:, 7]
    rh_val = replace(rh_val, "missing" => missing)
    rh_val = replace(rh_val, "" => missing)

    pbl_day, pbl_month, pbl_year, pbl_time, pbl_val =
        info_pbl[:, 1], info_pbl[:, 2], info_pbl[:, 3], info_pbl[:, 4], info_pbl[:, 5]
    pbl_val = replace(pbl_val, "missing" => missing)

    mask_rh = (rh_day .== day) .& (rh_month .== month) .& (rh_year .== year) .& (rh_time .== time)
    mask_pbl = (pbl_day .== day) .& (pbl_month .== month) .& (pbl_year .== year) .& (pbl_time .== time)

    if !any(mask_pbl)
        return nothing
    end

    pbl = pbl_val[mask_pbl][1]
    if ismissing(pbl) || pbl == 0
        return nothing
    end

    h = rh_height[mask_rh]
    t = rh_val[mask_rh]
    valid = .!ismissing.(t)
    h = h[valid]
    t = t[valid]

    isempty(h) && return nothing

    z_norm = h ./ pbl
    return (t, z_norm)
end


function plot_normalized_profiles_parallel()
    PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER6/output_txt/"
    PATH_output_png = "/home/ellai/test_arm_data/flux_calc/VER6/output_png/"

    file_rh = "/home/ellai/test_arm_data/flux_calc/VER5/output_txt/rh_aligned_with_lidar.txt"
    file_pbl = PATH_output_txt * "pbl_temp_inversion.txt"
    info_rh = readdlm(file_rh)
    info_pbl = readdlm(file_pbl)

    combos = unique([(info_rh[i, 1], info_rh[i, 2], info_rh[i, 3], info_rh[i, 4]) for i in 1:size(info_rh, 1)])

    println("Processing ", length(combos), " profiles in parallel...")

    results = pmap(c -> process_profile(c[1], c[2], c[3], c[4], info_rh, info_pbl), combos)
    results = filter(!isnothing, results)

    plt = plot(xlabel="Temperature (K)", ylabel="z / PBL height", legend=false,
               ylims=(0, 2), color=:blue, alpha=0.01, markersize=2)

    for (t, z_norm) in results
        scatter!(plt, t, z_norm, alpha=0.01)
    end

    savefig(PATH_output_png * "normalized_temp_profiles_12to15.png")
    println(PATH_output_png * "normalized_temp_profiles_12to15.png")

    all_t = vcat([r[1] for r in results]...)
    all_z = vcat([r[2] for r in results]...)
    data_out = hcat(all_t, all_z)
    output_file = PATH_output_txt * "normalized_temp_profiles_12to15.txt"
    writedlm(output_file, data_out)
    println(output_file)
end


# main()
# plot_normalized_profiles()
plot_normalized_profiles_parallel()