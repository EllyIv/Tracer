using Glob  # for globbing the file patterns
using CSV   # for reading CSV files
using Plots # for plotting
using Colors # for color normalization
using NCDatasets # for NetCDF
using Dates  # to convert dates in sec
using Statistics # for mean
using Dierckx     # For detrend (spline interpolation)
using Polynomials
using StatsBase 
using DSP  # Import DSP package
using DelimitedFiles
using NetCDF
using Measures
using Distributed
using LaTeXStrings
addprocs(16)
# atexit(() -> rmprocs(workers()))

@everywhere const PATH_folder_sonde = "/home/ellai/data/archive/DOE-SC0021074 (Tracer)/level 1/houinterpolatedsondeM1/"  # for rh and temperature

# const PATH_folder_sonde = "/home/ellai/data/archive/DOE-SC0021074 (Tracer)/level 1/houinterpolatedsondeM1/"
# const PATH_folder_sonde2 = "/home/ellai/data/archive/DOE-SC0021074 (Tracer)/level 1/houpblhtsonde1mcfarlM1/"
@everywhere const PATH_output_png = "/home/ellai/test_arm_data/flux_calc/VER6/output_png/"
@everywhere const PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER6/output_txt/"

# const time_gap = 3 * 3600 # sec 
@everywhere const time_zone = -5
@everywhere const max_h = 4000

@everywhere using NCDatasets, Statistics, Interpolations, LsqFit, Dates, Polynomials
@everywhere using Glob, DelimitedFiles
# RH and Temperature data for H = 105 and Time = 12pm 
#

# from dataset format to seconds
# function from_datetime_to_sec(set_time)
#     return hour.(set_time) .* 3600 .+ minute.(set_time) .* 60 .+ second.(set_time) .+ millisecond.(set_time) ./ 1000
# end

@everywhere function from_datetime_to_sec(set_time, day_in, month_in, year_in)
    time_sec = hour.(set_time) .* 3600 .+ minute.(set_time) .* 60 .+ second.(set_time) 
    
    base_datetime = DateTime(year_in, month_in, day_in)
    total_time_dt = base_datetime .+ Second.(time_sec)
    dt_local = total_time_dt .+ Hour(time_zone)

    true_year = year.(dt_local)
    true_month = month.(dt_local)
    true_day = day.(dt_local)

    true_time_sec = Dates.value.(dt_local .- DateTime.(true_year, true_month, true_day)) ./ 1000

    return true_time_sec, true_day, true_month, true_year
end


@everywhere function read_sonde_data_for_one_file(PATH_file,  day_str, month_str, year_str)
    dataset = NCDataset(PATH_file, "r")
    init_day = parse(Int, day_str)
    init_month = parse(Int, month_str)
    init_year = parse(Int, year_str)

    # variable_names = keys(dataset)
    # println("Variables in the dataset: ", variable_names)
    # wind = dataset["u_wind"]
    # println(size(wind))
    # sleep(100)

    # precip_var = dataset["precip"]
    # println("Attributes for 'precip':")
    # for (key, value) in precip_var.attrib
    #     println("$key => $value")
    # end


    all_info = []
    try 
        time_in_datetime = dataset["time"][:] # + num_day + time_zone * 3600 # sec, measurements each 30 min
        time_in_sec, day, month, year =  from_datetime_to_sec(time_in_datetime, init_day, init_month, init_year) 
        # println(time_in_sec[1:10]- time_in_sec[2:11])
        # sleep(100)
        height = dataset["height"]*1000 # m 
        # println(height)
        # println(size(height))
        # println(maximum(height))
        # sleep(100)
        valid_j = findall(h -> h <= max_h, height)
        # println(maximum(height[valid_j]))
        # sleep(5)
        # println(size(valid_j))
        wind_data = dataset["wspd"][valid_j, :] 
        height = height[valid_j]
        # println(size(wind_data))
        # sleep(1000)

        # println(size(time_in_sec), " ", size(height), " ", size(wind_data) )        
        # sleep(1000)
        # for i in 1:length(time_in_sec)
        #     for j in 1:length(height)
        #         if height[j] <= 2000
        #             push!(all_info, [day[i], month[i], year[i], time_in_sec[i]/3600, height[j], wind_data[j, i]])    
        #         end    
        #     end  
        # end
        bin_size = 900  # 15 minutes in seconds
        min_time = floor(Int, minimum(time_in_sec))
        max_time = ceil(Int, maximum(time_in_sec))
        bins = min_time:bin_size:max_time

        for k in 1:length(bins)-1
            t_start = bins[k]
            t_end = bins[k+1]
            # t_mid = (t_start + t_end) / 2

            inds = findall(t -> t_start <= t < t_end, time_in_sec)

            if !isempty(inds)
                for j in 1:length(height)
                    values = wind_data[j, inds]
                    if !all(ismissing, values)
                        avg = mean(skipmissing(values))
                        push!(all_info, [day[inds[1]], month[inds[1]], year[inds[1]], t_start / 3600, height[j], avg])
                    end
                end
            end
        end
    finally 
        close(dataset)
    end

    return all_info
end

@everywhere function extrapolated_data(info_sonde_all_days)
    # PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER4/output_txt/"
    
    input_file_h = PATH_output_txt * "height_lidar.txt"
    new_height = readdlm(input_file_h)
    # println(maximum(new_height))
    # sleep(30)
    # println(size(info_sonde_all_days))
    # println(info_sonde_all_days[1])
    day_w = [x[1] for x in info_sonde_all_days] # info_sonde_all_days[:, 1]
    month_w = [x[2] for x in info_sonde_all_days]
    year_w = [x[3] for x in info_sonde_all_days]
    hour_w = [x[4] for x in info_sonde_all_days]
    height_w = [x[5] for x in info_sonde_all_days]
    wind_w  = [x[6] for x in info_sonde_all_days]
    # println(maximum(height_w))
    # sleep(30)
    # println(day_w)
    # unique_times = unique(hcat(day_w, year_w))
   
    unique_times = unique([(day_w[i], month_w[i], year_w[i], hour_w[i]) for i in eachindex(day_w)])
    
    new_wind = []
    
    for (d, m, y, h) in unique_times
        mask = (day_w .== d) .& (month_w .== m) .& (year_w .== y) .& (hour_w .== h)
        heights = Float64.(height_w[mask])
        winds   = Float64.(wind_w[mask])
    
        sort_idx = sortperm(heights)
        heights_sorted = heights[sort_idx]
        winds_sorted   = winds[sort_idx]
    
        interpolated = []
    
        for h_val in new_height
            diffs = abs.(heights_sorted .- h_val)
            sorted_idx = sortperm(diffs)
            i1, i2 = sorted_idx[1:2]
    
            if heights_sorted[i1] > heights_sorted[i2]
                i1, i2 = i2, i1
            end
    
            x1, x2 = heights_sorted[i1], heights_sorted[i2]
            y1, y2 = winds_sorted[i1], winds_sorted[i2]
    
            interp_val = y1 + (h_val - x1) * (y2 - y1) / (x2 - x1)
            push!(interpolated, interp_val)
        end
    
        push!(new_wind, interpolated)
    end

    output = []

    for (i, (d, m, y, h)) in enumerate(unique_times)
        winds_interp = new_wind[i]
    
        for (j, height_val) in enumerate(new_height)
            wind_val = winds_interp[j]
            push!(output, (d, m, y, h, height_val, wind_val))
        end
    end    
    writedlm(PATH_output_txt*"wind_profile_interp.txt", output)
    println(PATH_output_txt*"wind_profile_interp.txt")

end     

@everywhere function process_sonde_file(file::String)
    file_parts = split(basename(file), ".")
    day = file_parts[3][7:8]
    month = file_parts[3][5:6]
    year = file_parts[3][1:4]
    println("Processing day ", day, " month ", month, " year ", year)

    file_path = joinpath(PATH_folder_sonde, file)
    return read_sonde_data_for_one_file(file_path, day, month, year)
end

function main()
    set_files = filter(x -> endswith(x, ".nc"), readdir(PATH_folder_sonde))

    results = pmap(process_sonde_file, set_files)

    info_sonde_all_days = reduce(vcat, results)
    output_file = joinpath(PATH_output_txt, "wind_profile.txt")
    writedlm(output_file, info_sonde_all_days)

    extrapolated_data(info_sonde_all_days)
end

# @everywhere  function main()
#     info_sonde_all_days = []

#     set_files = filter(x -> endswith(x, ".nc"), readdir(PATH_folder_sonde))
#     for file in set_files
#         file_parts = split(basename(file), ".")
#         day = file_parts[3][7:8]
#         month = file_parts[3][5:6]
#         year = file_parts[3][1:4]
#         println("day ", day, " month ", month, " year ", year)

#         file_new = PATH_folder_sonde * file
#         info_one_file = read_sonde_data_for_one_file(file_new, day, month, year) # [day_int, month_int, year_int, rh_d, t_d]
#         append!(info_sonde_all_days, info_one_file)
#     end
#     output_file_name = "wind_profile.txt"
#     output_file = PATH_output_txt * output_file_name
#     writedlm(output_file, info_sonde_all_days)
   
#     extrapolated_data(info_sonde_all_days)
# end 


function check()
    # PATH_output_png = "/home/ellai/test_arm_data/flux_calc/VER4/output_png/"
    # PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER4/output_txt/"

    wind_1  = readdlm(PATH_output_txt * "wind_profile.txt")
    wind_2 = readdlm(PATH_output_txt * "wind_profile_interp.txt")

    target_time = [1.0,	12.0, 2021.0, 10.758333333333333]
    rows_1 = [row for row in eachrow(wind_1) if row[1:4] == target_time]
    rows_2 = [row for row in eachrow(wind_2) if row[1:4] == target_time]

    println(size(rows_1))
    println(size(rows_2))
    x1 = [row[5] for row in rows_1]
    y1 = [row[6] for row in rows_1]

    x2 = [row[5] for row in rows_2]
    y2 = [row[6] for row in rows_2]
    
    for i in 1:length(y2)
        println(y2[i]," " , x2[i])
    end 
    p1 = plot(y1, x1, label = "Original", xlabel = "Wind", ylabel = "Height", lw = 2)
    plot!(p1, y2, x2, label = "Interpolated", lw = 2, linestyle = :dash)
    
    savefig(p1, PATH_output_png * "test.png")

end 

function divide_by_bins(ind , time, wind)
    time = time[ind]
    wind = wind[ind]

    num_intervals = 24 * 2 
    interval_width = 24 / num_intervals
    bin_indices = floor.(Int, time / interval_width) .+ 1 #rounds a number down 

    number = [isempty(wind[bin_indices .== i]) ? NaN : count(!ismissing, wind[bin_indices .== i]) for i in 1:num_intervals]
    intensity = number./maximum(filter(!isnan, number))
    # println(number)
    # println(intensity)
    # intensity = replace(intensity, NaN => 0.0)

    avg_wind = [isempty(wind[bin_indices .== i]) ? NaN : mean(skipmissing(wind[bin_indices .== i])) for i in 1:num_intervals]
    # std_flux = [std(flux[bin_indices .== i]) for i in 1:num_intervals]
    std_wind = [isempty(wind[bin_indices .== i]) ? NaN : std(skipmissing(wind[bin_indices .== i])) for i in 1:num_intervals]
    # time_bins = collect(0:interval_width:24 - interval_width) .+ interval_width / 2
    bin_edges = 0:interval_width:24
    time_bins = bin_edges[1:end-1] .+ interval_width / 2

    upper = avg_wind .+ std_wind
    lower = avg_wind .- std_wind

    return [time_bins, avg_wind, upper, lower, intensity]

end 




function normalize_height(fix_t, day, month, year, input_data_pbl1)
    #[pbl1[1], pbl2[1], day[1], hours, month[1], year[1]]
    # day_lidar, m_lidar, y_lidar, t_lidar, pbl_set1
    day_pbl, month_pbl, year_pbl = input_data_pbl1[:, 1], input_data_pbl1[:, 2], input_data_pbl1[:, 3]
    time_pbl, pbl_h = input_data_pbl1[:, 4], input_data_pbl1[:, 5]
    
    fix_t = floor(Float64, fix_t)
    # println(fix_t)
    # println(time_pbl[1:10])
    # sleep(100)
    time_gap = 30 * 60 # 30 min 
    mask =  (day_pbl .== day) .& (month_pbl .== month) .& (year_pbl .== year) .&  (abs.(time_pbl .- fix_t) .< time_gap)
    
    pbl_h = replace(pbl_h, "missing" => missing)
    # println(pbl_h[mask])

    if !isempty(skipmissing(pbl_h[mask]))
        # println("here ", mean(skipmissing(pbl_h[mask])))
        # sleep(1000)
        return mean(skipmissing(pbl_h[mask]))
    else 
        return missing
    end
end  

function find_number_of_the_profile(day, month, year, time_in)
    number_set = zeros(Int, length(time_in))
    unique_comb = unique(zip(time_in, day, month, year))

    for (k, (ti, d, m, y)) in enumerate(unique_comb)
        inds = findall(i -> time_in[i] == ti && day[i] == d && month[i] == m && year[i] == y, eachindex(time_in))
        number_set[inds] .= k
    end   
    return number_set
end 

@everywhere function normalized_wind_profile()
    # PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER4/output_txt/"

    input_file_wind  = PATH_output_txt * "wind_profile_interp.txt"
    wind_info = readdlm(input_file_wind) #d, m, y, h, height_val, wind_val
    day_w = wind_info[:, 1]
    month_w = wind_info[:, 2]
    year_w = wind_info[:, 3] 
    time_w = wind_info[:, 4] .* 3600   #sec 
    height_w = wind_info[:, 5] 
    wind_w = wind_info[:, 6]
    
    mask_season = (month_w.== 10) #.| (month_w.== 2) .| (month_w.== 12)
    day_w = day_w[mask_season]
    month_w = month_w[mask_season]
    year_w = year_w[mask_season]
    time_w = time_w[mask_season]
    height_w = height_w[mask_season]
    wind_w = wind_w[mask_season]
    # println(unique(time_w[:]))

    info_pbl_height = [] 
    input_file_pbl = PATH_output_txt * "pbl_aligned_with_lidar.txt"
    pbl_info = readdlm(input_file_pbl)

    for t_ind in 1:length(time_w)
        println(t_ind , " out of ", length(time_w))
        t = time_w[t_ind]
        norm_height = normalize_height(t, day_w[t_ind], month_w[t_ind], year_w[t_ind], pbl_info) #true , false 
        push!(info_pbl_height, norm_height)
    end 
    
    println("end", unique(info_pbl_height))
    number_of_the_profile = find_number_of_the_profile(day_w, month_w, year_w, time_w)
    height_w = height_w ./ info_pbl_height

    output_file_raw = PATH_output_txt * "wind_profile_interp_RAW_DATA_fall.txt"
    writedlm(output_file_raw, hcat(day_w, month_w, year_w, time_w, height_w, wind_w, number_of_the_profile ))

end 


main()
check()
# normalized_wind_profile()