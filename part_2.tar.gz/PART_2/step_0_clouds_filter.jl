using Glob 
using CSV  
using Plots 
using Colors 
using NCDatasets
using Dates  
using Statistics 
using Dierckx    
using Polynomials
using StatsBase 
using DSP  
using DelimitedFiles
using Measures
using LaTeXStrings
using Interpolations
using LsqFit 
using Distributed

addprocs(64)
@everywhere using NCDatasets, Statistics, Interpolations, LsqFit, Dates, Polynomials
@everywhere using Glob, DelimitedFiles

@everywhere const PATH_output_png = "/home/ellai/test_arm_data/flux_calc/VER6/output_png/"
@everywhere const PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER6/output_txt/"

@everywhere const PATH_folder_ceil1 = "/home/ellai/data/archive/DOE-SC0021074 (Tracer)/level 1/houarsclkazrbnd1kolliasM1/"
@everywhere const PATH_folder_ceil0 = "/home/ellai/data/archive/DOE-SC0021074 (Tracer)/level 1/houceilM1/"
@everywhere const PATH_folder_main = "/home/ellai/data/archive/DOE-SC0021074 (Tracer)/level 1/houdlprofwstats4newsM1.c1/"
@everywhere const PATH_folder_lidar = "/home/ellai/data/archive/DOE-SC0021074 (Tracer)/level 1/houdlfptM1/"

@everywhere const time_zone = -5
@everywhere const time_gap = 3

# from dataset format to seconds
@everywhere function from_datetime_to_sec(set_time, day_in, month_in, year_in)
    time_sec = hour.(set_time) .* 3600 .+ minute.(set_time) .* 60 .+ second.(set_time) 
    
    base_datetime = DateTime(year_in, month_in, day_in)
    total_time_dt = base_datetime .+ Second.(time_sec)
    dt_local = total_time_dt .+ Hour(time_zone)

    true_year = year.(dt_local)
    true_month = month.(dt_local)
    true_day = day.(dt_local)

    true_time_sec = Dates.value.(dt_local .- DateTime.(true_year, true_month, true_day)) ./ 1000

    return true_time_sec, true_day, true_month, true_year
end



@everywhere function align_data_with_lidar(num_cld, title)
    input_file_time = "time_lidar.txt"
    input_file_cld = "clouds.txt"

    input_data_time = readdlm(PATH_output_txt * input_file_time)         # day / month / year / time (LIDAR)
    input_data_cld = readdlm(PATH_output_txt * input_file_cld)             # day / month / year / time / h_all / rh_all / temp_all
    println(size(input_data_time))

    # Extract unique days from lidar time
    time_day_keys = [(input_data_time[i,1], input_data_time[i,2], input_data_time[i,3]) for i in 1:size(input_data_time,1)]
    unique_days = unique(time_day_keys)
    interpolated_cld = []

    count, count_2 = 0, 0
    count_days, count_days_2 = [], []

    for day in unique_days
        day_lidar, m_lidar, y_lidar = day

        idxs_time = findall(x -> x[1]==day_lidar && x[2]==m_lidar && x[3]==y_lidar, time_day_keys)
        lidar_times = input_data_time[idxs_time, 4]

        mask_day = (input_data_cld[:,1] .== day_lidar) .&
                   (input_data_cld[:,2] .== m_lidar) .&
                   (input_data_cld[:,3] .== y_lidar)

        cld_times = input_data_cld[mask_day, 4]
        cld_values = input_data_cld[mask_day, num_cld]
        cld_values = replace(cld_values, "missing" => missing)

        
        if isempty(cld_times)
            for t_lidar in lidar_times
                push!(interpolated_cld, [day_lidar, m_lidar, y_lidar, t_lidar, missing]) 
                
                count += 1
                push!(count_days, [day_lidar, m_lidar, y_lidar])
            end
            continue
        end

        
        for t_lidar in lidar_times
            time_diffs = abs.(cld_times .- t_lidar)
            if minimum(time_diffs) <= time_gap * 3600
                idx_closest = argmin(time_diffs)
                t_cld = cld_times[idx_closest]

                idx_match = findall(cld_times .== t_cld)
                cld_set1 = cld_values[idx_match][1]
                if !ismissing(cld_set1)
                    push!(interpolated_cld, [day_lidar, m_lidar, y_lidar, t_lidar, cld_set1])
                else
                    push!(interpolated_cld, [day_lidar, m_lidar, y_lidar, t_lidar, missing])
                    count_2 += 1
                    push!(count_days_2, [day_lidar, m_lidar, y_lidar])
                end 
                # push!(interpolated_cld, [day_lidar, m_lidar, y_lidar, t_lidar, cld_set1])
            else
                push!(interpolated_cld, [day_lidar, m_lidar, y_lidar, t_lidar, missing])
                count_2 += 1
                push!(count_days_2, [day_lidar, m_lidar, y_lidar])
            end
        end
    end
    unique_days = unique(count_days)
    unique_days_2 = unique(count_days_2)
    println(unique_days)

    println("missing days ", count, ", which is ", round(count/length(interpolated_cld)*100, digits = 2),"% from all data set,  or ", length(unique_days), " days")
    println("missing time gap ", count_2, ", which is ", round(count_2/length(interpolated_cld)*100),"% from all data set,  or ", length(unique_days_2), " days")
    println(size(interpolated_cld))
    writedlm(PATH_output_txt * "clouds_aligned_with_lidar"*title*".txt", interpolated_cld)
    println(PATH_output_txt * "clouds_aligned_with_lidar"*title*".txt")
end


@everywhere function read_ceil_data(PATH_file, init_day, init_month, init_year)
    println(PATH_file)
    dataset = NCDataset(PATH_file, "r")
    info_one_file = []

    # variable_names = keys(dataset)
    # println("Variables in the dataset: ", variable_names)
    # sleep(100)

    time_in_datetime = dataset["time"] 
    time_in_sec, day, month, year =  from_datetime_to_sec(time_in_datetime, init_day, init_month, init_year)

    # cld1 = dataset["first_cbh"] #ceil0 
    # cld1 = dataset["cloud_base_best_estimate"]
    # cld1 = dataset["cloud_layer_base_height"]
    cld1 = dataset["dl_cbh"] # dl
    cld2 = dataset["ceil_cbh"] # ceil

    # println(cld1)
    # println(cld1[1:10])
    # sleep(100)

    # for i in eachindex(time_in_sec)
    #     if cld1[i] !== missing 
    #         cldh_val = 0.9 * cld1[i]
    #         push!(info_one_file, [day[i], month[i], year[i], time_in_sec[i], cldh_val])
    #     end
    # end
    for i in eachindex(time_in_sec)
        cldh_val_1 = if !ismissing(cld1[i])
            0.9f0 * Float32(cld1[i])
        else
            missing
        end
    
        cldh_val_2 = if !ismissing(cld2[i])
            0.9f0 * Float32(cld2[i])
        else
            missing
        end
    
        push!(info_one_file, [day[i], month[i], year[i], time_in_sec[i], cldh_val_1, cldh_val_2])
    end
    
    close(dataset)

    return info_one_file
end



@everywhere function process_file_ceil(file)
    file_parts = split(basename(file), ".")
    day = parse(Int, file_parts[3][7:8])
    month = parse(Int, file_parts[3][5:6])
    year = parse(Int, file_parts[3][1:4])
    file_path = PATH_folder_main * file
    return read_ceil_data(file_path, day, month, year)
end

function cloud_all()
    set_files = filter(x -> endswith(x, ".nc"), readdir(PATH_folder_main))
    println("there are ", length(set_files), " files in your folder")

    clouds_from_files = pmap(process_file_ceil, set_files)
    all_clouds = reduce(vcat, clouds_from_files)

    output_file = PATH_output_txt * "clouds.txt"
    writedlm(output_file, all_clouds)
    println(output_file)
end


function compare_ceil_vs_dl()
    input_data_cld_1 = readdlm(PATH_output_txt * "clouds_aligned_with_lidar_dl.txt", Any)
    day_1 = input_data_cld_1[:, 1]
    month_1 = input_data_cld_1[:, 2]
    year_1 = input_data_cld_1[:, 3]
    cldh_1 = input_data_cld_1[:, 5]


    input_data_cld_2 = readdlm(PATH_output_txt * "clouds_aligned_with_lidar_ceil.txt")
    day_2 = input_data_cld_2[:, 1]
    month_2 = input_data_cld_2[:, 2]
    year_2 = input_data_cld_2[:, 3]
    cldh_2 = input_data_cld_2[:, 5]

    # mask_days_1 = (month_1 .== 6) .& (year_1 .== 2022)
    # mask_days_2 = (month_2 .== 6) .& (year_2 .== 2022)


    # cldh_1 = cldh_1[mask_days_1]
    # cldh_2 = cldh_2[mask_days_2]
    
    cldh_1 = [x == "missing" ? missing : x for x in cldh_1]
    cldh_2 = [x == "missing" ? missing : x for x in cldh_2]

    cldh_1 = sort(cldh_1)
    cldh_2 = sort(cldh_2)

    p = histogram(cldh_1, bins=20, alpha=0.5, label="clouds DL")
    histogram!(cldh_2, bins=20, alpha=0.5, label="clouds CEIL")
    png(p, PATH_output_png * "cloud_base.png")
end 

# cloud_all()
# align_data_with_lidar(5, "_dl") 
# align_data_with_lidar(6, "_ceil")

# compare_ceil_vs_dl()



# clouds checked in 3 h gap: then we loose only 3 %
# missing days 852, which is 2.62% from all data set,  or 9 days
# missing time gap 3447, which is 11.0% from all data set,  or 133 days

# missing days 852, which is 2.62% from all data set,  or 9 days
# missing time gap 5419, which is 17.0% from all data set,  or 175 days
# (32508,)

# missing days 0, which is 0.0% from all data set,  or 0 days
# missing time gap 3, which is 0.0% from all data set,  or 2 days
# (32508,)