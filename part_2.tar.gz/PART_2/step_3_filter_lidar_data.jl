
using Glob  # for globbing the file patterns
using CSV   # for reading CSV files
using Plots # for plotting
using Colors # for color normalization
using NCDatasets # for NetCDF
using Dates  # to convert dates in sec
using Statistics # for mean
using Dierckx     # For detrend (spline interpolation)
using Polynomials
using StatsBase 
using DSP  # Import DSP package
using DelimitedFiles
using NetCDF
using Measures
using DataFrames
using Distributed

addprocs(64)
# @everywhere include("/home/ellai/test_arm_data/flux_calc/VER4/step_3_calc_flux_ll.jl")

# atexit(() -> rmprocs(workers()))

@everywhere using NCDatasets, Statistics, Interpolations, LsqFit, Dates, Polynomials
@everywhere using Glob, DelimitedFiles

@everywhere function one_month(info_time_lidar, info_stab, info_pbl, info_clouds, info_precip, info_rh, time_in, time_out, month_flag, stability_flag, condition_flag)
    time_in = time_in * 3600
    time_out = time_out * 3600 

    println("------", month_flag)
    l_day = info_time_lidar[:, 1]
    l_month = info_time_lidar[:, 2]
    l_year = info_time_lidar[:, 3]
    l_time = info_time_lidar[:, 4]  # sec 


    stab_day = info_stab[:, 1]
    stab_month = info_stab[:, 2]
    stab_year = info_stab[:, 3]
    stab_time = info_stab[:, 4] # sec 
    stab_val = info_stab[:, 5]
    stab_val = replace(stab_val, "missing" => missing)

    pbl_day = info_pbl[:, 1]
    pbl_month = info_pbl[:, 2]
    pbl_year = info_pbl[:, 3]
    pbl_time = info_pbl[:, 4] # sec
    pbl_val = info_pbl[:, 5]
    pbl_val = replace(pbl_val, "missing" => missing)

    cld_day = info_clouds[:, 1]
    cld_month = info_clouds[:, 2]
    cld_year = info_clouds[:, 3]
    cld_time = info_clouds[:, 4] # sec
    cld_val = info_clouds[:, 5]
    cld_val = replace(cld_val, "missing" => missing)

    prcpt_day = info_precip[:, 1]
    prcpt_month = info_precip[:, 2]
    prcpt_year = info_precip[:, 3]
    prcpt_time = info_precip[:, 4] # sec
    prcpt_val = info_precip[:, 5]
    prcpt_val = replace(prcpt_val, "missing" => missing)
    
    
    rh_day = info_rh[:, 1]
    rh_month = info_rh[:, 2]
    rh_year = info_rh[:, 3]
    rh_time = info_rh[:, 4] .* 3600 # sec
    rh_height = info_rh[:, 5]
    rh_val = info_rh[:, 6]
    rh_val = replace(rh_val, "missing" => missing)
    rh_temp = info_rh[:, 7]
    rh_temp = replace(rh_temp, "missing" => missing)

    # println(size(cld_day))
    # println(size(pbl_day))
    # println(size(stab_day))
    # println(size(l_day))
    # println(size(prcpt_day))
    # sleep(100)
    println("total amount of profiles: ", length(l_time))
    if month_flag[1] == true 
        mask_time  = (l_time .>= time_in) .& (l_time .<= time_out) .& (l_month .== month_flag[2]) .& (l_year .== month_flag[3])
    else
        mask_time  = (l_time .>= time_in) .& (l_time .<= time_out) 
    end

    l_day = l_day[mask_time]
    l_month = l_month[mask_time]
    l_year = l_year[mask_time]
    l_time = l_time[mask_time]  
    println("for ", time_in/3600, "-", time_out/3600, " time range: ", length(l_time))
    N_total = length(l_time)


    # STABILITY
    ind_l_time_after_zl = []
    set_stblt = []
    for t in 1:length(l_time)
        mask = (l_day[t] .== stab_day) .& (l_month[t] .== stab_month) .& (l_year[t] .== stab_year) .& (l_time[t] .== stab_time) 
        stab_time_new = stab_time[mask]
        stab_val_new = stab_val[mask]
        if length(stab_time_new) != 0  && !ismissing(stab_val_new[1])
            if stability_flag == "neutral"
                if abs(stab_val_new[1]) <= 0.2
                    push!(ind_l_time_after_zl, t)
                    push!(set_stblt, stab_val_new[1])
                end   
            elseif  stability_flag == "unstable"
                if stab_val_new[1] < -0.2
                    push!(ind_l_time_after_zl, t)
                    push!(set_stblt, stab_val_new[1])
                end  
            elseif  stability_flag == "stable"
                if stab_val_new[1] > 0.2
                    push!(ind_l_time_after_zl, t)
                    push!(set_stblt, stab_val_new[1])
                end  
            end    
        end
    end

    l_day = l_day[ind_l_time_after_zl]
    l_month = l_month[ind_l_time_after_zl]
    l_year = l_year[ind_l_time_after_zl]
    l_time = l_time[ind_l_time_after_zl]
    println("after stability-filter: ", length(l_time), " ", length(set_stblt))
    N_zl = length(l_time)
    
    # PBL H 
    pbl_for_lidar = []
    for t in 1:length(l_time)
        mask = (l_day[t] .== pbl_day) .& (l_month[t] .== pbl_month) .& (l_year[t] .== pbl_year) .& (l_time[t] .== pbl_time)
        pbl_time_new = pbl_time[mask]
        pbl_val_new = pbl_val[mask]
        if length(pbl_time_new) != 0  && !ismissing(pbl_val_new[1])
            # diff_hours = abs.(pbl_time_new .- (l_time[t]))  
            # min_diff, min_idx = findmin(diff_hours)
            # if min_diff <= 3  # within ±1 hour
            push!(pbl_for_lidar, pbl_val_new[1])         
            # else 
                # push!(pbl_for_lidar, missing)         
            # end
        else
            push!(pbl_for_lidar, missing)             
        end
    end
    # println(unique(pbl_for_lidar))
    # println(unique(cld_val))
    # println(pbl_for_lidar./cld_val)
    # p = histogram(cld_val, bins = 40, xlabel = "Cloud Fraction / Value", ylabel = "Count", title  = "Distribution of Cloud Values", label = "clouds")
    # p = histogram(pbl_for_lidar, bins = 40, xlabel = "Cloud Fraction / Value", ylabel = "Count", title  = "Distribution of Cloud Values", alpha = 0.6, label = "pbl")
    # PATH_output_png = "/home/ellai/test_arm_data/flux_calc/VER6/output_png/"
    # savefig(PATH_output_png*"hist_cloud_value.png")

    # println()


    # pbl_for_lidar = replace(pbl_for_lidar, "missing" => missing)
    # missing_count = count(x -> ismissing(x) || x == "missing", pbl_for_lidar)
    # println("amount of missing for pbl: ", missing_count)

    # unique_days = unique(zip(l_year, l_month, l_day))
    # println("Number of unique days: ", length(unique_days))
  
    # CLOUDS
    ind_l_time_after_cld = []
    set_cld_h = []
    set_pbl_h = []
    for t in 1:length(l_time)
        mask = (l_day[t] .== cld_day) .& (l_month[t] .== cld_month) .& (l_year[t] .== cld_year).& (l_time[t] .== cld_time)
        cld_time_new = cld_time[mask]
        cld_val_new = cld_val[mask]
        pbl_t = pbl_for_lidar[t]
        if length(cld_time_new) != 0  && !ismissing(cld_val_new[1])
            # diff_hours = abs.(cld_time_new .- (l_time[t]))  
            # min_diff, min_idx = findmin(diff_hours)
            # if min_diff <= 1  # within ±1 hour
            if condition_flag == "clean"
                if !(ismissing(pbl_t)) && cld_val_new[1] != "missing" 
                    if cld_val_new[1] >= pbl_t
                        push!(ind_l_time_after_cld, t)
                        push!(set_cld_h, cld_val_new[1])
                        push!(set_pbl_h, pbl_t)
                    end
                end 
            elseif condition_flag == "nonclean"
                if !(ismissing(pbl_t)) && cld_val_new[1] != "missing" 
                    if cld_val_new[1] > 100 && cld_val_new[1] < pbl_t
                        push!(ind_l_time_after_cld, t)
                        push!(set_cld_h, cld_val_new[1])
                        push!(set_pbl_h, pbl_t)
                    end
                end
            end 
        end 
    end
    l_day = l_day[ind_l_time_after_cld]
    l_month = l_month[ind_l_time_after_cld]
    l_year = l_year[ind_l_time_after_cld]
    l_time = l_time[ind_l_time_after_cld]
    set_stblt = set_stblt[ind_l_time_after_cld]
    println("after cloud-filter: ", length(l_time), " ", length(set_stblt), " ", length(set_cld_h))
    # sleep(5)
    N_clouds = length(l_day)

    # PRECIPITATION
    ind_l_time_after_prcpt = []
    for t in 1:length(l_time)
        mask = (l_day[t] .== prcpt_day) .& (l_month[t] .== prcpt_month) .& (l_year[t] .== prcpt_year).& (l_time[t] .== prcpt_time)
        prcpt_time_new = prcpt_time[mask]
        prcpt_val_new = prcpt_val[mask]
        if length(prcpt_time_new)!= 0 &&  !ismissing(prcpt_val_new[1])
            # diff_hours = abs.(prcpt_time_new .- (l_time[t]))  
            # min_diff, min_idx = findmin(diff_hours)
            # if min_diff <= 1  # within ±1 hour
                # println(min_diff)
                # println(min_idx)
            if prcpt_val_new[1] == 0
                push!(ind_l_time_after_prcpt, t)
            end
        end 
    end

    l_day = l_day[ind_l_time_after_prcpt]
    l_month = l_month[ind_l_time_after_prcpt]
    l_year = l_year[ind_l_time_after_prcpt]
    l_time = l_time[ind_l_time_after_prcpt]
    set_stblt = set_stblt[ind_l_time_after_prcpt]
    set_cld_h = set_cld_h[ind_l_time_after_prcpt]
    set_pbl_h = set_pbl_h[ind_l_time_after_prcpt]
    println("after precipitation-filter: ", length(l_time))
    N_prcpt = length(l_day)
    
    set_pbl_h = ifelse.(ismissing.(set_pbl_h), set_cld_h, set_pbl_h) # if no plh , replace for clouds level . 

    # RH 
    ind_l_time_after_rh = []
    set_rh_h, set_temp_t =  [], []
    for t in 1:length(l_time)
        mask = (l_day[t] .== rh_day) .& (l_month[t] .== rh_month) .& (l_year[t] .== rh_year).& (l_time[t] .== rh_time)
        original_inds = findall(mask)  
        rh_time_new = rh_time[original_inds]
        rh_val_new = rh_val[original_inds]
        rh_height_new = rh_height[original_inds]

        if !ismissing(set_pbl_h[t])
            pbl_t = set_pbl_h[t]
        else 
            pbl_t = NaN
        end
         
        # everything below pbl
        mask_h = (pbl_t .>= rh_height_new) 
        rh_height_new = rh_height_new[mask_h]
        rh_val_new = rh_val_new[mask_h]
        rh_time_new = rh_time_new[mask_h]
        original_inds = original_inds[mask_h]  # update indices after filtering

        # amount_of_data_1 = length(rh_height_new)
         
        # minimum hight with rh = 90
        inds = findall(x -> x >= 90, rh_val_new)
        if length(inds) != 0
            min_h = minimum(rh_height_new[inds])
        else
            min_h = pbl_t
        end 
        
        if condition_flag == "clean"
            if min_h >= pbl_t
                mask_h2 = (min_h .>= rh_height_new) 
                rh_height_new = rh_height_new[mask_h2]
                rh_val_new = rh_val_new[mask_h2]
                rh_time_new = rh_time_new[mask_h2]
                original_inds = original_inds[mask_h2]  # final filtered indices
                push!(ind_l_time_after_rh, t)
                push!(set_rh_h, min_h)
            end 
        elseif condition_flag == "nonclean"
            mask_h2 = (min_h .>= rh_height_new) 
            rh_height_new = rh_height_new[mask_h2]
            rh_val_new = rh_val_new[mask_h2]
            rh_time_new = rh_time_new[mask_h2]
            original_inds = original_inds[mask_h2]  # final filtered indices
            push!(ind_l_time_after_rh, t)
            push!(set_rh_h, min_h) 
        end 


        # mask_h2 = (min_h .>= rh_height_new) 
        # rh_height_new = rh_height_new[mask_h2]
        # rh_val_new = rh_val_new[mask_h2]
        # rh_time_new = rh_time_new[mask_h2]
        # original_inds = original_inds[mask_h2]  # final filtered indices
        # push!(ind_l_time_after_rh, t)
        # push!(set_rh_h, min_h)

        # amount_of_data_2 = length(rh_height_new)

        #
        # mask_rh = (90 .>= rh_val_new)
        # rh_height_new = rh_height_new[mask_rh]
        # rh_val_new = rh_val_new[mask_rh]
        # rh_time_new = rh_time_new[mask_rh]

        # percent_of_clean_data = amount_of_data_2/amount_of_data_1*100
        
        # if  percent_of_clean_data > 50 && min_h >= pbl_t/2  # cutting all bad profiles 
        #     min_h_2 = minimum(rh_height_new) 
        #     if condition_flag == "clean"
        #         if min_h >= pbl_t
        #             push!(ind_l_time_after_rh, t)
        #             push!(set_rh_h, pbl_t)
        #         end
        #     elseif condition_flag == "nonclean"
        #         push!(ind_l_time_after_rh, t)
        #         push!(set_rh_h, min_h_2)
        #     end 
        # end         
    end
    
    println("MINIMUM ", set_rh_h)
    l_day = l_day[ind_l_time_after_rh]
    l_month = l_month[ind_l_time_after_rh]
    l_year = l_year[ind_l_time_after_rh]
    l_time = l_time[ind_l_time_after_rh]
    set_stblt = set_stblt[ind_l_time_after_rh]
    set_cld_h = set_cld_h[ind_l_time_after_rh]
    set_pbl_h = set_pbl_h[ind_l_time_after_rh]
    # set_rh_h
    println("after rh-filter: ", length(l_time))
    N_rh = length(l_day)

    # println(length(l_time), length(set_stblt))
    # println(length(l_day), length(l_month), length(l_year),  length(l_time))
    # println(length(set_pbl_h), length(set_cld_h), length(set_stblt),  length(set_rh_h))

    return N_total, N_zl, N_clouds, N_prcpt, N_rh, [l_day, l_month, l_year, l_time, set_pbl_h, set_cld_h, set_stblt, set_rh_h]
end


@everywhere function compute_one_month(d, info_time_lidar, info_stab, info_pbl, info_clouds, info_precip, info_rh, stability_flag, condition_flag)
    month_flag = [true, month(d), year(d)]
    true_time, true_N1, true_N2, true_N3, true_N4, true_N5 = Float64[], Float64[], Float64[], Float64[], Float64[], Float64[]
    filtered_time_lidar = (Int[], Int[], Int[], Int[], Float64[], Union{Missing, Float64}[], Union{Missing, Float64}[], Union{Missing, Float64}[])

    for t in 0:1.0:23.0
        N1, N2, N3, N4, N5, time_info = one_month(info_time_lidar, info_stab, info_pbl, info_clouds, info_precip, info_rh, t, t + 1.0, month_flag, stability_flag, condition_flag)
        push!(true_time, t)
        push!(true_N1, N1)
        push!(true_N2, N2)
        push!(true_N3, N3)
        push!(true_N4, N4)
        push!(true_N5, N5)
        for j in 1:length(time_info)
            append!(filtered_time_lidar[j], time_info[j])
        end
    end
    return (d, true_time, true_N1, true_N2, true_N3, true_N4, true_N5, filtered_time_lidar)
end



function main(stability_flag, condition_flag)
    PATH_output_png = "/home/ellai/test_arm_data/flux_calc/VER6/output_png/"
    PATH_output_txt = "/home/ellai/test_arm_data/flux_calc/VER6/output_txt/"


    file_time_lidar = PATH_output_txt * "time_lidar.txt"
    info_time_lidar = readdlm(file_time_lidar)

    file_stab = PATH_output_txt * "stb_aligned_with_lidar.txt" # every 30 nim 
    info_stab = readdlm(file_stab)

    file_pbl = PATH_output_txt * "pbl_aligned_with_lidar_filtered.txt"
    info_pbl = readdlm(file_pbl)

    file_clouds = PATH_output_txt * "clouds_aligned_with_lidar_dl.txt" 
    info_clouds = readdlm(file_clouds)

    file_precip = PATH_output_txt * "prc_aligned_with_lidar.txt" # does not depend on hight 
    info_precip = readdlm(file_precip)

    file_rh = PATH_output_txt * "rh_aligned_with_lidar.txt"
    info_rh = readdlm(file_rh)



    # Time range: Sep 2021 to Sep 2022
    # start_date = Date(2021, 8, 1)
    # end_date = Date(2022, 10, 1)
    start_date = Date(2021, 10, 1)
    end_date = Date(2022, 10, 1)
    months_all = collect(start_date:Month(1):end_date)

    ncols = 4
    nrows = cld(length(months_all), ncols)
    plt = plot(layout=(nrows, ncols), size=(1200, 300 * nrows), left_margin = 10mm)
    filtered_time_lidar = (Int[], Int[], Int[], Int[],  Float64[], Union{Missing, Float64}[], Union{Missing, Float64}[], Union{Missing, Float64}[])

    total_N1 = 0.0
    total_N2 = 0.0 
    total_N3 = 0.0 
    total_N4 = 0.0 
    total_N5 = 0.0 

    results = pmap(d -> compute_one_month(d, info_time_lidar, info_stab, info_pbl, info_clouds, info_precip, info_rh, stability_flag, condition_flag), months_all)
    vir = cgrad(:viridis)

    c1 = vir[0.2]
    c2 = vir[0.4]
    c3 = vir[0.6]
    c4 = vir[0.8]
    for (i, (d, true_time, true_N1, true_N2, true_N3, true_N4, true_N5, time_info)) in enumerate(results)
        total_N1 += sum(true_N1)
        total_N2 += sum(true_N2)
        total_N3 += sum(true_N3)
        total_N4 += sum(true_N4)
        total_N5 += sum(true_N5)

        bar!(plt, true_time, true_N1, bar_width=0.9, alpha=0.2, label="Total", color=c1, subplot=i, ylim=(0, 150), xlim = [-1,25])
        bar!(plt, true_time, true_N2, bar_width=0.6, alpha=0.5, label="ZL", color=c2, subplot=i, ylim=(0, 150), xlim = [-1,25])
        bar!(plt, true_time, true_N3, bar_width=0.3, alpha=0.8, label="Clouds",color=c3, subplot=i, ylim=(0, 150), xlim = [-1,25])
        bar!(plt, true_time, true_N5, bar_width=0.3, alpha=1.0, label="Precipitation+RH", color=c4, subplot=i, ylim=(0, 150), xlim = [-1,25])
        
        title!(plt[i], "$(month(d))/$(year(d))")
        xlabel!(plt[i], "Time (h)")
        ylabel!(plt[i], "N")

        for j in 1:length(filtered_time_lidar)
            append!(filtered_time_lidar[j], time_info[j])
        end
    end

    println("total: ", total_N1, " after zl: ", total_N2, " after clouds: ", total_N3,  " after perc: ", total_N4,  " after rh: ", total_N5)
    println(round(total_N1/total_N1*100, digits=1), " ", round(total_N2/total_N1*100, digits=1), " ", round(total_N3/total_N1*100, digits=1), " ", round(total_N4/total_N1*100, digits=1), " ", round(total_N5/total_N1*100, digits=1))

    data = hcat(filtered_time_lidar...)
    writedlm(PATH_output_txt * "filtered_time_lidar_"* stability_flag*"_"*condition_flag*".txt", data)
    savefig(PATH_output_png * "monthly_time_vs_N_panel_"* stability_flag*"_"*condition_flag*".png")

    # for (i, d) in enumerate(months_all)
    #     month_flag = [true, month(d), year(d)]

    #     true_time, true_N1, true_N2, true_N3, true_N4, true_N5 = Float64[], Float64[], Float64[], Float64[], Float64[], Float64[]

    #     for t in 0:1.0:23.0
    #         in = t
    #         out = t + 1.0
    #         N1, N2, N3, N4, N5, time_info = one_month(info_time_lidar, info_stab, info_pbl, info_clouds, info_precip, info_rh, in, out, month_flag, stability_flag, condition_flag)
    #         push!(true_time, t)
    #         push!(true_N1, N1)
    #         push!(true_N2, N2)
    #         push!(true_N3, N3)
    #         push!(true_N4, N4)
    #         push!(true_N5, N5)
    #         # println(size(time_info))
    #         for j in 1:length(time_info)
    #             # println(time_info[j])
    #             # println(time_info[j])
    #             # println(j, " ", size(filtered_time_lidar[j]))
    #             # println(j, " ", size(time_info[j]), " ", time_info[j])
    #             append!(filtered_time_lidar[j], time_info[j])
    #         end 
    #     end
    #     total_N1 += sum(true_N1)
    #     total_N2 += sum(true_N2)
    #     total_N3 += sum(true_N3)
    #     total_N4 += sum(true_N4)
    #     total_N5 += sum(true_N5)

    #     bar!(plt, true_time, true_N1, bar_width=0.9, alpha=0.2, label="Total", color=:green, subplot=i, ylim=(0, 150))
    #     bar!(plt, true_time, true_N2, bar_width=0.6, alpha=0.5, label="ZL", color=:purple, subplot=i, ylim=(0, 150))
    #     bar!(plt, true_time, true_N3, bar_width=0.3, alpha=0.8, label="Clouds", color=:blue, subplot=i, ylim=(0, 150))
    #     bar!(plt, true_time, true_N5, bar_width=0.3, alpha=1.0, label="Precipitation+RH", color=:red, subplot=i, ylim=(0, 150))
     
    #     title!(plt[i], "$(month(d))/$(year(d))")
    #     xlabel!(plt[i], "Time (h)")
    #     ylabel!(plt[i], "N")
    # end
    # println("total: ", total_N1, " after zl: ", total_N2, " after clouds: ", total_N3,  " after perc: ", total_N4,  " after rh: ", total_N5)
    # println(round(total_N1/total_N1*100, digits=1), " ", round(total_N2/total_N1*100, digits=1), " ", round(total_N3/total_N1*100, digits=1), " ", round(total_N4/total_N1*100, digits=1), " ", round(total_N5/total_N1*100, digits=1))
    # # println(filtered_time_lidar)
    # data = hcat(filtered_time_lidar...)  # convert tuple of vectors to a matrix
    # writedlm(PATH_output_txt * "filtered_time_lidar_"* stability_flag*"_"*condition_flag*".txt", data)
    # savefig(PATH_output_png * "monthly_time_vs_N_panel_"* stability_flag*"_"*condition_flag*".png")
end 


main("stable", "nonclean")

# cloud_options = ["nonclean", "clean"]
# stability_options = ["stable", "unstable","neutral"]

# for flag_clouds in cloud_options
#     for flag_stability in stability_options
#         main(flag_stability, flag_clouds)
#     end
# end

# "unstable", "clean"
# total: 32488.0 after zl: 3363.0 after clouds: 2062.0 after perc: 1807.0 after rh: 1686.0
# 100.0 10.4 6.3 5.6 5.2

# "unstable", "nonclean"
# total: 32488.0 after zl: 3363.0 after clouds: 351.0 after perc: 332.0 after rh: 332.0
# 100.0 10.4 1.1 1.0 1.0

# "neutral", "clean"
# total: 32488.0 after zl: 22063.0 after clouds: 11093.0 after perc: 9296.0 after rh: 8050.0
# 100.0 67.9 34.1 28.6 24.8

# "neutral", "nonclean"
# total: 32488.0 after zl: 22063.0 after clouds: 4951.0 after perc: 4223.0 after rh: 4223.0
# 100.0 67.9 15.2 13.0 13.0

# "stable", "clean"
# total: 32488.0 after zl: 6330.0 after clouds: 4030.0 after perc: 3466.0 after rh: 3277.0
# 100.0 19.5 12.4 10.7 10.1

# "stable", "nonclean"
# total: 32488.0 after zl: 6330.0 after clouds: 91.0 after perc: 85.0 after rh: 85.0
# 100.0 19.5 0.3 0.3 0.3