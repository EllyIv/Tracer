using DelimitedFiles
using Plots
using Measures
using LaTeXStrings

function group_by_day(info)
    groups = Dict{Tuple{Int,Int,Int}, Vector{Int}}()
    for i in 1:size(info,1)
        key = (info[i,1], info[i,2], info[i,3])   # (day, month, year)
        push!(get!(groups, key, Int[]), i)
    end
    return groups
end


function process_profile(day, month, year, time,
                                     info_rh, info_pbl,
                                     group_rh, group_pbl)

    # skip time
    if time < 12 || time > 13
        return nothing
    end

    key = (day, month, year)

    # get rows for this day only
    idx_rh  = get(group_rh,  key, Int[])
    idx_pbl = get(group_pbl, key, Int[])

    isempty(idx_pbl) && return nothing

    # --- PBL matching ---
    pbl_time   = info_pbl[idx_pbl, 4] 
    pbl_values = info_pbl[idx_pbl, 5]

    # time tolerance ±0.5 h
    mask_p = abs.(pbl_time .- time) .<= 0.5

    if !any(mask_p)
        return nothing
    end

    pbl = pbl_values[mask_p][1]
    if pbl == "missing" || pbl == "" || pbl == 0 || ismissing(pbl)
        return nothing
    end

    # --- RH matching ---
    rh_time  = info_rh[idx_rh, 4]
    rh_h     = info_rh[idx_rh, 5]
    rh_t_raw = info_rh[idx_rh, 7]

    mask_r = abs.(rh_time .- time) .<= 0.5
    if !any(mask_r)
        return nothing
    end

    h = rh_h[mask_r]
    t = rh_t_raw[mask_r]

    # clean missing
    t = [v isa String && (v == "missing" || v == "") ? missing : v for v in t]
    valid = .!ismissing.(t)

    h = h[valid]
    t = t[valid]

    isempty(h) && return nothing

    z_norm = h ./ pbl
    return (t, z_norm)
end


function plot_normalized_profiles()

    PATH_txt = "/home/ellai/test_arm_data/flux_calc/VER6/output_txt/"
    PATH_png = "/home/ellai/test_arm_data/flux_calc/VER6/output_png/"

    info_rh       = readdlm(PATH_txt * "rh_aligned_with_lidar.txt")
    info_pbl_thl  = readdlm(PATH_txt * "pbl_aligned_with_lidar_temp_inversion.txt")
    info_pbl_LL   = readdlm(PATH_txt * "pbl_aligned_with_lidar_filtered.txt")
    info_pbl_comb = readdlm(PATH_txt * "pbl_aligned_with_lidar_combine.txt")

    # --- Pre-group by (day, month, year) ---
    group_rh_thl  = group_by_day(info_rh)
    group_rh_LL   = group_by_day(info_rh)
    group_rh_comb = group_by_day(info_rh)

    group_pbl_thl  = group_by_day(info_pbl_thl)
    group_pbl_LL   = group_by_day(info_pbl_LL)
    group_pbl_comb = group_by_day(info_pbl_comb)

    combos = unique([(info_rh[i,1], info_rh[i,2], info_rh[i,3], info_rh[i,4])
                     for i in 1:size(info_rh,1)])
    # combos = combos[90:5000]
    # --- No pmap, FAST serial loop ---
    function run_method(info_pbl, group_pbl, group_rh)
        out = Vector{Any}()
        for c in combos
            res = process_profile(c[1], c[2], c[3], c[4],
                                  info_rh, info_pbl,
                                  group_rh, group_pbl)
            if res !== nothing
                push!(out, res)
            end
        end
        return out
    end

    results = [
        run_method(info_pbl_thl,  group_pbl_thl,  group_rh_thl),
        run_method(info_pbl_LL,   group_pbl_LL,   group_rh_LL),
        run_method(info_pbl_comb, group_pbl_comb, group_rh_comb)
    ]

    labels = [L"z/PBL_{\theta}", L"z/PBL_{LL}", L"z/PBL_{comb}"]

    subplots = [plot(xlabel=L"θ (K)", ylabel=labels[i], legend=false, ylims=(0,1.5)) for i in 1:3]

    for i in 1:3
        for (t, z) in results[i]
            scatter!(subplots[i], t, z; color=:gray, markersize=1, alpha=0.02)
        end
    end

    plt = plot(subplots..., layout=(1,3), size=(1400,450))

    savefig(plt, PATH_png * "pbl_aligned_with_lidar_all.png")
    println(PATH_png * "pbl_aligned_with_lidar_all.png")

    # Save output
    for i in 1:3
        all_t = vcat([r[1] for r in results[i]]...)
        all_z = vcat([r[2] for r in results[i]]...)
        writedlm(PATH_txt * "normalized_temp_profiles_method_$i.txt", hcat(all_t, all_z))
    end
end


function plot_normalized_profiles_only_temp_inv()

    PATH_txt = "/home/ellai/test_arm_data/flux_calc/VER6/output_txt/"
    PATH_png = "/home/ellai/test_arm_data/flux_calc/VER6/output_png/"

    # === Load only needed datasets ===
    info_rh      = readdlm(PATH_txt * "rh_aligned_with_lidar.txt")
    info_pbl_thl = readdlm(PATH_txt * "pbl_aligned_with_lidar_temp_inversion.txt")

    # === Pre-grouping ===
    group_rh_thl  = group_by_day(info_rh)
    group_pbl_thl = group_by_day(info_pbl_thl)

    # === Unique combinations (day,month,year,time) ===
    combos = unique([(info_rh[i,1], info_rh[i,2], info_rh[i,3], info_rh[i,4])
                     for i in 1:size(info_rh,1)])

    # === Run only temp-inversion method ===
    function run_method(info_pbl, group_pbl, group_rh)
        out = Vector{Any}()
        for c in combos
            res = process_profile(c[1], c[2], c[3], c[4],
                                  info_rh, info_pbl,
                                  group_rh, group_pbl)
            if res !== nothing
                push!(out, res)
            end
        end
        return out
    end

    results = run_method(info_pbl_thl, group_pbl_thl, group_rh_thl)

    # === Plot ===
    p = plot(xlabel=L"θ\,(K)",
             ylabel=L"z/PBL_{\theta}",
             legend=false,
             ylims=(0,1.5),
             size=(600,450))

    for (t, z) in results
        scatter!(p, t, z; color=:gray, markersize=1, alpha=0.02)
    end

    savefig(p, PATH_png * "pbl_temp_inversion_only.png")
    println(PATH_png * "pbl_temp_inversion_only.png")
end


# plot_normalized_profiles()
plot_normalized_profiles_only_temp_inv()